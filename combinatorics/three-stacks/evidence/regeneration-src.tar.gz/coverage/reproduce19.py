"""Rebuild length-19 tables, run disjoint ordered workers, close their rows and archive the result."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import gzip
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import audit19
import close_ranges

SOURCE = Path(__file__).resolve().parents[1]
RESULTS = SOURCE/'coverage/results'
PHASES = ('build', 'tables', 'primary', 'close', 'archive')


def readable(path):
    return gzip.open(path, 'rt') if path.suffix == '.gz' else path.open()


def build(work):
    cxx = [os.environ.get('CXX', 'c++'), '-std=c++20', '-O3', '-march=native']

    def compile(source, name, *flags):
        subprocess.run([*cxx, *flags, SOURCE/source, '-o', work/name], check=True)

    for cut in (8, 9, 10, 11):
        compile('coverage/build_prefix_canonical.cpp', f'build-prefix{cut}', f'-DDECK_CUT={cut}')
        if cut <= 10:
            compile('coverage/recut.cpp', f'recut{cut}', f'-DDECK_CUT={cut}')
    compile('coverage/build_tail.cpp', 'build-tail19', '-DDECK_SIZE=19', '-DDECK_CUT=11')
    compile('verify/join_audit.cpp', 'table-index', '-DCARD_COUNT=19')
    compile('verify/check_packed_tail.cpp', 'check-packed')
    compile('verify/build_quadrant_codes.cpp', 'build-codes')
    compile('coverage/build_low_index.cpp', 'build-low-index')
    compile('coverage/check_low_index.cpp', 'check-low-index')
    compile('coverage/check_ordered_ownership.cpp', 'check-domains')
    compile('coverage/ordered_join.cpp', 'ordered-join')
    compile('coverage/ordered_join.cpp', 'ordered-projected', '-DORDERED_PROJECTED')
    compile('coverage/project_ordered_tables.cpp', 'project-ordered')
    compile('verify/check_ordered_projection.cpp', 'check-ordered-projection')
    compile('coverage/check_ordered_stream.cpp', 'check-stream')
    compile('coverage/flexfinish.cpp', 'flex')


def prepare_schedule(work, reference, manifest):
    if manifest:
        schedule = [(j.name, j.ranks) for j in audit19.live_jobs(manifest)]
    else:
        run = json.loads((reference/'run.json').read_text())
        schedule = [(name, reference/'workers'/name/'ranks.txt') for name in run['workers']]
    rows = []
    for name, source in schedule:
        shard = work / 'workers' / name
        shard.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, shard/'ranks.txt')
        rows.append(f"{name} @{shard/'ranks.txt'} 5040 1 {shard/'progress.log'} {shard/'raw.txt'}\n")
    (work/'workers.tsv').write_text(''.join(rows))
    with readable(RESULTS/'n19-fresh-priority.txt.gz') as src, (work/'priority.txt').open('w') as out:
        shutil.copyfileobj(src, out)
    tools = {f'recut{k}': str(work/f'recut{k}') for k in (8, 9, 10)}
    tools.update({f'prefix{k}': str(work/f'prefix{k}.bin') for k in (8, 9, 10)})
    tools.update(flex=str(work/'flex'), python=sys.executable, audit=str(work/'check-stream'),
                 priority=str(work/'priority.txt'), hard=900)
    (work/'tools.json').write_text(json.dumps(tools, indent=2)+'\n')
    with (work/'domains.csv').open('w') as dst:
        subprocess.run([work/'check-domains', work/'priority.txt', '900'], stdout=dst, check=True)
    with readable(RESULTS/'n19-ordered-domains.csv.gz') as expected:
        if (work/'domains.csv').read_text() != expected.read():
            raise ValueError('Independently regenerated domain counts differ')


def tables(work):
    for k in (8, 9, 10, 11):
        subprocess.run([work/f'build-prefix{k}', work/f'prefix{k}.bin'], check=True)
    raw = work/'tail19k11.bin'
    packed = work/'verify-tail19-packed.bin'
    subprocess.run([work/'build-tail19', raw, '1800'], check=True)
    subprocess.run([work/'table-index', '--pack-tail', raw, packed], check=True)
    subprocess.run([work/'check-packed', '19', '11', raw, packed], check=True)
    subprocess.run([work/'table-index', '--build-index', work/'prefix11.bin', work/'verify-index11.bin'], check=True)
    subprocess.run([work/'build-codes', '11', work/'quadrant-codes11.bin'], check=True)
    columns = SOURCE/'verify/n19-projection-columns.txt'
    subprocess.run([work/'project-ordered', work, columns], check=True)
    subprocess.run([work/'check-ordered-projection', work, columns], check=True)
    subprocess.run([work/'build-low-index', work/'quadrant-codes11.bin', work/'low-index11.bin'], check=True)
    subprocess.run([work/'check-low-index', work/'low-index11.bin'], check=True)


def primary(work, workers):
    jobs = audit19.live_jobs(work/'workers.tsv')
    checkpoints = json.loads((RESULTS/'n19-primary-restarts.json').read_text())
    def scan(job):
        with job.log.open('x') as log, job.raw.open('xb') as raw:
            ranks = list(map(int,job.ranks.read_text().split()))
            boundary = checkpoints.get(job.name, 0)
            if not 0 <= boundary <= len(ranks):
                raise ValueError(f'Invalid primary restart offset for {job.name}')
            phases = [('ordered-join', ranks[:boundary]), ('ordered-projected', ranks[boundary:])]
            for program, batch in phases:
                if not batch:
                    continue
                source = job.ranks.with_name(program+'-ranks.txt')
                source.write_text(''.join(f'{r}\n' for r in batch))
                subprocess.run([work/program, work, work/'prefix10.bin', work/'priority.txt',
                                source, '900', '0', work/'prefix9.bin', work/'prefix8.bin'],
                               stdout=raw, stderr=log, check=True)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        list(pool.map(scan, jobs))


def close(work, reference, recorded_chunks):
    out = work/'closures'
    tools = json.loads((work/'tools.json').read_text())
    if not recorded_chunks:
        subprocess.run([sys.executable, SOURCE/'coverage/close_ranges.py', work/'workers.tsv',
                        work/'tools.json', out], check=True)
        return
    out.mkdir(exist_ok=True)
    jobs = {j.name: j for j in audit19.live_jobs(work/'workers.tsv')}
    groups = sorted(p.parent for p in (reference/'closures').glob('*/closure.json'))
    if not groups:
        raise ValueError('Reference closure batches are missing')
    for name, job in jobs.items():
        primary = close_ranges.read_ranks(job.log, job.raw, '@'+str(job.ranks), 5040, 1, 19, 11)
        by_rank = {row[0]: row for row in primary}
        complete = set()
        for group in groups:
            if group.name.split('--')[0] != name:
                continue
            old = json.loads((group/'closure.json').read_text())['ranks']
            chunk = [by_rank[t] for t, _ in old]
            if [(r, c) for r, c, _, _ in chunk] != list(map(tuple, old)):
                raise ValueError(f'Fresh pending counts differ from reference at {group.name}')
            if any(t in complete for t, _ in old):
                raise ValueError('Duplicate reference closure rank')
            complete.update(t for t, _ in old)
            dest = out/group.name
            if not (dest/'closure.json').exists():
                close_ranges.close(job.raw, chunk, dest, tools, 19, 11)
            first = json.loads((group/'closure.json').read_text())
            second = json.loads((dest/'closure.json').read_text())
            if any(first[k] != second[k] for k in ('ranks', 'checked_rows', 'steps', 'flex')):
                raise ValueError(f'Fresh closure stage counts differ at {group.name}')
            if (group/'individual.txt').read_bytes() != (dest/'individual.txt').read_bytes():
                raise ValueError(f'Fresh final individual stream differs at {group.name}')
        if complete != set(by_rank):
            raise ValueError(f'Incomplete reference closures at {name}')


def compare_original(work, reference):
    for job in audit19.live_jobs(work/'workers.tsv'):
        actual = work/'proof/workers'/job.name
        original = reference/'workers'/job.name
        if json.loads((original/'raw.json').read_text()) != json.loads((actual/'raw.json').read_text()):
            raise ValueError(f'Raw candidate stream differs at {job.name}')
        with gzip.open(original/'progress.txt.gz', 'rt') as f:
            before = [line.split(' prepare ')[0] for line in f]
        with gzip.open(actual/'progress.txt.gz', 'rt') as f:
            after = [line.split(' prepare ')[0] for line in f]
        if before != after:
            raise ValueError(f'Primary counters differ at {job.name}')
    print('Fresh raw stream hashes, primary counters, closing counts and individual decks match the original.')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('work', type=Path)
    ap.add_argument('phase', nargs='?', default='all', choices=('all', *PHASES))
    ap.add_argument('--workers', type=int, default=2, help='Number of concurrent primary workers')
    ap.add_argument('--reference', type=Path, default=RESULTS/'n19-ordered',
                    help='Preserved run supplying the original rank lists and closure batches')
    ap.add_argument('--schedule', type=Path, help='Use a live worker manifest and freshly grouped closure batches')
    args = ap.parse_args()
    work = args.work.resolve()
    if any(c.isspace() for c in str(work)) or args.workers < 1:
        ap.error('Use a work path without whitespace and a positive worker count')
    work.mkdir(parents=True, exist_ok=True)
    for phase in (PHASES if args.phase == 'all' else [args.phase]):
        if phase == 'build':
            build(work)
            prepare_schedule(work, args.reference, args.schedule)
        elif phase == 'tables':
            tables(work)
        elif phase == 'primary':
            primary(work, args.workers)
        elif phase == 'close':
            close(work, args.reference, not args.schedule)
        elif phase == 'archive':
            subprocess.run([sys.executable, SOURCE/'coverage/audit19.py', '--live', work/'workers.tsv',
                            work/'closures', '--priority', work/'priority.txt', '--domains', work/'domains.csv',
                            '--stream-checker', work/'check-stream', '--save', work/'proof'], check=True)
            if not args.schedule:
                compare_original(work, args.reference)


if __name__ == '__main__':
    main()
