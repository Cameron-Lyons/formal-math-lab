#include "quadrant_code_file.hpp"
#include <iostream>
template <int K> static void run(const char *path) {
  quadrant_codes::File<K>::build(path);
  quadrant_codes::File<K> check(path);
  constexpr unsigned rows = quadrant_codes::factorials<K>()[K];
  // Independent lexicographic unranking and quadratic evaluation of the digits.
  for (unsigned id = 0; id < rows; id += std::max(1u, rows / 100003)) {
    std::array<unsigned, K> p;
    unsigned x = id, avail = (1u << K) - 1;
    constexpr auto f = quadrant_codes::factorials<K>();
    for (unsigned i = 0; i < K; i++) {
      unsigned den = f[K - 1 - i], rank = x / den;
      x %= den;
      unsigned rest = avail;
      for (unsigned j = 0; j < rank; j++)
        rest &= rest - 1;
      p[i] = std::countr_zero(rest);
      avail ^= 1u << p[i];
    }
    unsigned high = 0, low = 0;
    for (unsigned i = 0; i < K; i++)
      for (unsigned j = 0; j < i; j++)
        if (p[i] < p[j])
          high += f[K - 1 - p[i]];
        else
          low += f[p[i]];
    if (check[id].high != high || check[id].low != low)
      throw std::runtime_error(
          "Quadrant file disagrees with explicit prefix code");
  }
  std::cout << "Verified sampled lexicographic row codes in " << rows
            << "-row file " << path << '\n';
}
int main(int argc, char **argv) {
  if (argc != 3)
    throw std::runtime_error("usage: build-quadrant-codes 10|11|12 NEW_FILE");
  switch (std::stoi(argv[1])) {
  case 10:
    run<10>(argv[2]);
    break;
  case 11:
    run<11>(argv[2]);
    break;
  case 12:
    run<12>(argv[2]);
    break;
  default:
    throw std::runtime_error("unsupported cut");
  }
}
