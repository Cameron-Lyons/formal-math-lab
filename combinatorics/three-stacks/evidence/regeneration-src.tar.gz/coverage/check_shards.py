"""Compare a complete partitioned toy join with direct enumeration.

Build sharded_range.cpp using -DCARD_COUNT=10 -DCUT_SIZE=6, then pass the
binary as the only argument. The synthetic masks deliberately leave thousands
of decks unresolved, exercising both the local and the deferred paths.
"""
from itertools import permutations
from pathlib import Path
import struct
import subprocess
import sys
import tempfile


def main(binary):
    n, k = 10, 6
    heads = list(permutations(range(k)))
    head_rank = {p: i for i, p in enumerate(heads)}
    sets = [s for s in range(1 << (n - 1)) if s.bit_count() == n - 1 - k]
    set_rank = {s: i for i, s in enumerate(sets)}

    def bitmask(x):
        return (1 << ((x * 281 + x // 7) % 13)) if x % 19 else 0

    front = [bitmask(i) for i in range(len(heads))]
    tail = [bitmask(i * 151) for i in range(len(sets) * 6)]

    def hit(p):
        normalized = tuple(sorted(p[:k]).index(v) for v in p[:k])
        suffix = p[k:-1]
        order = 0
        for i, v in enumerate(suffix):
            order = order * (i + 1) + sum(w > v for w in suffix[:i])
        values = sum(1 << (v - 1) for v in suffix)
        return bool(front[head_rank[normalized]] & tail[order * len(sets) + set_rank[values]])

    expected = set()
    for positive in permutations(range(1, n)):
        p = positive + (0,)
        if any(a == b + 1 for a, b in zip(p, p[1:])):
            continue
        dual = tuple(n - 1 - p.index(n - 1 - x) for x in range(n))
        if p <= dual and not hit(p) and not hit(dual):
            expected.add(p)

    actual = set()
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        hf, tf = root / 'heads', root / 'tails'
        for path, masks in [(hf, front), (tf, tail)]:
            path.write_bytes(b''.join(struct.pack('=QQ', x, 0) for x in masks))

        def run(*args):
            proc = subprocess.run([binary, *map(str, args)], check=True, capture_output=True, text=True)
            count = 0
            for line in proc.stdout.splitlines():
                kind, count_str, *cards = line.split()
                assert (kind, count_str) == ('Hard', '1')
                p = tuple(int(c) - 1 for c in cards)
                assert p not in actual, p
                actual.add(p)
                count += 1
            return count

        sources = []
        local = 0
        stops = [0, 1, 17, 43, 120, 213, 360, 480, 509, 641, 720]
        for j, (first, end) in enumerate(zip(stops, stops[1:])):
            out = root / f'shard{j}'
            sources.append(out)
            if j == 1:
                source = root / 'physical-slice'
                source.write_bytes(hf.read_bytes()[first*16:end*16])
                local += run('scan-slice', source, tf, first, end, 0, 6, 1, out, 211)
            else:
                local += run('scan', hf, tf, first, end, 0, 6, 1, out, 211, '--prefix-depth', 2)
        remote = 0
        for g in range(4):
            if g % 2:
                source = root / 'physical-dual-slice'
                source.write_bytes(hf.read_bytes()[g*211*16:(g+1)*211*16])
                remote += run('finish-slice', source, tf, g, *sources)
            else:
                remote += run('finish', hf, tf, g, *sources)
        assert local > 0 and remote > 0 and actual == expected, (len(actual), len(expected))
        print(f'All {362880:,} terminal-1 decks accounted for. {local:,} local and {remote:,} deferred residuals agree with direct enumeration.')


if __name__ == '__main__':
    main(sys.argv[1])
