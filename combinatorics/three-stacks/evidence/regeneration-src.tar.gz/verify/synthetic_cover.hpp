// Global lower covers shared by suffix orders. Only actual contained bits are
// selected. A representative sample chooses efficient bits; every resulting
// candidate prefix list is computed exactly from the full transposed table.
#pragma once
namespace synthetic {
using Rows = std::vector<Id>;
using RowPtr = std::shared_ptr<const Rows>;

class Cache {
  struct Policy {
    std::vector<std::uint16_t> priority;
    unsigned sample_size = 0;
  };
  struct Entry {
    RowPtr rows;
    std::list<Mask>::iterator used;
  };
  const TableFile &head;
  const PrefixIndex &index;
  std::array<Mask, 8192> sample{};
  std::unordered_map<Mask, Policy, MaskHash> policies;
  std::unordered_map<Mask, Entry, MaskHash> memo;
  std::list<Mask> lru;
  std::size_t bytes = 0;
  static constexpr std::size_t cache_limit = 128u << 20;
  std::uint64_t hits_ = 0, misses_ = 0;

  const Policy &policy(const Mask &lower) {
    auto [it, fresh] = policies.try_emplace(lower);
    auto &p = it->second;
    if (!fresh)
      return p;
    std::array<Id, columns> frequency{};
    for (const auto &h : sample)
      if (disjoint(h, lower)) {
        ++p.sample_size;
        for (unsigned i = 0; i < h.size(); ++i)
          for (auto bits = h[i]; bits; bits &= bits - 1)
            ++frequency[64 * i + std::countr_zero(bits)];
      }
    if (p.sample_size <= 2)
      return p;
    for (unsigned c : index.sorted_columns)
      if (frequency[c])
        p.priority.push_back(c);
    std::stable_sort(p.priority.begin(), p.priority.end(), [&](auto a, auto b) {
      return frequency[a] > frequency[b];
    });
    return p;
  }
  std::pair<Mask, Id> signature(const Mask &full) {
    if (policies.size() > 100000)
      policies.clear();
    Mask lower{};
    for (unsigned depth = 0; depth < 12; ++depth) {
      const auto &p = policy(lower);
      auto chosen =
          std::find_if(p.priority.begin(), p.priority.end(), [&](unsigned c) {
            return ((full[c / 64] >> (c % 64)) & 1) &&
                   !((lower[c / 64] >> (c % 64)) & 1);
          });
      if (chosen == p.priority.end())
        return {lower, p.sample_size};
      lower[*chosen / 64] |= 1ULL << (*chosen % 64);
    }
    return {lower, policy(lower).sample_size};
  }
  void remember(const Mask &lower, RowPtr rows) {
    auto space = rows->capacity() * sizeof(Id);
    if (space > cache_limit / 3)
      return;
    while (!lru.empty() && bytes + space > cache_limit) {
      auto it = memo.find(lru.back());
      bytes -= it->second.rows->capacity() * sizeof(Id);
      memo.erase(it);
      lru.pop_back();
    }
    lru.push_front(lower);
    memo.emplace(lower, Entry{std::move(rows), lru.begin()});
    bytes += space;
  }
  RowPtr fetch(const Mask &lower) {
    auto it = memo.find(lower);
    if (it == memo.end())
      return {};
    lru.splice(lru.begin(), lru, it->second.used);
    return it->second.rows;
  }
  struct Request {
    Mask lower;
    Id estimate;
    std::vector<std::size_t> minima;
    std::vector<const std::uint64_t *> bitsets;
    std::shared_ptr<Rows> rows;
  };
  // The tile loop lets many synthetic masks reuse the same small window of
  // each column. Sorting and grouping use the full candidate lists after this.
  void fill(std::vector<Request *> &batch) {
    for (auto *req : batch) {
      req->rows = std::make_shared<Rows>();
      req->rows->reserve(std::min<Id>(heads, req->estimate + 32));
      for (unsigned c : index.sorted_columns)
        if ((req->lower[c / 64] >> (c % 64)) & 1)
          req->bitsets.push_back(&index.present[std::size_t(c) * chunks]);
    }
    constexpr unsigned tile = 1024;
    for (unsigned lo = 0; lo < chunks; lo += tile) {
      unsigned hi = std::min(chunks, lo + tile);
      for (auto *req : batch) {
        for (unsigned w = lo; w < hi; ++w) {
          std::uint64_t alive = ~0ULL;
          if (w + 1 == chunks && (heads % 64))
            alive = (1ULL << (heads % 64)) - 1;
          for (auto *c : req->bitsets)
            if (!(alive &= ~c[w]))
              break;
          for (; alive; alive &= alive - 1)
            req->rows->push_back(64 * w + std::countr_zero(alive));
        }
      }
    }
  }

public:
  Cache(const TableFile &file, const PrefixIndex &index)
      : head(file), index(index) {
    // One random prefix from each equal-width band of lexicographic ranks.
    std::mt19937_64 rng(0x5f17016cULL);
    for (std::size_t i = 0; i < sample.size(); ++i) {
      Id lo = std::uint64_t(i) * heads / sample.size();
      Id hi = std::uint64_t(i + 1) * heads / sample.size();
      sample[i] = head[lo + (hi > lo ? rng() % (hi - lo) : 0)];
    }
  }
  std::uint64_t hits() const { return hits_; }
  std::uint64_t misses() const { return misses_; }

  template <class F>
  void enumerate(const std::vector<Mask> &full_masks, F callback) {
    std::vector<Request> work;
    std::unordered_map<Mask, std::size_t, MaskHash> ids;
    for (std::size_t i = 0; i < full_masks.size(); ++i) {
      auto [s, observed] = signature(full_masks[i]);
      if (!subset(s, full_masks[i]))
        throw std::logic_error("Invalid synthetic cover");
      auto [it, fresh] = ids.try_emplace(s, work.size());
      if (fresh)
        work.push_back({s,
                        Id(std::uint64_t(heads) * observed / sample.size()),
                        {},
                        {},
                        {}});
      work[it->second].minima.push_back(i);
    }
    auto use = [&](const Request &req, const Rows &candidates) {
      for (auto i : req.minima) {
        Rows rows;
        for (Id h : candidates)
          if (disjoint(head[h], full_masks[i]))
            rows.push_back(h);
        callback(i, std::move(rows));
      }
    };
    std::vector<Request *> batch;
    std::uint64_t expected = 0;
    auto flush = [&]() {
      if (batch.empty())
        return;
      fill(batch);
      for (auto *r : batch) {
        use(*r, *r->rows);
        remember(r->lower, r->rows);
        r->rows.reset();
      }
      batch.clear();
      expected = 0;
    };
    for (auto &r : work) {
      if (auto rows = fetch(r.lower)) {
        ++hits_;
        use(r, *rows);
        continue;
      }
      ++misses_;
      if (expected + r.estimate > 4000000 || batch.size() >= 128)
        flush();
      expected += r.estimate;
      batch.push_back(&r);
    }
    flush();
  }
};
} // namespace synthetic
