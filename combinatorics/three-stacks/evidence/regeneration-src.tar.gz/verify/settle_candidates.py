"""Replay every positive result and independently refute any negative candidate."""

import argparse
import subprocess
from itertools import combinations
from pathlib import Path

from pysat.solvers import Solver
from check import check, encode, operation_word, pair_table, unpack
from replay import replay


def settle(n, source, words, proof_dir, drat_check, snapshot):
    cards = tuple(range(1, n + 1))
    seen = set()
    if words.exists():
        for line in words.read_text().splitlines():
            *raw, sequence = line.split()
            p = tuple(map(int, raw))
            if tuple(sorted(p)) != cards or not replay(p, sequence):
                raise ValueError("Invalid existing move certificate")
            seen.add(p)
    fixed = pair_table(cards, n * (n - 1))
    a, b, clauses = encode(cards, variable_input=fixed)
    inputs = positives = 0
    with Solver(name="cadical195", bootstrap_with=clauses) as sat, source.open() as src, words.open("a") as out:
        for row in src:
            if snapshot and not row.endswith("\n"):
                break
            tag, status, *raw = row.split()
            p = tuple(map(int, raw))
            if tag != "Hard" or status != "1" or tuple(sorted(p)) != cards:
                raise ValueError("Incorrect candidate row")
            inputs += 1
            if p in seen:
                continue
            assumptions = [fixed[i, j] for i, j in combinations(p, 2)]
            if sat.solve(assumptions=assumptions):
                model = set(sat.get_model())
                orders = [unpack(p, a, model), unpack(p, b, model), list(cards)]
                sequence = operation_word(p, orders)
                if not replay(p, sequence):
                    raise RuntimeError("SAT move certificate failed replay")
                print(*p, sequence, file=out)
                seen.add(p)
                positives += 1
                continue
            proof_dir.mkdir(parents=True, exist_ok=True)
            name = proof_dir / ("counterexample-" + "-".join(map(str, p)))
            if check(p, certificate=name) is not None:
                raise RuntimeError("Fixed-deck and variable-input SAT answers differ")
            output = subprocess.run(
                [drat_check, name.with_suffix(".cnf"), name.with_suffix(".drat")],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True
            ).stdout
            if b"s VERIFIED" not in output:
                raise RuntimeError("Independent DRAT checker did not verify the refutation")
            name.with_suffix(".verified").write_bytes(output)
            print("INDEPENDENTLY VERIFIED UNSORTABLE", *p, name, flush=True)
            return 2
    print(f"Read {inputs} rows, wrote {positives} new replayed schedules, {len(seen)} distinct schedules in {words}.")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("n", type=int)
    parser.add_argument("candidates", type=Path)
    parser.add_argument("words", type=Path)
    parser.add_argument("proof_directory", type=Path)
    parser.add_argument("drat_check")
    parser.add_argument("--snapshot", action="store_true")
    o = parser.parse_args()
    raise SystemExit(settle(o.n, o.candidates, o.words, o.proof_directory, o.drat_check, o.snapshot))
