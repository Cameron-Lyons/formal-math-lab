// Construct the same prefix table, reusing a search whenever the positions
// and roles of parked cards and the relative order of all other cards agree.
#include "prefix.hpp"
#include <chrono>
#include <cstring>
#include <iostream>
#include <limits>

namespace {
using namespace prefix;
constexpr int k=size;
constexpr int pair_slots=k*(k-1)/2;
constexpr int one_count=count/k, two_count=one_count/(k-1);
using Perm=std::array<unsigned char,k>;

bool advance(Perm& word,int length){
    int i=length-2;
    while(i>=0 && word[i]>=word[i+1])--i;
    if(i<0)return false;
    int j=length-1;
    while(word[j]<=word[i])--j;
    std::swap(word[i],word[j]);
    for(int a=i+1,b=length-1;a<b;++a,--b)std::swap(word[a],word[b]);
    return true;
}
struct Parking {
    std::array<layout::Shape,6> shape;
    Parking(int a,int b):shape{{{{a,b},{}},{{a},{b}},{{},{a,b}},
                                 {{b,a},{}},{{b},{a}},{{},{b,a}}}}{}
};
struct Info {
    std::vector<unsigned char> single,pair;
    std::vector<std::array<std::uint32_t,k-1>> removed;
    std::array<std::array<int,k>,k> position_code{}, double_bits{}, single_bits{};
    layout::Shape empty;
    Info():single(std::size_t(one_count)*k),pair(std::size_t(two_count)*pair_slots),removed(one_count) {
        auto shapes=layout::layouts(k);
        for(int a=0;a<k;a++){
            single_bits[a][0]=1+a*(2+3*(k-1));
            for(int b=0;b<k;b++)if(b!=a){
                int j=single_bits[a][0]+2+3*(b-(b>a));
                if(shapes[j].first!=std::vector<int>{a,b})throw std::logic_error("Inconsistent layout positions");
                double_bits[a][b]=j;
            }
        }
        int slot=0;for(int i=0;i<k;i++)for(int j=i+1;j<k;j++)position_code[i][j]=slot++;
    }

    static void removal_ranks(const Perm& word,int len,std::uint32_t* out){
        for(int i=0;i<len;i++){
            unsigned left=((1u<<len)-1)^(1u<<word[i]);
            unsigned r=0,radix=len-1;
            for(int j=0;j<len;j++)if(j!=i){
                unsigned v=word[j];r=r*radix--+std::popcount(left&((1u<<v)-1));left^=1u<<v;
            }
            out[i]=r;
        }
    }
    void cache_singles() {
        Perm p{},word{};
        std::iota(p.begin(),p.end(),0);
        layout::Shape first{{k-1},{}},second{{},{k-1}};
        unsigned rank=0;
        do{
            removal_ranks(p,k-1,removed[rank].data());
            std::copy_n(p.begin(),k-1,word.begin());word[k-1]=k-1;
            for(int i=k-1;i>=0;i--){
                layout::Prepare x{word.data(),k,first},y{word.data(),k,second};
                single[std::size_t(rank)*k+i]=x.test()|(y.test()<<1);
                if(i)std::swap(word[i],word[i-1]);
            }
            rank++;
        }while(advance(p,k-1));
        if(rank!=one_count)throw std::logic_error("Single-card cache incomplete");
    }
    void cache_pairs(){
        Perm p{},word{};
        std::iota(p.begin(),p.end(),0);
        Parking roles(k-2,k-1);
        unsigned rank=0;
        do{
            for(int i=0;i<k-1;i++)for(int j=i+1;j<k;j++){
                int t=0;for(int l=0;l<k;l++)word[l]=l==i?k-2:l==j?k-1:p[t++];
                unsigned mask=0;
                // The two cards cannot end in stack one in reversed input order.
                for(int u:{0,1,2,4,5}){
                    layout::Prepare x{word.data(),k,roles.shape[u]};
                    if(x.test())mask|=1u<<u;
                }
                pair[std::size_t(rank)*pair_slots+position_code[i][j]]=mask;
            }
            rank++;
        }while(advance(p,k-2));
        if(rank!=two_count)throw std::logic_error("Two-card cache incomplete");
    }
    static void insert_bits(Mask& mask,int start,std::uint64_t bits){
        mask[start/64] |= bits<<(start%64);
        if(start%64>=62 && start/64+1<int(mask.size()))mask[start/64+1]|=bits>>(64-start%64);
    }
    Mask generate(const Perm& word)const{
        Mask mask{};
        layout::Prepare test{word.data(),k,empty};
        if(test.test())add(mask,0);
        std::array<std::uint32_t,k> one;
        removal_ranks(word,k,one.data());
        for(int i=0;i<k;i++){
            int a=word[i];
            insert_bits(mask,single_bits[a][0],single[std::size_t(one[i])*k+i]);
            const auto& next=removed[one[i]];
            for(int j=i+1;j<k;j++){
                int b=word[j];
                unsigned bits=pair[std::size_t(next[j-1])*pair_slots+position_code[i][j]];
                insert_bits(mask,double_bits[a][b],bits&7u);
                insert_bits(mask,double_bits[b][a],bits>>3);
            }
        }
        return mask;
    }
};
}
int main(int argc,char**argv){
    if(argc<2||argc>4)throw std::runtime_error("usage: build-prefix output [first-rank past-last-rank]");
    int start=argc>2?std::stoi(argv[2]):0,end=argc>3?std::stoi(argv[3]):count;
    if(start<0||start>=end||end>count)throw std::runtime_error("Invalid prefix rank range");
    Info info;info.cache_pairs();info.cache_singles();
    std::cerr<<"canonical layout caches ready\n";
    auto initial=permutation(start);Perm word;
    std::copy(initial.begin(),initial.end(),word.begin());
    std::ofstream out(argv[1],std::ios::binary);
    if(!out)throw std::runtime_error("Cannot create prefix table");
    int rank=start;
    do{
        auto mask=info.generate(word);
        out.write(reinterpret_cast<const char*>(mask.data()),sizeof(mask));
        if((++rank%one_count)==0)std::cerr<<rank<<" prefixes\n";
        if(rank==end)break;
    }while(advance(word,k));
    if(rank!=end || !out)throw std::runtime_error("Prefix enumeration incomplete");
}
