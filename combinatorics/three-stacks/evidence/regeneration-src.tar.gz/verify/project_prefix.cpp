#include "dual_projection.hpp"
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>
namespace fs = std::filesystem;
template <unsigned K>
void project(bool build, const char *src, const char *cols, const char *out,
             std::uint64_t first) {
  using Map = dual_projection::Map<K>;
  using Mask = typename Map::Mask;
  using File = dual_projection::File<K>;
  std::ifstream full(src, std::ios::binary | std::ios::ate), spec(cols);
  if (!full || !spec)
    throw std::runtime_error("Cannot read source or column list");
  auto len = full.tellg();
  if (len <= 0 || std::uint64_t(len) % sizeof(Mask))
    throw std::runtime_error("Truncated source");
  full.seekg(0);
  auto rows = std::uint64_t(len) / sizeof(Mask);
  int c;
  Mask selected{};
  while (spec >> c) {
    if (c < 0 || unsigned(c) >= Map::columns ||
        ((selected[c / 64] >> (c % 64)) & 1))
      throw std::runtime_error("Incorrect or repeated column in spec");
    selected[c / 64] |= 1ULL << (c % 64);
  }
  if (!spec.eof())
    throw std::runtime_error("Invalid column list");
  Map map(selected);
  constexpr std::uint64_t width = 16384;
  std::vector<Mask> words(width);
  std::vector<std::uint64_t> projected(width);
  if (build) {
    if (fs::exists(out))
      throw std::runtime_error("Choose a new projection output path");
    std::string tmp = std::string(out) + ".tmp." + std::to_string(getpid());
    try {
      std::ofstream f(tmp, std::ios::binary);
      auto h = File::header(first, rows, map);
      f.write(reinterpret_cast<const char *>(h.data()), sizeof(h));
      for (std::uint64_t a = 0; a < rows; a += width) {
        auto cnt = std::min(width, rows - a);
        if (!full.read(reinterpret_cast<char *>(words.data()),
                       cnt * sizeof(Mask)))
          throw std::runtime_error("Reading full prefix failed");
        for (unsigned i = 0; i < cnt; i++)
          projected[i] = map(words[i]);
        if (!f.write(reinterpret_cast<char *>(projected.data()), cnt * 8))
          throw std::runtime_error("Writing projected prefix failed");
      }
      f.close();
      if (!f || link(tmp.c_str(), out) != 0)
        throw std::runtime_error("Could not publish projected prefix");
      fs::remove(tmp);
    } catch (...) {
      fs::remove(tmp);
      throw;
    }
  } else {
    File f(out);
    if (f.first != first || f.count != rows || f.map.selected != selected)
      throw std::runtime_error("Projected header or range mismatch");
    std::vector<unsigned> bits;
    for (unsigned j = 0; j < Map::columns; j++)
      if ((selected[j / 64] >> (j % 64)) & 1)
        bits.push_back(j);
    for (std::uint64_t a = 0; a < rows; a += width) {
      auto cnt = std::min(width, rows - a);
      if (!full.read(reinterpret_cast<char *>(words.data()),
                     cnt * sizeof(Mask)))
        throw std::runtime_error("Reading full prefix failed");
      for (unsigned i = 0; i < cnt; i++) {
        std::uint64_t expected = 0;
        for (unsigned j = 0; j < bits.size(); j++)
          expected |= ((words[i][bits[j] / 64] >> (bits[j] % 64)) & 1ULL) << j;
        if (expected != f[first + a + i])
          throw std::runtime_error(
              "Projection mask differs from direct column extraction");
      }
    }
    std::cout << "Verified all " << rows << " projected prefixes starting at "
              << first << " for " << bits.size() << " columns.\n";
  }
}
int main(int argc, char **argv) {
  if (argc != 7)
    throw std::runtime_error(
        "usage: project-prefix build|verify K FULL_PREFIX_OR_SLICE COLUMN_IDS "
        "PROJECTED_FILE FIRST_RANK");
  std::string mode = argv[1];
  if (mode != "build" && mode != "verify")
    throw std::runtime_error("Unknown mode");
  auto a = std::stoull(argv[6]);
  switch (std::stoul(argv[2])) {
  case 10:
    project<10>(mode == "build", argv[3], argv[4], argv[5], a);
    break;
  case 11:
    project<11>(mode == "build", argv[3], argv[4], argv[5], a);
    break;
  case 12:
    project<12>(mode == "build", argv[3], argv[4], argv[5], a);
    break;
  default:
    throw std::runtime_error("Unsupported cut size");
  }
}
