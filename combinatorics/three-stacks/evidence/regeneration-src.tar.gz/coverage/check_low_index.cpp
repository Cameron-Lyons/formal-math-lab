// Verify the low-order index directly from all eleven-letter words in
// lexicographic order, independently of the quadrant codes file and encoder.
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fcntl.h>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <vector>

int main(int argc, char **argv) {
  if (argc != 2)
    throw std::runtime_error("usage: check_low_index low-index11.bin");
  constexpr std::array<unsigned, 8> fact{1, 1, 2, 6, 24, 120, 720, 5040};
  constexpr unsigned heads = 39916800;
  constexpr size_t bytes = size_t(6) * heads * sizeof(uint32_t);
  int fd = open(argv[1], O_RDONLY);
  struct stat st;
  if (fd < 0 || fstat(fd, &st) || st.st_size != off_t(bytes))
    throw std::runtime_error("Invalid low-order index size");
  const auto *data = static_cast<const uint32_t *>(
      mmap(nullptr, bytes, PROT_READ, MAP_SHARED, fd, 0));
  close(fd);
  if (data == MAP_FAILED)
    throw std::runtime_error("Cannot map index");

  // Each bin is an ascending list of full head ranks. Check all six
  // levels in one lexicographic walk and consume every bin in order.
  std::array<std::vector<const uint32_t *>, 8> cursor;
  for (unsigned b = 2; b <= 7; ++b) {
    cursor[b].resize(fact[b]);
    for (unsigned j = 0; j < fact[b]; ++j)
      cursor[b][j] = data + size_t(b - 2) * heads + j * (heads / fact[b]);
  }
  std::array<unsigned, 11> w{};
  std::iota(w.begin(), w.end(), 0);
  unsigned h = 0;
  do {
    std::array<unsigned char, 11> position;
    for (unsigned i = 0; i < 11; ++i)
      position[w[i]] = i;
    unsigned used = 1u << position[0], code = 0;
    for (unsigned b = 2; b <= 7; ++b) {
      unsigned location = 1u << position[b - 1];
      // Insert the next-largest retained symbol after exactly r of
      // the previously retained symbols in the physical head.
      unsigned r = std::popcount(used & (location - 1));
      code += r * fact[b - 1];
      used |= location;
      if (*cursor[b][code]++ != h)
        throw std::runtime_error("Incorrect low-order index membership");
    }
    ++h;
  } while (std::next_permutation(w.begin(), w.end()));
  if (h != heads)
    throw std::runtime_error("Incomplete head traversal");
  for (unsigned b = 2; b <= 7; ++b) {
    for (unsigned j = 0; j < fact[b]; ++j)
      if (cursor[b][j] !=
          data + size_t(b - 2) * heads + (j + 1) * (heads / fact[b]))
        throw std::runtime_error("Incorrect bin cardinality");
    std::cout << "b " << b << " classes " << fact[b] << " entries in each "
              << heads / fact[b] << '\n';
  }
  munmap(const_cast<uint32_t *>(data), bytes);
  std::cout << "Checked " << size_t(6) * h << " memberships.\n";
}
