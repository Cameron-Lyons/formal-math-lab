#include "tail.hpp"
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>

// Reorder a residual stream by tail shape to reuse later cut computations.
int main(int argc,char**argv){
    if(argc!=3)throw std::runtime_error("usage: group_residuals n original_cut");
    int n=std::stoi(argv[1]),cut=std::stoi(argv[2]),m=n-cut-1;
    if(n<1 || n>21 || m<0 || m>9)throw std::runtime_error("Unsupported shape");
    unsigned orders=1;for(int i=2;i<=m;i++)orders*=i;
    struct Item{std::array<unsigned char,21> p;unsigned set;};
    std::vector<std::vector<Item>> by_order(orders);
    std::ios::sync_with_stdio(false);std::cin.tie(nullptr);
    std::string tag;int flag;
    unsigned long long count=0;
    while(std::cin>>tag>>flag){
        if(tag!="Hard" || flag!=1)throw std::runtime_error("Unexpected input");
        Item item{};unsigned seen=0;
        std::array<int,10> tail{};
        for(int i=0;i<n;i++){
            int v;if(!(std::cin>>v)||v<1||v>n||(seen&(1u<<v)))throw std::runtime_error("Invalid deck");
            seen|=1u<<v;item.p[i]=v;
            if(i>=cut && i<n-1){tail[i-cut]=v;item.set|=1u<<v;}
        }
        if(item.p[n-1]!=1)throw std::runtime_error("Expected terminal 1");
        by_order[tail::rank_order(tail.data(),m)].push_back(item);++count;
    }
    for(auto& group:by_order){
        std::sort(group.begin(),group.end(),[](const Item& a,const Item& b){return a.set<b.set;});
        for(auto& h:group){
            std::cout<<"Hard 1";for(int i=0;i<n;i++)std::cout<<' '<<int(h.p[i]);std::cout<<'\n';
        }
    }
    std::cerr<<"regrouped "<<count<<" residuals\n";
}
