#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 8 ]]; then
  echo 'Usage: close_shard.sh n original_cut inputs outdir recut_A prefix_A recut_B prefix_B' >&2
  exit 2
fi
n=$1
cut=$2
source=$3
dest=$4
first=$5
first_table=$6
second=$7
second_table=$8
mkdir -p "$dest"
"$first" "$first_table" "$n" 1000 "$cut" <"$source" 2>"$dest/first.txt" |
  "$second" "$second_table" "$n" 1000 "$cut" 2>"$dest/second.txt" |
  "$first" "$first_table" "$n" 1000 "$cut" dual 2>"$dest/dual-first.txt" |
  "$second" "$second_table" "$n" 1000 "$cut" dual 2>"$dest/dual-second.txt" >"$dest/individual.txt"
python coverage/settle.py "$n" "$dest/individual.txt" "$dest/words.txt.gz" --certificate "$dest/candidate" >"$dest/schedules.txt"
python coverage/replay.py "$dest/individual.txt" "$dest/words.txt.gz" >"$dest/replay.txt"
