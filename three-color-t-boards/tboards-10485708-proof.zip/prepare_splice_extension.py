"""Generate the packed Lean certificate for the additional row-five splice groups."""
import argparse
import json
import subprocess
from pathlib import Path

from prepare_splice import lean_list, pattern_codes, split_rows

ROOT = Path(__file__).resolve().parent
BATCH_SIZE = 512
BATCHES_PER_MODULE = 4
BUILD_JOBS = 2
BUILD_LANES = 3
# The first thirteen cap templates were certified together. Later signatures
# get separate modules so extending the data cannot invalidate those proofs.
BASE_TEMPLATE_COUNT = 13


def write_module(path, imports, body):
    content = "\n".join("import " + name for name in imports)
    content += """

-- Generated from splice_extension.json by prepare_splice_extension.py.
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TBoards.SpliceExtensionData
open Splice

""" + "\n".join(body) + "\nend TBoards.SpliceExtensionData\n"
    if not path.exists() or path.read_text() != content:
        path.write_text(content)


def total(data):
    return sum(12 * len(g["caps"]) * len(g["tails"]) for g in data["groups"])


def code_list(numbers):
    return "[\n  " + ",\n  ".join(
        ", ".join(map(str, numbers[i:i+3])) for i in range(0, len(numbers), 3)
    ) + "]"


def generate(old, extension, directory):
    if old["cut"] != 5 or extension["cut"] != 5 or not extension["groups"]:
        raise ValueError("the packed certificate requires a row-five cut and at least one new group")
    generated = directory / "SpliceExtensionData"
    generated.mkdir(parents=True, exist_ok=True)
    base_templates, assemblies, markers, names = [], [], [], []
    extra_templates = set()
    modules, last_modules = [], []
    for i, group in enumerate(extension["groups"]):
        pivot, caps, tails = group["pivot"], group["caps"], group["tails"]
        split_rows(pivot, 5, 6)
        if not caps or not tails:
            raise ValueError(f"group {i} has an empty list of pieces")
        upper = pattern_codes(split_rows(caps[0], 0, 5) + [pivot])
        lower = pattern_codes([pivot] + split_rows(tails[0], 6, 10))
        if sorted(upper + lower) != list(range(81)):
            raise ValueError(f"incompatible sample pieces in group {i}")
        template = f"template{i}"
        templates = base_templates if i < BASE_TEMPLATE_COUNT else []
        templates += [
            f"def {template} : Group where", "  k := 5",
            f"  pivot := {lean_list(pivot)}", "  caps := []", "  tails := []",
            f"  upperMask := {sum(1 << c for c in upper)}",
            f"  lowerMask := {sum(1 << c for c in lower)}", "",
        ]
        tails_in_group = []
        pieces = []
        for side, flats, start, stop in [("cap", caps, 0, 5), ("tail", tails, 6, 10)]:
            if flats != sorted(set(flats)):
                raise ValueError(f"{side} pieces in group {i} must be sorted and distinct")
            piece_batches = []
            for offset in range(0, len(flats), BATCH_SIZE):
                chunk = flats[offset:offset+BATCH_SIZE]
                for flat in chunk:
                    split_rows(flat, start, stop)
                name = f"{side}{i}_{len(piece_batches)}"
                codes = code_list([int(flat, 3) for flat in chunk])
                declaration = [
                    f"private def {name}Codes : List Nat := {codes}", "",
                    f"def {name} : Group.Batch {template}.{side}OK :=",
                    f"  Packed.{side}Batch {template} {int(pivot, 3)} rfl (by decide) {name}Codes",
                    "    (by decide +kernel)", "",
                ]
                # Caps are small, and all tail workers can import their definitions.
                if side == "cap":
                    templates.extend(declaration)
                else:
                    tails_in_group.append(declaration)
                piece_batches.append(name)
            pieces.append(lean_list(piece_batches))
        extra_template = None
        if i >= BASE_TEMPLATE_COUNT:
            extra_template = f"SpliceExtensionData.Template{i:03}"
            extra_templates.add(extra_template)
            write_module(generated / f"Template{i:03}.lean", ["SplicePacked"], templates)
        # Each lane is serial even when Lake schedules every target at once.
        previous = last_modules[i-BUILD_LANES] if i >= BUILD_LANES else "SpliceExtensionData.Groups"
        for part, start in enumerate(range(0, len(tails_in_group), BATCHES_PER_MODULE)):
            module = f"Group{i:03}Part{part:03}"
            body = [line for batch in tails_in_group[start:start+BATCHES_PER_MODULE] for line in batch]
            imports = [previous]
            if part == 0 and extra_template:
                imports.append(extra_template)
            write_module(generated / (module + ".lean"), imports, body)
            previous = "SpliceExtensionData." + module
            modules.append(previous)
        last_modules.append(previous)
        name = f"group{i}"
        names.append(name)
        assemblies += [
            f"def {name} := Group.assemble {template} {pieces[0]} {pieces[1]}",
            f"theorem {name}_checked : {name}.Checked := by",
            "  apply Group.assemble_checked <;> decide +kernel",
            f"private theorem {name}_size : {name}.size = {len(caps) * len(tails)} := by decide +kernel", "",
        ]

    write_module(generated / "Groups.lean", ["SplicePacked"], base_templates)
    for path in generated.glob("Template[0-9][0-9][0-9].lean"):
        if "SpliceExtensionData." + path.stem not in extra_templates:
            path.unlink()
    for path in generated.glob("Group[0-9][0-9][0-9]Part[0-9][0-9][0-9].lean"):
        if "SpliceExtensionData." + path.stem not in modules:
            path.unlink()

    for group in old["groups"] + extension["groups"]:
        for cap in group["caps"]:
            marker = cap[0] + group["pivot"] + cap[0]
            if marker not in markers:
                markers.append(marker)
    checked = ", ".join(name + "_checked" for name in names)
    if len(names) > 1:
        checked = "⟨" + checked + "⟩"
    assemblies += [
        f"def groups : List Group := {lean_list(names)}", "",
        "theorem checked : ∀ g ∈ groups, g.Checked := by",
        "  simp only [groups, List.forall_mem_cons, List.not_mem_nil, false_implies,",
        "    implies_true, and_true]", f"  exact {checked}", "",
        f"theorem size_sum : (groups.map Group.size).sum = {total(extension) // 12} := by",
        "  simp only [groups, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil,",
        "    " + ", ".join(name + "_size" for name in names) + "] <;> decide", "",
        "def markers : List (List Nat) := [",
        "  " + ",\n  ".join(lean_list(marker) for marker in markers) + "]",
    ]
    write_module(directory / "SpliceExtensionData.lean", last_modules[-BUILD_LANES:], assemblies)
    count = total(old) + total(extension)
    proof = f"""import SpliceData
import SpliceExtensionData
import SpliceSymmetry

-- Generated from the two splice certificates by prepare_splice_extension.py.
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TBoards
open Splice

/-- At least {count:,} distinct labeled T boards arise from the two splice certificates. -/
theorem at_least_{count} :
    ∃ f : Fin {count} → Board, (∀ i, Valid (f i)) ∧
      (∀ i j, f i = f j → i = j) := by
  apply orbit_lower_bound 5 (SpliceData.groups ++ SpliceExtensionData.groups)
    SpliceExtensionData.markers {count}
  · exact List.forall_mem_append.mpr ⟨SpliceData.checked, SpliceExtensionData.checked⟩
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · rw [List.map_append, List.sum_append, SpliceExtensionData.size_sum]
    decide +kernel

end TBoards

#print axioms TBoards.at_least_{count}
"""
    path = directory / "SpliceExtensionCertificates.lean"
    if not path.exists() or path.read_text() != proof:
        path.write_text(proof)
    return count


def build(directory, groups):
    # Select two group targets at a time when less memory or CPU is available.
    targets = [sorted((directory / "SpliceExtensionData").glob(f"Group{i:03}Part*.lean"))[-1]
               for i in range(len(groups))]
    for i in range(0, len(targets), BUILD_JOBS):
        modules = ["+SpliceExtensionData." + path.stem for path in targets[i:i+BUILD_JOBS]]
        subprocess.run(["lake", "build", *modules], cwd=directory, check=True)
    subprocess.run(["lake", "build", "SpliceExtensionCertificates"], cwd=directory, check=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true", help="build two groups at a time and check the final theorem")
    args = parser.parse_args()
    base = json.loads((ROOT / "splice_witnesses.json").read_text())
    extra = json.loads((ROOT / "splice_extension.json").read_text())
    result = generate(base, extra, ROOT)
    print(f"Generated the combined Lean certificate for {result:,} boards.", flush=True)
    if args.build:
        build(ROOT, extra["groups"])
