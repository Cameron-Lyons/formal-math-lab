// Independent disjoint-mask join for the enumerated end-in-minimum decks. No
// primary join implementation. The tail masks are grouped by identical bits,
// then covered by inclusion-minimal masks. Testing a superset needs only the
// prefix ranks disjoint from its cover.
#include "join_tables.hpp"
#include "quadrant_code_file.hpp"
#include <optional>

struct FastDual {
  quadrant_codes::File<cut> prefix;
  quadrant_codes::Tables<n, cut> tables;
  explicit FastDual(const char *filename) : prefix(filename) {}
};

struct PrefixIndex {
  const std::uint64_t *present;
  const std::array<unsigned, columns> &sorted_columns;
  std::unordered_map<Mask, Id, MaskHash> counts;
  explicit PrefixIndex(const IndexFile &file)
      : present(file.bits()), sorted_columns(file.header()->order) {}
  // For a fixed tail mask, take the complement of the union of its prefix
  // bitsets. Populate a list only for the single minimum currently processed.
  Id failed(const Mask &m, std::vector<Id> *ids = nullptr) const {
    std::array<const std::uint64_t *, columns> active;
    unsigned used = 0;
    for (unsigned c : sorted_columns)
      if ((m[c / 64] >> (c % 64)) & 1)
        active[used++] = &present[std::size_t(c) * chunks];
    Id total = 0;
    for (unsigned w = 0; w < chunks; ++w) {
      std::uint64_t left = ~0ULL;
      if (w == chunks - 1 && (heads % 64))
        left = (1ULL << (heads % 64)) - 1;
      for (unsigned k = 0; k < used && left; ++k)
        left &= ~active[k][w];
      total += std::popcount(left);
      if (ids)
        for (; left; left &= left - 1)
          ids->push_back(w * 64 + std::countr_zero(left));
    }
    return total;
  }
  Id count(const Mask &m) {
    auto [it, fresh] = counts.try_emplace(m, 0);
    if (fresh)
      it->second = failed(m);
    return it->second;
  }
};
#include "synthetic_cover.hpp"

struct Cover {
  Id group, count;
  std::vector<Id> supersets;
  std::shared_ptr<const std::vector<Id>> saved;
};
struct Totals {
  std::uint64_t tested = 0, disjoint = 0, bonds = 0, dual_ok = 0, pending = 0,
                suffixes = 0;
  std::uint64_t unique = 0, minima = 0, references = 0, literal_checks = 0,
                by_symmetry = 0;
  double grouping_seconds = 0, index_seconds = 0, mask_seconds = 0,
         classification_seconds = 0;
};
// Expand only disjoint pairs. One fixed suffix is handled at a time, so a
// descending suffix bond eliminates its whole list of prefixes at once.
void classify(const Group &group, const std::vector<Id> &failed,
              const Coding &codes, const TableFile &head, const TableFile &tail,
              bool canonical, const FastDual *fast, std::ostream *residuals,
              Totals &sum) {
  if (failed.empty())
    return;
  for (Id block : group.blocks) {
    sum.disjoint += failed.size();
    const auto &embedding = codes.labels[block % embeddings];
    const auto &order = codes.orders[block / embeddings];
    Deck p{};
    for (unsigned i = 0; i < ordinary; ++i)
      p[cut + i] = embedding.back[order[i]];
    bool suffix_bond = false;
    for (unsigned i = cut + 1; i < n; ++i)
      if (p[i - 1] == p[i] + 1) {
        suffix_bond = true;
        break;
      }
    if (suffix_bond) {
      sum.bonds += failed.size();
      continue;
    }
    int tail_max =
        embedding.back.back() == n - 1
            ? cut + (std::find(order.begin(), order.end(), ordinary - 1) -
                     order.begin())
            : -1;
    std::optional<quadrant_codes::Tables<n, cut>::Block> accelerated;
    if (fast) {
      std::array<int, cut> labels;
      std::array<int, ordinary + 1> suffix;
      std::copy(embedding.front.begin(), embedding.front.end(), labels.begin());
      std::copy(p.begin() + cut, p.end(), suffix.begin());
      accelerated.emplace(fast->tables, labels.data(), suffix.data());
    }
    for (Id id : failed) {
      const auto &word = codes.prefixes[id];
      if ((word.descending & embedding.consecutive) ||
          embedding.front[word.rank.back()] == p[cut] + 1) {
        ++sum.bonds;
        continue;
      }
      int left = embedding.front[word.rank.front()];
      int right = n - 1 - (tail_max >= 0 ? tail_max : word.max_position);
      if (canonical && left > right) {
        ++sum.by_symmetry;
        continue;
      }
      Id dh, db;
      if (!accelerated || (canonical && left == right)) {
        for (unsigned i = 0; i < cut; ++i)
          p[i] = embedding.front[word.rank[i]];
        Deck dual{};
        for (unsigned i = 0; i < n; ++i)
          dual[n - 1 - p[i]] = n - 1 - i;
        if (canonical && left == right && p > dual) {
          ++sum.by_symmetry;
          continue;
        }
        std::tie(dh, db) = codes.encode(dual);
      } else {
        auto key = accelerated->key(fast->prefix[id], word.rank.data());
        dh = key.head;
        db = key.order * embeddings + codes.set_id[key.set];
      }
      if (!disjoint(head[dh], tail[db])) {
        ++sum.dual_ok;
        continue;
      }
      ++sum.pending;
      if (residuals) {
        if (accelerated && !(canonical && left == right))
          for (unsigned i = 0; i < cut; ++i)
            p[i] = embedding.front[word.rank[i]];
        *residuals << "Hard 1";
        for (int card : p)
          *residuals << ' ' << card + 1;
        *residuals << '\n';
      }
    }
  }
}
void run_shard(const TableFile &head, const TableFile &tail, PrefixIndex &index,
               const Coding &codes, const std::vector<Id> &ranks,
               synthetic::Cache *synthetic_cache, bool canonical,
               const FastDual *fast, std::ostream *residuals, Totals &sum) {
  using Clock = std::chrono::steady_clock;
  auto duration = [](auto start) {
    return std::chrono::duration<double>(Clock::now() - start).count();
  };
  auto phase_start = Clock::now();
  std::vector<Group> groups;
  {
    std::unordered_map<Mask, Id, MaskHash> ids;
    for (Id order : ranks)
      for (Id set = 0; set < embeddings; ++set) {
        Id b = order * embeddings + set;
        if (invalid_high_bits(tail[b]))
          throw std::logic_error("High bits in tail mask");
        auto [it, fresh] = ids.try_emplace(tail[b], groups.size());
        if (fresh)
          groups.push_back({tail[b], weight(tail[b]), {}});
        groups[it->second].blocks.push_back(b);
      }
  }
  std::vector<Id> by_weight(groups.size());
  std::iota(by_weight.begin(), by_weight.end(), 0);
  std::stable_sort(by_weight.begin(), by_weight.end(),
                   [&](Id a, Id b) { return groups[a].bits < groups[b].bits; });
  sum.grouping_seconds += duration(phase_start);
  phase_start = Clock::now();
  std::vector<Cover> minima;
  for (Id g : by_weight) {
    if (std::none_of(minima.begin(), minima.end(), [&](const Cover &m) {
          return subset(groups[m.group].mask, groups[g].mask);
        })) {
      minima.push_back({g, 0, {}, {}});
    }
  }
  if (synthetic_cache) {
    std::vector<Mask> targets;
    for (auto &m : minima)
      targets.push_back(groups[m.group].mask);
    std::size_t saved_bytes = 0;
    synthetic_cache->enumerate(
        targets, [&](std::size_t i, std::vector<Id> &&found) {
          auto &m = minima[i];
          m.count = found.size();
          sum.references += m.count;
          auto bytes = sizeof(Id) * found.capacity();
          if (saved_bytes + bytes < 128U * 1024 * 1024) {
            m.saved = std::make_shared<const std::vector<Id>>(std::move(found));
            saved_bytes += bytes;
          }
        });
  } else
    for (auto &m : minima) {
      m.count = index.count(groups[m.group].mask);
      sum.references += m.count;
    }
  sum.unique += groups.size();
  sum.minima += minima.size();
  std::sort(minima.begin(), minima.end(),
            [](const Cover &a, const Cover &b) { return a.count < b.count; });
  for (Id g : by_weight) {
    auto it = std::find_if(minima.begin(), minima.end(), [&](const Cover &m) {
      return subset(groups[m.group].mask, groups[g].mask);
    });
    if (it == minima.end())
      throw std::logic_error("No minimal tail cover");
    it->supersets.push_back(g);
    sum.suffixes += groups[g].blocks.size();
  }
  sum.index_seconds += duration(phase_start);
  for (const Cover &m : minima) {
    if (!m.count || m.supersets.empty())
      continue;
    phase_start = Clock::now();
    std::vector<Id> local;
    if (!m.saved) {
      local.reserve(m.count);
      if (index.failed(groups[m.group].mask, &local) != m.count)
        throw std::logic_error("Wrong count for minimal tail mask");
    }
    const auto &failed = m.saved ? *m.saved : local;
    constexpr unsigned chunk_rows = 32;
    std::vector<Mask> shared;
    if (m.supersets.size() > 2) {
      shared.resize((failed.size() + chunk_rows - 1) / chunk_rows);
      for (unsigned i = 0; i < failed.size(); ++i) {
        auto &common = shared[i / chunk_rows];
        if (i % chunk_rows == 0)
          common = head[failed[i]];
        else
          for (unsigned j = 0; j < common.size(); ++j)
            common[j] &= head[failed[i]][j];
      }
    }
    struct Helper {
      Mask tail;
      std::vector<Id> rows;
    };
    std::vector<Helper> helpers;
    std::size_t helper_bytes = 0;
    sum.index_seconds += duration(phase_start);
    for (Id g : m.supersets) {
      phase_start = Clock::now();
      const auto &group = groups[g];
      sum.tested += failed.size();
      const std::vector<Id> *candidates = &failed;
      for (auto &helper : helpers)
        if (helper.rows.size() < candidates->size() &&
            subset(helper.tail, group.mask)) {
          candidates = &helper.rows;
          if (candidates->empty())
            break;
        }
      std::vector<Id> found;
      if (candidates == &failed && !shared.empty()) {
        for (unsigned c = 0; c < shared.size(); ++c)
          if (disjoint(group.mask, shared[c])) {
            unsigned stop =
                std::min<std::size_t>((c + 1) * chunk_rows, failed.size());
            sum.literal_checks += stop - c * chunk_rows;
            for (unsigned i = c * chunk_rows; i < stop; ++i)
              if (disjoint(head[failed[i]], group.mask))
                found.push_back(failed[i]);
          }
      } else {
        sum.literal_checks += candidates->size();
        for (Id h : *candidates)
          if (disjoint(head[h], group.mask))
            found.push_back(h);
      }
      sum.mask_seconds += duration(phase_start);
      phase_start = Clock::now();
      classify(group, found, codes, head, tail, canonical, fast, residuals,
               sum);
      sum.classification_seconds += duration(phase_start);
      // A previously settled subset supplies another exact, often much
      // smaller candidate list for subsequent supersets. This cache is local
      // to one minimum and consumes at most 32 MiB of prefix-rank arrays.
      auto bytes = sizeof(Id) * found.capacity();
      if (helpers.size() < 64 && m.supersets.size() > 8 &&
          candidates->size() > 256 && found.size() < candidates->size() / 8 &&
          helper_bytes + bytes < 32U * 1024 * 1024) {
        helper_bytes += bytes;
        helpers.push_back({group.mask, std::move(found)});
      }
    }
  }
}
int main(int argc, char **argv) {
  if (argc == 4 && std::string(argv[1]) == "--pack-tail") {
    TableFile raw(argv[2], blocks);
    packed_tail::build(raw, argv[3]);
    return 0;
  }
  if (argc == 4 && std::string(argv[1]) == "--check-packed") {
    TableFile raw(argv[2], blocks), packed(argv[3], blocks, true);
    if (packed.data)
      throw std::runtime_error("Expected compressed file");
    for (Id i = 0; i < blocks; ++i)
      if (raw[i] != packed[i])
        throw std::runtime_error("Packed mask mismatch");
    std::cerr << "All " << blocks << " packed rows match the source table.\n";
    return 0;
  }
  if (argc == 4 && std::string(argv[1]) == "--build-index") {
    build_and_publish_index(argv[2], argv[3]);
    return 0;
  }
  if (argc < 4 || argc > 12)
    throw std::runtime_error(
        "usage: join-audit head-table tail-table residual-output|- [first stop "
        "stride shard-ranks shared-prefix-index all|canonical synthetic "
        "prefix-code-file]");
  auto first = argc > 4 ? std::stoi(argv[4]) : 0;
  auto stop = argc > 5 ? std::stoi(argv[5]) : int(tail_orders);
  auto stride = argc > 6 ? std::stoi(argv[6]) : 1;
  // A shard has at most ~1.25M tail rows at n=18. The failed-prefix list
  // is released after each minimum and never exceeds 10! 32-bit entries.
  auto shard_size = argc > 7 ? std::stoi(argv[7]) : (n == 17 ? 720 : 64);
  if (first < 0 || stop > int(tail_orders) || first >= stop || stride < 1 ||
      shard_size < 1)
    throw std::runtime_error("Invalid rank range");
  TableFile head(argv[1], heads), tail(argv[2], blocks, true);
  std::ofstream residuals;
  const bool write = std::strcmp(argv[3], "-") != 0;
  if (write) {
    residuals.open(argv[3]);
    if (!residuals)
      throw std::runtime_error("Cannot write residuals");
  }
  auto start = std::chrono::steady_clock::now();
  auto elapsed = [&]() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now() -
                                         start)
        .count();
  };
  IndexFile storage;
  if (argc > 8)
    storage.load(argv[8], head);
  else {
    storage.map(-1, true);
    storage.build(head);
  }
  bool canonical = argc > 9 && std::string(argv[9]) == "canonical";
  if (argc > 9 && !canonical && std::string(argv[9]) != "all")
    throw std::invalid_argument("Unknown symmetry convention");
  std::unique_ptr<synthetic::Cache> synthetic_cache;
  Coding codes(storage.words());
  PrefixIndex index(storage);
  if (argc > 10) {
    if (std::string(argv[10]) != "synthetic")
      throw std::invalid_argument("Unknown cover mode");
    synthetic_cache = std::make_unique<synthetic::Cache>(head, index);
  }
  std::unique_ptr<FastDual> fast;
  if (argc > 11)
    fast = std::make_unique<FastDual>(argv[11]);
  Totals totals;
  std::vector<Id> ranks;
  for (int i = first; i < stop; i += stride) {
    ranks.push_back(i);
    if (int(ranks.size()) != shard_size && i + stride < stop)
      continue;
    run_shard(head, tail, index, codes, ranks, synthetic_cache.get(), canonical,
              fast.get(), write ? &residuals : nullptr, totals);
    std::cerr << "Through rank " << i << " blocks " << totals.suffixes
              << " disjoint " << totals.disjoint << " pending "
              << totals.pending << " elapsed " << elapsed() << "s\n";
    ranks.clear();
  }
  if (synthetic_cache)
    std::cerr << "Synthetic cache hits " << synthetic_cache->hits() << " new "
              << synthetic_cache->misses() << "\n";
  std::uint64_t expected =
      std::uint64_t((stop - first + stride - 1) / stride) * embeddings;
  if (totals.disjoint !=
          totals.bonds + totals.dual_ok + totals.pending + totals.by_symmetry ||
      totals.suffixes != expected || (write && !residuals))
    throw std::logic_error("Incomplete join");
  std::cout
      << "Total tail groups across shards " << totals.unique
      << " minimal groups " << totals.minima << " minimal disjoint references "
      << totals.references << "\n"
      << "Universally enumerated " << totals.suffixes * heads
      << " comparisons\n"
      << "Prefix vs distinct-tail mask comparisons after containment filtering "
      << totals.tested << "\nActual literal mask checks "
      << totals.literal_checks << "\n"
      << "Disjoint " << totals.disjoint << "\nBond " << totals.bonds
      << "\nDual " << totals.dual_ok << "\nBy symmetry " << totals.by_symmetry
      << "\nResidual " << totals.pending
      << "\nGrouping/index/masks/classification seconds "
      << totals.grouping_seconds << " " << totals.index_seconds << " "
      << totals.mask_seconds << " " << totals.classification_seconds << "\n";
}
