// Look up only the prefix configurations offered by the known continuation.
// A failed lookup sends the deck to the next search. Cache both positive and
// negative prefix tests for repeated heads in an insertion neighborhood.
#include "../verify/join_tables.hpp"
#include "../knuth/layout.hpp"
struct Lazy {
  struct Entry {Id id=heads; Mask tried{},good{};};
  std::vector<Entry> slots=std::vector<Entry>(1u<<18);
  TableFile tail;Coding model{nullptr};
  const std::vector<layout::Shape> shapes=layout::layouts(cut);
  explicit Lazy(const char* path):tail(path,blocks,true){}
  bool test(const Deck& p){
    auto [h,b]=model.encode(p);const auto& offers=tail[b];
    auto& e=slots[(h*2654435761u)>>(32-18)];
    if(e.id!=h){e=Entry{};e.id=h;}
    for(unsigned w=0;w<offers.size();w++)if(offers[w]&e.good[w])return true;
    Head order;bool normalized=false;
    for(unsigned w=0;w<offers.size();w++){
      auto check=offers[w]&~e.tried[w];
      while(check){unsigned j=std::countr_zero(check);uint64_t flag=1ull<<j;check^=flag;e.tried[w]|=flag;
        if(!normalized){unsigned values=0;for(unsigned i=0;i<cut;i++)values|=1u<<p[i];
          for(unsigned i=0;i<cut;i++)order[i]=std::popcount(values&((1u<<p[i])-1));normalized=true;}
        layout::Prepare prep{order.data(),cut,shapes[64*w+j]};if(prep.test()){e.good[w]|=flag;return true;}
      }
    }
    return false;
  }
};
int main(int argc,char**argv){if(argc!=2)throw std::runtime_error("usage: probe_join packed-tail");std::ios::sync_with_stdio(false);std::cin.tie(nullptr);
 Lazy check(argv[1]);std::string tag;int flag;uint64_t direct=0,reverse=0,pending=0;
 while(std::cin>>tag>>flag){if(tag!="Hard"||flag!=1)throw std::runtime_error("Invalid row header");Deck p{},d{};unsigned seen=0;
   for(unsigned i=0;i<n;i++){int v;if(!(std::cin>>v)||v<1||v>int(n)||(seen&(1u<<(v-1))))throw std::runtime_error("Invalid card");p[i]=v-1;d[n-v]=n-1-i;seen|=1u<<(v-1);}
   if(p.back())throw std::runtime_error("Missing final minimum");
   if(check.test(p)){++direct;continue;}if(check.test(d)){++reverse;continue;}++pending;std::cout<<"Hard 1";for(auto v:p)std::cout<<' '<<int(v)+1;std::cout<<'\n';
 }std::cerr<<"length "<<n<<" direct "<<direct<<" dual "<<reverse<<" pending "<<pending<<'\n';
}
