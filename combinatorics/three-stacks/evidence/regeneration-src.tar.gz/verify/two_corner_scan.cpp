// Enumerate end-in-minimum decks for which both the deck and its sorting
// dual begin with one of a prescribed set of standardized prefix patterns.
#ifndef CARD_COUNT
#define CARD_COUNT 20
#endif
#include "../knuth/layout.hpp"
#include "bond_spool.hpp"
#include "join_tables.hpp"
#include "stream_tail.hpp"
#include <filesystem>
#include <set>
namespace fs = std::filesystem;
static_assert(n == 20 && cut == 12 && ordinary == 7);
using Small = std::vector<int>;
using Word = std::array<int, cut>;
struct Skeleton {
  Id head;
  std::uint16_t set;
  bool bond;
};
struct HeadInfo {
  Head word;
  Mask mask{};
};
struct Query {
  Id h, b;
};
template <class T> int lex(const T *p, int len) {
  unsigned seen = 0;
  int fact = 1, value = 0;
  for (int i = len - 1; i >= 0; --i) {
    auto bit = 1u << p[i];
    value += fact * std::popcount(seen & (bit - 1));
    fact *= len - i;
    seen |= bit;
  }
  return value;
}
template <class T> Small standard(const T *p, int k) {
  unsigned used = 0;
  for (int i = 0; i < k; i++)
    used |= 1u << p[i];
  Small pattern;
  for (int i = 0; i < k; i++)
    pattern.push_back(std::popcount(used & ((1u << p[i]) - 1)));
  return pattern;
}
std::set<Small> seed_patterns(int k) {
  constexpr std::array<int, 21> known{6,  3, 12, 8,  17, 5,  2, 11, 7,  19, 14,
                                      10, 4, 18, 13, 21, 16, 9, 20, 15, 1};
  std::set<Small> patterns;
  for (unsigned j = 0; j < known.size(); j++) {
    int p[n], dual[n], at = 0;
    for (unsigned i = 0; i < known.size(); i++)
      if (i != j)
        p[at++] = known[i] - 1 - (known[i] > known[j]);
    std::swap(*std::min_element(p, p + n), p[n - 1]);
    for (unsigned i = 0; i < n; i++)
      dual[n - 1 - p[i]] = n - 1 - i;
    patterns.insert(standard(p, k));
    patterns.insert(standard(dual, k));
  }
  return patterns;
}
struct Geometry {
  int k, m;
  const Coding &codec;
  bool evaluate_layouts;
  decltype(layout::layouts(cut)) shapes = layout::layouts(cut);
  std::array<std::vector<std::vector<Skeleton>>, ordinary + 1> buckets;
  std::unordered_map<Id, Id> heads_by_rank;
  std::vector<HeadInfo> head_info;
  std::uint64_t expected = 0, skeletons = 0;
  explicit Geometry(int length, const Coding &coding, bool evaluate = true)
      : k(length), m(n - 1 - k), codec(coding), evaluate_layouts(evaluate) {
    for (unsigned h = 0; h <= ordinary; h++)
      buckets[h].resize(factorial_of(h));
  }
  template <class T> unsigned store_head(Id headrank, const T *p) {
    auto [it, newword] = heads_by_rank.try_emplace(headrank, head_info.size());
    if (newword) {
      auto &info = head_info.emplace_back();
      auto rank = standard(p, cut);
      std::copy(rank.begin(), rank.end(), info.word.begin());
      if (!evaluate_layouts) return it->second;
      for (unsigned c = 0; c < shapes.size(); c++) {
        layout::Prepare pre{info.word.data(), cut, shapes[c]};
        if (pre.test())
          info.mask[c / 64] |= 1ULL << (c % 64);
      }
    }
    return it->second;
  }
  void save(const Word &p, unsigned low, const Small &high, unsigned index) {
    unsigned used = low;
    for (unsigned i = index; i < high.size(); i++)
      used |= 1u << high[i];
    if (std::popcount(used) != int(ordinary))
      throw std::logic_error("Wrong remaining length");
    unsigned head_id = store_head(lex(p.data(), cut), p.data());
    bool bond = false;
    for (unsigned i = 1; i < cut; i++)
      bond |= p[i - 1] == p[i] + 1;
    auto rest = high.size() - index;
    auto order = rest ? lex(high.data() + index, rest) : 0;
    buckets[rest][order].push_back(
        {head_id, std::uint16_t(codec.set_id[used >> 1]), bond});
    ++skeletons;
  }
  void extend(Word &p, unsigned length, unsigned low, const Small &high,
              unsigned used) {
    if (length == cut) {
      save(p, low, high, used);
      return;
    }
    for (auto bits = low; bits; bits &= bits - 1) {
      int v = std::countr_zero(bits);
      p[length] = v;
      extend(p, length + 1, low ^ (1u << v), high, used);
    }
    if (used < high.size()) {
      p[length] = high[used];
      extend(p, length + 1, low, high, used + 1);
    }
  }
  void pair(const Small &a, const Small &b) {
    int ell = b.size(), low_labels = n - 1 - ell;
    for (int common = 0; common <= std::min(k, ell); common++) {
      int head_low = k - common, tail_high = ell - common;
      if (head_low > low_labels || tail_high > m)
        continue;
      Small high_head, high_suffix(tail_high), positions;
      for (int i = 0; i < ell; i++) {
        int v = n - 1 - i;
        if (b[i] < tail_high)
          high_suffix[tail_high - 1 - b[i]] = v;
        else {
          int rank = k - 1 - int(high_head.size());
          positions.push_back(std::find(a.begin(), a.end(), rank) - a.begin());
          high_head.push_back(v);
        }
      }
      bool matches = true;
      int j = 0;
      for (int i = 0; i < ell; i++)
        if (b[i] >= tail_high) {
          int pos = positions[j++], later = 0;
          for (auto x : positions)
            later += x > pos;
          matches &= b[i] == tail_high + later;
        }
      if (!matches)
        continue;
      expected += std::uint64_t(choose(low_labels, head_low)) *
                  choose(m, tail_high) * factorial_of(low_labels - head_low);
      for (unsigned set = 0; set < (1u << low_labels); set++)
        if (std::popcount(set) == head_low) {
          Small labels;
          for (unsigned bits = set; bits; bits &= bits - 1)
            labels.push_back(std::countr_zero(bits) + 1);
          labels.insert(labels.end(), high_head.rbegin(), high_head.rend());
          Word p{};
          for (int i = 0; i < k; i++)
            p[i] = labels[a[i]];
          extend(p, k, (((1u << low_labels) - 1) ^ set) << 1, high_suffix, 0);
        }
    }
  }
};
#include "corner_skeletons.hpp"
std::set<Small> load_patterns(int k, const char *path) {
  std::ifstream source(path);
  std::set<Small> result;
  unsigned id;
  while (source >> id) {
    if (id >= factorial_of(k)) throw std::runtime_error("Pattern identifier out of range");
    Small pattern, available(k);
    std::iota(available.begin(), available.end(), 0);
    for (int i = k - 1; i >= 0; --i) {
      auto slot = id / factorial_of(i);
      id %= factorial_of(i);
      pattern.push_back(available.at(slot));
      available.erase(available.begin() + slot);
    }
    if (!result.insert(pattern).second) throw std::runtime_error("Duplicate pattern identifier");
  }
  if (!source.eof() || result.empty()) throw std::runtime_error("Malformed pattern file");
  return result;
}
int main(int argc, char **argv) {
  const char *head_file = nullptr, *dual_file = nullptr;
  if (argc >= 6 && std::string(argv[argc - 3]) == "--patterns") {
    head_file = argv[argc - 2];
    dual_file = argv[argc - 1];
    argc -= 3;
  }
  bool verify_records = argc >= 5 && std::string(argv[argc - 1]) == "--audit-and-run";
  if (verify_records) --argc;
  bool audit = argc == 3 && std::string(argv[2]) == "--audit-geometry";
  if (!audit && argc != 4 && argc != 5)
    throw std::runtime_error(
        "usage: two-corner-scan K[,DUAL_K] PACKED_TAIL NEW_SPOOL "
        "[NEW_CONTRACTION_SPOOL] [--audit-and-run] [--patterns SOURCE_RANKS DUAL_RANKS], "
        "or K[,DUAL_K] --audit-geometry [--patterns SOURCE_RANKS DUAL_RANKS]");
  std::string dims(argv[1]);
  auto split = dims.find(',');
  int k = std::stoi(dims.substr(0, split));
  int ell = split == std::string::npos ? k : std::stoi(dims.substr(split + 1));
  if (k < 8 || k > 12 || ell < 8 || ell > 12)
    throw std::runtime_error("Choose corner lengths between 8 and 12");
  auto patterns = head_file ? load_patterns(k, head_file) : seed_patterns(k);
  auto dual_patterns = dual_file ? load_patterns(ell, dual_file) : seed_patterns(ell);
  bool symmetric = k == ell && patterns == dual_patterns;
  std::set<Id> first_allowed, dual_allowed;
  for (auto &v : patterns)
    first_allowed.insert(lex(v.data(), k));
  for (auto &v : dual_patterns)
    dual_allowed.insert(lex(v.data(), ell));
  Coding codec(nullptr);
  Geometry geo(k, codec, !audit);
  for (const auto &a : patterns)
    for (const auto &b : dual_patterns)
      geo.pair(a, b);
  std::cerr << "patterns " << patterns.size() << " / " << dual_patterns.size()
            << " skeletons " << geo.skeletons << " full head types "
            << geo.head_info.size() << " expected decks " << geo.expected
            << '\n';
  if (audit) {
    check_geometry(geo, ell, patterns, dual_patterns);
    return 0;
  }
  if (verify_records) check_geometry(geo, ell, patterns, dual_patterns, std::cerr);
  StreamTail tail(argv[2]);
  fs::path dir = argv[3];
  if (!fs::create_directory(dir))
    throw std::runtime_error("Choose a fresh spool directory");
  std::unique_ptr<BondSpool> contractions;
  if (argc == 5)
    contractions = std::make_unique<BondSpool>(argv[4]);
  std::vector<std::ofstream> spool(1 + (tail_orders - 1) / 64);
  std::uint64_t total = 0, dis = 0, bond = 0, mirror = 0, remote = 0,
                second = 0, hard = 0;
  for (Id order = 0; order < tail_orders; order++) {
    tail.select(order);
    auto &tau = codec.orders[order];
    for (unsigned h = 0; h <= ordinary; h++) {
      int high[ordinary], cnt = 0;
      for (auto x : tau)
        if (x >= ordinary - h)
          high[cnt++] = x;
      auto &group = geo.buckets[h][lex(high, cnt)];
      total += group.size();
      for (auto &s : group) {
        auto &info = geo.head_info[s.head];
        if (!disjoint(info.mask, tail.dictionary[tail.ids[s.set]]))
          continue;
        ++dis;
        if (s.bond && !contractions) {
          ++bond;
          continue;
        }
        auto &emb = codec.labels[s.set];
        Deck p{}, dual{};
        p[cut - 1] = emb.front[info.word.back()];
        for (unsigned i = 0; i < ordinary; i++)
          p[cut + i] = emb.back[tau[i]];
        bool tailbond = false;
        for (unsigned i = cut - 1; i < n - 1; i++)
          tailbond |= p[i] == p[i + 1] + 1;
        for (unsigned i = 0; i < cut - 1; i++)
          p[i] = emb.front[info.word[i]];
        if (s.bond || tailbond) {
          if (contractions && !contractions->add(p))
            throw std::logic_error("Flagged descending bond absent");
          ++bond;
          continue;
        }
        for (unsigned i = 0; i < n; i++)
          dual[n - 1 - p[i]] = n - 1 - i;
        if (p > dual &&
            (symmetric || (first_allowed.contains(lex(dual.data(), k)) &&
                          dual_allowed.contains(lex(p.data(), ell))))) {
          ++mirror;
          continue;
        }
        auto [dh, db] = codec.encode(dual);
        auto it = geo.heads_by_rank.find(dh);
        if (symmetric && it == geo.heads_by_rank.end())
          throw std::logic_error("Symmetric family has missing dual head");
        unsigned head_id = it == geo.heads_by_rank.end()
                               ? geo.store_head(dh, dual.data())
                               : it->second;
        auto cl = (db / embeddings) / 64;
        auto &f = spool[cl];
        if (!f.is_open())
          f.open(dir / ("dual-" + std::to_string(cl) + ".bin"),
                 std::ios::binary);
        Query q{head_id, db};
        if (!f.write(reinterpret_cast<char *>(&q), sizeof(q)))
          throw std::runtime_error("Writing deferred dual failed");
        ++remote;
      }
    }
  }
  if (contractions) {
    contractions->finish();
    if (contractions->count != bond)
      throw std::logic_error("Wrong contraction count");
  }
  if (total != geo.expected || dis != bond + mirror + remote)
    throw std::logic_error("Incorrect primary count");
  for (auto &f : spool)
    if (f.is_open()) {
      f.close();
      if (!f)
        throw std::runtime_error("Could not close spool");
    }
  std::cerr << "decks " << total << " direct " << total - dis
            << " descending bond " << bond << " mirror " << mirror
            << " deferred " << remote << '\n';
  std::vector<Query> q(262144);
  for (auto item : fs::directory_iterator(dir)) {
    std::ifstream f(item.path(), std::ios::binary);
    while (f) {
      f.read(reinterpret_cast<char *>(q.data()), sizeof(Query) * q.size());
      if (f.gcount() % sizeof(Query))
        throw std::runtime_error("Truncated dual queries");
      auto count = f.gcount() / sizeof(Query);
      std::sort(q.begin(), q.begin() + count,
                [](Query a, Query b) { return a.b < b.b; });
      for (unsigned j = 0; j < count; j++) {
        auto u = q[j];
        auto &info = geo.head_info.at(u.h);
        if (!disjoint(info.mask, tail[u.b])) {
          ++second;
          continue;
        }
        ++hard;
        const auto &emb = codec.labels[u.b % embeddings];
        const auto &tau = codec.orders[u.b / embeddings];
        std::cout << "Hard 1";
        for (auto x : info.word)
          std::cout << ' ' << int(emb.front[x]) + 1;
        for (auto x : tau)
          std::cout << ' ' << int(emb.back[x]) + 1;
        std::cout << " 1\n";
      }
    }
    if (!f.eof())
      throw std::runtime_error("Reading deferred duals failed");
  }
  if (hard + second != remote || !std::cout)
    throw std::logic_error("Incorrect final counts");
  std::cerr << "dual " << second << " pending " << hard << '\n';
}
