// Grow difficult decks by one card in every nonterminal position and rank.
// The last card stays 1. Group equal resulting decks by their exact cut key.
#include "../verify/join_tables.hpp"
#include <sstream>
#include <filesystem>
#include <functional>
int main(int argc,char**argv){
 bool ranked=argc==4 && std::string(argv[1])=="--ranked";
 if(argc!=1 && argc!=3 && !ranked)throw std::runtime_error("usage: grow [full_prefix full_tail | --ranked temporary-directory minimum-support]");
 std::ios::sync_with_stdio(false);std::cin.tie(nullptr);
 Coding codec(nullptr);
 std::unique_ptr<TableFile> prefix,tail;
 if(argc==3){prefix=std::make_unique<TableFile>(argv[1],heads);tail=std::make_unique<TableFile>(argv[2],blocks,true);}
 std::vector<std::uint64_t> candidates, local;std::filesystem::path buckets;std::vector<std::ofstream> streams;
 constexpr unsigned bucket_count=128;int target=ranked?std::stoi(argv[3]):1;
 if(ranked){buckets=argv[2];if(target<1 || !std::filesystem::create_directory(buckets))throw std::runtime_error("Supply a new output directory");for(unsigned i=0;i<bucket_count;i++){streams.emplace_back(buckets/std::to_string(i),std::ios::binary);if(!streams.back())throw std::runtime_error("Cannot create bucket");}}
 auto uniq=[](auto& v){std::sort(v.begin(),v.end());v.erase(std::unique(v.begin(),v.end()),v.end());};
 std::string line;unsigned long long seeds=0,generated=0;
 while(std::getline(std::cin,line)){
   if(line.empty())continue;
   std::istringstream input(line);std::string tag;input>>tag;
   Deck parent{};int offset=0;
   if(tag=="Hard"){int flag;if(!(input>>flag))throw std::runtime_error("Missing flag");}
   else{int v=std::stoi(tag);if(v<1 || v>=int(n))throw std::runtime_error("Invalid first card");parent[offset++]=v-1;}
   for(;offset<int(n)-1;offset++){int v;if(!(input>>v)||v<1||v>=int(n))throw std::runtime_error("Invalid seed");parent[offset]=v-1;}
   unsigned mask=0;for(unsigned i=0;i<n-1;i++)mask|=1u<<parent[i];
   if(mask!=(1u<<(n-1))-1||parent[n-2]!=0)throw std::runtime_error("Seed must end in its minimum");++seeds;
   local.clear();
   for(unsigned pos=0;pos<n-1;pos++)for(unsigned rank=1;rank<n;rank++){
     Deck deck{},dual{};unsigned old=0;bool bond=false;
     for(unsigned i=0;i<n;i++){
       unsigned x;if(i==pos)x=rank;else{x=parent[old++];x+=x>=rank;}
       deck[i]=x;dual[n-1-x]=n-1-i;if(i && deck[i-1]==x+1)bond=true;
     }
     if(bond)continue;
     if(dual<deck)std::swap(deck,dual);
     auto [head,block]=codec.encode(deck);
     if(prefix){
       auto hit=[](const Mask& a,const Mask& b){for(unsigned w=0;w<a.size();w++)if(a[w]&b[w])return true;return false;};
       if(hit((*prefix)[head],(*tail)[block]))continue;
       auto [dh,db]=codec.encode(dual);if(hit((*prefix)[dh],(*tail)[db]))continue;
     }
     local.push_back(std::uint64_t(block)*heads+head);generated++;
   }
   uniq(local);
   if(ranked){for(auto key:local){auto bucket=(key/heads)*bucket_count/blocks;streams[bucket].write((const char*)&key,sizeof(key));}}
   else candidates.insert(candidates.end(),local.begin(),local.end());
 }
 if(ranked){for(auto& f:streams){f.close();if(!f)throw std::runtime_error("Incomplete bucket write");}}
 std::vector<uint64_t> histogram(2*n+2);uint64_t unique=0,selected=0;
 for(unsigned part=0;part<(ranked?bucket_count:1u);part++){
 if(ranked){auto path=buckets/std::to_string(part);std::ifstream f(path,std::ios::binary|std::ios::ate);auto bytes=f.tellg();if(bytes<0 || bytes%8)throw std::runtime_error("Incomplete bucket");candidates.resize(bytes/8);f.seekg(0);f.read((char*)candidates.data(),bytes);if(!f)throw std::runtime_error("Invalid bucket");}std::sort(candidates.begin(),candidates.end());
 // Prefix permutation names can be decoded directly from their lexicographic rank.
 for(size_t i=0;i<candidates.size();){auto key=candidates[i];size_t j=i+1;while(j<candidates.size()&&candidates[j]==key)++j;int support=j-i;i=j;unique++;if(size_t(support)>=histogram.size())histogram.resize(support+1);histogram[support]++;if(support<target)continue;selected++;Id h=key%heads,b=key/heads;unsigned avail=(1u<<cut)-1,ways=heads;
   const auto& e=codec.labels[b%embeddings];const auto& t=codec.orders[b/embeddings];std::cout<<"Hard 1";
   for(unsigned i=0;i<cut;i++){ways/=cut-i;unsigned ix=h/ways;h%=ways;unsigned bits=avail;while(ix--)bits&=bits-1;unsigned r=std::countr_zero(bits);avail^=1u<<r;std::cout<<' '<<int(e.front[r])+1;}
   for(unsigned r:t)std::cout<<' '<<int(e.back[r])+1;std::cout<<" 1\n";
 }
 if(ranked)std::filesystem::remove(buckets/std::to_string(part));}
 std::cerr<<"seeds "<<seeds<<" visits "<<generated<<" distinct "<<unique<<" selected "<<selected<<'\n';
 if(ranked){std::cerr<<"distinct parents, decks\n";for(unsigned i=1;i<histogram.size();i++)if(histogram[i])std::cerr<<i<<' '<<histogram[i]<<'\n';}
}
