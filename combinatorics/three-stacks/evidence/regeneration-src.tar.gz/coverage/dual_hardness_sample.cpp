// Joint forward/dual difficulty for the sampled pairs failing the first cut.
#define HARDNESS_PROFILE_LIBRARY
#include "hardness_profile.cpp"
int main(int argc, char **argv) {
  using namespace profile;
  if (argc != 4)
    throw std::runtime_error("dual_hardness_sample prefix tail priority-csv");
  TableFile head(argv[1], heads), tailfile(argv[2], blocks, true);
  std::array<unsigned, tail_orders> priority;
  std::ifstream ranks(argv[3]);
  std::string line;
  std::getline(ranks, line);
  unsigned seen = 0;
  while (std::getline(ranks, line)) {
    auto a = line.find(','), b = line.find(',', a + 1);
    int t = std::stoi(line.substr(0, a));
    priority[t] = std::stoul(line.substr(a + 1, b - a - 1));
    ++seen;
  }
  if (seen != tail_orders)
    throw std::runtime_error("Incomplete priorities");
  Coding codec(nullptr);
  std::mt19937 rng(351119);
  auto sampled = sample_heads(&head, rng);
  auto sets = values();
  std::array<unsigned, S> ids;
  for (unsigned j = 0; j < S; ++j) {
    unsigned lo = j * embeddings / S, hi = (j + 1) * embeddings / S;
    ids[j] = lo + rng() % (hi - lo);
  }
  std::cout << "tau,priority,unbonded,unbonded_easier,miss_both,both_easier,"
               "late_miss,late_easier";
  for (unsigned percent : {1, 5, 10, 25, 50})
    std::cout << ",dual_top" << percent << "_unbonded,dual_top" << percent
              << "_both,dual_top" << percent << "_late";
  std::cout << '\n';
  for (unsigned t = 0; t < tail_orders; t++) {
    const auto &tau = codec.orders[t];
    unsigned tag = bond_key(tau);
    bool first_tail = suffix_direct(tau, 1);
    unsigned counters[6]{}, upper[5][3]{};
    for (unsigned j = 0; j < S; j += 2) {
      unsigned s = ids[j];
      const auto &v = sets[s];
      if (v.suffix_bonds & tag)
        continue;
      const auto &m = tailfile[t * embeddings + s];
      unsigned bonds = v.bond[tau[0]];
      unsigned rx = v.below[tau[0]], ry = v.below[tau[1]] + (tau[0] < tau[1]);
      for (unsigned i = 0; i < H; i += 2) {
        const auto &x = sampled[i];
        if ((x.bonds & bonds) || hit(x.mask, m))
          continue;
        Deck d{}, q{};
        for (unsigned z = 0; z < cut; z++)
          d[z] = v.front[x.word[z]];
        for (unsigned z = 0; z < ordinary; z++)
          d[cut + z] = v.back[tau[z]];
        for (unsigned z = 0; z < n; z++)
          q[n - 1 - d[z]] = n - 1 - z;
        auto [dh, db] = codec.encode(q);
        unsigned dual_order = db / embeddings;
        bool easier = priority[dual_order] < priority[t],
             both = !hit(head[dh], tailfile[db]);
        bool not_late = !(first_tail && int(rx) <= x.first_limit) &&
                        int(ry) > x.second_limit[rx];
        counters[0]++;
        counters[1] += easier;
        counters[2] += both;
        counters[3] += both && easier;
        counters[4] += both && not_late;
        counters[5] += both && not_late && easier;
        unsigned z = 0;
        for (unsigned percent : {1, 5, 10, 25, 50}) {
          if (priority[dual_order] >=
              tail_orders - tail_orders * percent / 100) {
            upper[z][0]++;
            upper[z][1] += both;
            upper[z][2] += both && not_late;
          }
          ++z;
        }
      }
    }
    std::cout << t << ',' << priority[t];
    for (auto c : counters)
      std::cout << ',' << c;
    for (auto &kinds : upper)
      for (auto c : kinds)
        std::cout << ',' << c;
    std::cout << '\n';
  }
}
