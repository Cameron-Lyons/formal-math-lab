// Try physically replayed splices at a small fixed collection of head patterns.
// Every positive receives a literal full sorting word and is replayed in full.
#include "../knuth/layout.hpp"
#include "../structural/reach.hpp"
#include "physical_route.hpp"
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <unordered_map>
using Cards = std::array<int, 24>;
struct State {
  layout::Shape shape;
  std::vector<unsigned char> prefix;
};
struct Plan {
  std::vector<State> states;
  std::vector<unsigned> recent;
  unsigned cursor = 0;
};
int rank(const Cards &p, unsigned k) {
  unsigned fresh = 0, fact = 1, r = 0;
  for (int i = k - 1; i >= 0; i--) {
    auto bit = 1u << p[i];
    r += fact * std::popcount(fresh & (bit - 1));
    fresh |= bit;
    fact *= k - i;
  }
  return r;
}
Cards unrank(unsigned id, unsigned k) {
  unsigned fact = 1;
  for (unsigned i = 2; i <= k; i++)
    fact *= i;
  if (id >= fact)
    throw std::runtime_error("Invalid prefix id");
  Cards p{};
  unsigned used = (1u << k) - 1;
  for (unsigned i = 0; i < k; i++) {
    fact /= k - i;
    auto digit = id / fact;
    id %= fact;
    unsigned choices = used;
    while (digit--)
      choices &= choices - 1;
    p[i] = std::countr_zero(choices);
    used ^= 1u << p[i];
  }
  return p;
}
void additional_shapes(std::vector<layout::Shape> &shapes,
                       std::array<int, 4> &values, unsigned used,
                       unsigned length, unsigned depth, unsigned k) {
  if (length >= 3) {
    for (unsigned split = 0; split <= length; split++)
      shapes.push_back({{values.data(), values.data() + split},
                        {values.data() + split, values.data() + length}});
  }
  if (length >= depth || length == values.size())
    return;
  for (unsigned remaining = ((1u << k) - 1) & ~used; remaining;
       remaining &= remaining - 1) {
    auto v = std::countr_zero(remaining);
    values[length] = v;
    additional_shapes(shapes, values, used | (1u << v), length + 1, depth, k);
  }
}
Plan build(unsigned id, unsigned k, unsigned depth) {
  auto word = unrank(id, k);
  std::array<unsigned char, 24> p{};
  std::copy_n(word.begin(), k, p.begin());
  auto shapes = layout::layouts(k);
  std::array<int, 4> values;
  additional_shapes(shapes, values, 0, 0, depth, k);
  Plan plan;
  std::mt19937 gen(177013 + id);
  Word reverse(word.begin(), word.begin() + k);
  std::reverse(reverse.begin(), reverse.end());
  for (auto &shape : shapes) {
    if (!layout::Prepare{p.data(), int(k), shape}.test())
      continue;
    Word committed;
    for (int v = k - 1; v >= 0; v--)
      if (std::find(shape.first.begin(), shape.first.end(), v) ==
              shape.first.end() &&
          std::find(shape.second.begin(), shape.second.end(), v) ==
              shape.second.end())
        committed.push_back(v);
    Route undo({committed, shape.second, shape.first}, reverse);
    if (!undo.find())
      throw std::logic_error("Claimed prefix shape has no literal moves");
    auto &state = plan.states.emplace_back();
    state.shape = shape;
    for (auto i = undo.moves.rbegin(); i != undo.moves.rend(); ++i)
      state.prefix.push_back(3 - *i);
  }
  std::shuffle(plan.states.begin(), plan.states.end(), gen);
  return plan;
}
struct Complete {
  const int *p;
  int n, budget, nodes = 0, len = 0;
  std::array<unsigned char, 96> moves{};
  bool dfs(unsigned A, const reach::Node *B, unsigned C, int in, int target,
           int w) {
    if (++nodes > budget)
      return false;
    while (target < n) {
      int b = B->value, c = C ? std::countr_zero(C) : 31;
      int ai = A ? std::bit_width(A) - 1 : 0, a = A ? p[ai] : 31,
          head = in < n ? p[in] : 31;
      if (c == target) {
        moves[w++] = 4;
        C ^= 1u << target++;
        continue;
      }
      if (b == target) {
        moves[w++] = 3;
        moves[w++] = 4;
        B = B->below;
        target++;
        continue;
      }
      if (a == target) {
        moves[w++] = 2;
        moves[w++] = 3;
        moves[w++] = 4;
        A ^= 1u << ai;
        target++;
        continue;
      }
      if (head == target) {
        for (int op = 1; op <= 4; op++)
          moves[w++] = op;
        in++;
        target++;
        continue;
      }
      if (b + 1 == c && b < n) {
        moves[w++] = 3;
        C |= 1u << b;
        B = B->below;
        continue;
      }
      if (a < n && !(B->forbidden & (1u << a)) &&
          !(C & ((1u << a) - 1) & ~((1u << B->smallest) - 1))) {
        unsigned bad = B->forbidden;
        if (a > B->smallest)
          bad |= ((1u << a) - 1) & ~((2u << B->smallest) - 1);
        reach::Node next{a, std::min(a, B->smallest), bad, B};
        moves[w] = 2;
        if (dfs(A ^ (1u << ai), &next, C, in, target, w + 1))
          return true;
        if (nodes > budget)
          return false;
      }
      if (b < c) {
        moves[w] = 3;
        if (dfs(A, B->below, C | (1u << b), in, target, w + 1))
          return true;
        if (nodes > budget)
          return false;
      }
      if (head == 31)
        return false;
      moves[w++] = 1;
      A |= 1u << in++;
    }
    len = w;
    return true;
  }
};
struct Replay {
  const Cards &p;
  int n, in = 0, out = 0;
  std::array<Cards, 3> s{};
  std::array<int, 3> size{};
  void step(unsigned d) {
    if (d == 1) {
      if (in >= n)
        throw std::logic_error("Overread input");
      s[0][size[0]++] = p[in++];
      return;
    }
    if (d < 2 || d > 4 || !size[d - 2])
      throw std::logic_error("Illegal stack move");
    auto x = s[d - 2][--size[d - 2]];
    if (d == 4) {
      if (x != out++)
        throw std::logic_error("Wrong output card");
    } else
      s[d - 1][size[d - 1]++] = x;
  }
};
bool try_plan(const Cards &original, int n, int k, unsigned trials, int fuel,
              Plan &plan, std::array<unsigned char, 96> *moves = nullptr) {
  if (plan.states.empty())
    return false;
  Cards value = original;
  std::sort(value.begin(), value.begin() + k);
  unsigned occupied = 0;
  for (int i = 0; i < k; i++)
    occupied |= 1u << original[i];
  Cards local = original;
  Complete search{local.data(), n, fuel};
  auto test = [&](unsigned choice) {
    const auto &state = plan.states[choice];
    const auto &s = state.shape;
    unsigned A = 0, C = occupied;
    for (unsigned i = 0; i < s.first.size(); i++) {
      int x = value[s.first[i]];
      local[i] = x;
      A |= 1u << i;
      C ^= 1u << x;
    }
    const reach::Node empty{31, 31, 0, nullptr};
    const reach::Node *top = &empty;
    reach::Node middle[4];
    for (unsigned i = 0; i < s.second.size(); i++) {
      int x = value[s.second[i]];
      middle[i] = {x, std::min(x, top->smallest), 0, top};
      top = middle + i;
      C ^= 1u << x;
    }
    search.nodes = 0;
    if (!search.dfs(A, top, C, k, 0, 0))
      return false;
    Replay physical{original, n};
    for (auto move : state.prefix)
      physical.step(move);
    for (int i = 0; i < search.len; i++)
      physical.step(search.moves[i]);
    if (physical.in != n || physical.out != n ||
        !std::all_of(physical.size.begin(), physical.size.end(),
                     [](int x) { return x == 0; }))
      throw std::logic_error("Incomplete witness");
    if (moves) {
      auto next = std::copy(state.prefix.begin(), state.prefix.end(), moves->begin());
      std::copy_n(search.moves.begin(), search.len, next);
    }
    return true;
  };
  for (unsigned r = 0; r < plan.recent.size(); r++)
    if (test(plan.recent[r])) {
      std::rotate(plan.recent.begin(), plan.recent.begin() + r,
                  plan.recent.begin() + r + 1);
      return true;
    }
  for (unsigned i = 0; i < std::min(trials, unsigned(plan.states.size()));
       i++) {
    auto id = plan.cursor++;
    if (plan.cursor == plan.states.size())
      plan.cursor = 0;
    if (std::find(plan.recent.begin(), plan.recent.end(), id) !=
        plan.recent.end())
      continue;
    if (test(id)) {
      plan.recent.insert(plan.recent.begin(), id);
      if (plan.recent.size() > 8)
        plan.recent.pop_back();
      return true;
    }
  }
  return false;
}
#ifndef FIXED_HEAD_WORDS_LIBRARY
int main(int argc, char **argv) {
  if (argc < 6 || argc > 7)
    throw std::runtime_error(
        "usage: fixed-head-words N K HEAD_IDS TRIALS FUEL [3|4]");
  int n = std::stoi(argv[1]), k = std::stoi(argv[2]),
      trials = std::stoi(argv[4]), fuel = std::stoi(argv[5]);
  if (n < 2 || n > 23 || k < 3 || k > 12 || k >= n || trials < 1 || fuel < 1)
    throw std::runtime_error("Incorrect search dimensions");
  unsigned depth = argc == 7 ? std::stoul(argv[6]) : 3;
  if (depth != 3 && depth != 4)
    throw std::runtime_error("Choose three or four parked cards");
  std::ifstream src(argv[3]);
  std::unordered_map<unsigned, Plan> plans;
  unsigned id;
  while (src >> id) {
    if (!plans.emplace(id, build(id, k, depth)).second)
      throw std::runtime_error("Duplicate head id");
  }
  if (!src.eof() || plans.empty())
    throw std::runtime_error("Invalid head source");
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  Cards p{}, dual{};
  unsigned long long good = 0, open = 0;
  std::string tag;
  int status;
  while (std::cin >> tag >> status) {
    if (tag != "Hard" || status != 1)
      throw std::runtime_error("Incorrect input marker");
    unsigned seen = 0;
    for (int i = 0; i < n; i++) {
      int x;
      if (!(std::cin >> x) || x < 1 || x > n || (seen & (1u << x)))
        throw std::runtime_error("Invalid candidate");
      seen |= 1u << x;
      p[i] = x - 1;
      dual[n - x] = n - 1 - i;
    }
    bool sorted = false;
    for (auto *deck : {&p, &dual}) {
      auto it = plans.find(rank(*deck, k));
      if (it != plans.end() &&
          try_plan(*deck, n, k, trials, fuel, it->second)) {
        sorted = true;
        break;
      }
    }
    if (sorted) {
      good++;
      continue;
    }
    std::cout << "Hard 1";
    for (int i = 0; i < n; i++)
      std::cout << ' ' << p[i] + 1;
    std::cout << '\n';
    open++;
  }
  if (!std::cin.eof() || !std::cout)
    throw std::runtime_error("Incomplete I/O");
  std::cerr << "Fully replayed " << good << " pending " << open << '\n';
}

#endif
