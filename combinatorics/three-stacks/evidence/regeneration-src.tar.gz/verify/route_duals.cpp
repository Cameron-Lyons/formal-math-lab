// Convert explicit deferred decks to sorter-dual head/tail keys grouped by
// tail order, for the bounded-memory continuation reader in lazy_dual.
#include "join_tables.hpp"
#include <filesystem>
namespace fs = std::filesystem;
int main(int argc, char **argv) {
  if (argc != 2)
    throw std::runtime_error("usage: route-duals NEW_SPOOL");
  fs::path dir = argv[1];
  if (!fs::create_directory(dir))
    throw std::runtime_error("Choose a fresh dual spool");
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  Coding codec(nullptr);
  std::vector<std::ofstream> output(1 + (tail_orders - 1) / 64);
  unsigned long long records = 0;
  std::string tag;
  int code;
  while (std::cin >> tag >> code) {
    if (tag != "Hard" || code != 1)
      throw std::runtime_error("Unexpected input marker");
    Deck d{};
    unsigned seen = 0;
    for (unsigned i = 0; i < n; ++i) {
      int x;
      if (!(std::cin >> x) || x < 1 || x > int(n) || (seen & (1u << x)))
        throw std::runtime_error("Invalid deck");
      seen |= 1u << x;
      d[n - x] = n - 1 - i;
    }
    if (d.back() != 0)
      throw std::runtime_error("Expected a final minimum");
    auto [h, b] = codec.encode(d);
    auto group = (b / embeddings) / 64;
    auto &f = output[group];
    if (!f.is_open())
      f.open(dir / ("dual-" + std::to_string(group) + ".bin"),
             std::ios::binary);
    std::array<Id, 2> q{h, b};
    if (!f.write(reinterpret_cast<char *>(q.data()), sizeof(q)))
      throw std::runtime_error("Could not write dual key");
    ++records;
  }
  if (!std::cin.eof())
    throw std::runtime_error("Truncated input");
  for (auto &f : output)
    if (f.is_open()) {
      f.close();
      if (!f)
        throw std::runtime_error("Could not close spool");
    }
  std::cerr << "Routed " << records << " sorting duals.\n";
}
