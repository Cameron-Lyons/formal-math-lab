// Immutable POSIX mapping of the two factorial codes in lexicographic row
// order.
#pragma once
#include "../coverage/quadrant_codes.hpp"
#include <array>
#include <cerrno>
#include <fcntl.h>
#include <numeric>
#include <stdexcept>
#include <string>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

namespace quadrant_codes {
template <int K> class File {
  static_assert(K >= 2 && K <= 12);
  using Header = std::array<std::uint32_t, 4>;
  static constexpr auto rows = factorials<K>()[K];
  static constexpr Header expected{0x444f4351u, 1, K, rows};
  static_assert(sizeof(Prefix) == 8);
  static constexpr size_t bytes =
      sizeof(Header) + size_t(rows) * sizeof(Prefix);
  void *mapping = MAP_FAILED;

public:
  explicit File(const char *path) {
    int fd = open(path, O_RDONLY);
    if (fd < 0)
      throw std::runtime_error("Could not open quadrant code file");
    struct stat st;
    if (fstat(fd, &st) || st.st_size != off_t(bytes)) {
      close(fd);
      throw std::runtime_error("Incorrect quadrant code file size");
    }
    mapping = mmap(nullptr, bytes, PROT_READ, MAP_SHARED, fd, 0);
    close(fd);
    if (mapping == MAP_FAILED)
      throw std::runtime_error("Could not map quadrant code file");
    if (std::memcmp(mapping, expected.data(), sizeof(Header)) != 0) {
      munmap(mapping, bytes);
      throw std::runtime_error("Wrong quadrant code file header");
    }
  }
  File(const File &) = delete;
  File &operator=(const File &) = delete;
  ~File() { munmap(mapping, bytes); }
  const Prefix &operator[](unsigned i) const {
    return reinterpret_cast<const Prefix *>(
        static_cast<const unsigned char *>(mapping) + sizeof(Header))[i];
  }
  static void build(const char *out) {
    std::string tmp = std::string(out) + ".tmp.XXXXXX";
    int fd = mkstemp(tmp.data());
    if (fd < 0)
      throw std::runtime_error("Could not create temporary quadrant code file");
    try {
      auto append = [&](const void *data, size_t n) {
        auto p = static_cast<const char *>(data);
        while (n) {
          ssize_t w = write(fd, p, n);
          if (w < 0 && errno == EINTR)
            continue;
          if (w <= 0)
            throw std::runtime_error("Could not write quadrant code file");
          n -= w;
          p += w;
        }
      };
      append(expected.data(), sizeof(Header));
      std::array<unsigned, K> word;
      std::iota(word.begin(), word.end(), 0);
      std::array<Prefix, 16384> buffer;
      size_t count = 0, used = 0;
      do {
        buffer[used++] = encode_prefix<K>(word.data());
        count++;
        if (used == buffer.size()) {
          append(buffer.data(), sizeof(buffer));
          used = 0;
        }
      } while (std::next_permutation(word.begin(), word.end()));
      append(buffer.data(), used * sizeof(Prefix));
      if (count != rows)
        throw std::runtime_error("Incorrect number of quadrant code rows");
      if (close(fd) != 0) {
        fd = -1;
        throw std::runtime_error("Could not close quadrant code file");
      }
      fd = -1;
      if (link(tmp.c_str(), out) != 0)
        throw std::runtime_error("Could not publish quadrant code file");
      unlink(tmp.c_str());
    } catch (...) {
      if (fd != -1)
        close(fd);
      unlink(tmp.c_str());
      throw;
    }
  }
};
} // namespace quadrant_codes
