"""Close complete suffix ranks from range_join, checking every stage count.

A manifest row has six fields: name, first rank, stop, stride, log, raw rows.
Input rows have fixed byte width because each one lists every card once.
"""
import argparse
import gzip
import json
import math
import os
from pathlib import Path
import subprocess
import tempfile

from replay import validate


def read_ranks(log, raw, first, stop, stride, n, cut):
    expected = math.comb(n - 1, n - cut - 1) * math.factorial(cut)
    width = len('Hard 1 ' + ' '.join(str(i) for i in range(1, n + 1)) + '\n')
    order = (list(map(int, Path(first[1:]).read_text().split())) if isinstance(first, str) and first.startswith("@") else list(range(int(first), stop, stride)))
    end = 0
    rows = []
    for line in log.read_text().splitlines():
        fields = line.split()
        if not fields or fields[0] != 'order':
            continue
        rank = int(fields[1])
        if len(rows) >= len(order):
            break
        if 'pending' not in fields or 'seconds' not in fields:
            break
        if rank != order[len(rows)] or int(fields[3]) != expected:
            raise ValueError(f'Invalid rank or coverage at {log} {rank}')
        missing = int(fields[fields.index('pending') + 1])
        start = end
        end += missing * width
        if raw.stat().st_size < end:
            break
        rows.append((rank, missing, start, end))
    return rows


def close(raw, chunk, output, tools, n, cut):
    first, last = chunk[0], chunk[-1]
    with tempfile.TemporaryDirectory(dir=output.parent) as tmp:
        tmp = Path(tmp)
        current = tmp / 'raw.txt'
        with raw.open('rb') as source, current.open('wb') as dest:
            source.seek(first[2])
            remaining = last[3] - first[2]
            while remaining:
                data = source.read(min(remaining, 2 << 20))
                if not data:
                    raise EOFError('Incomplete candidate records')
                dest.write(data)
                remaining -= len(data)
        pending = sum(row[1] for row in chunk)
        log = {'ranks': [[r, c] for r, c, _, _ in chunk], 'steps': []}
        if 'audit' in tools:
            expected = tmp / 'expected.tsv'
            expected.write_text(''.join(f'{r} {c}\n' for r, c, _, _ in chunk))
            checked = subprocess.run([tools['audit'], current, expected, tools['priority'], str(tools['hard'])], check=True, capture_output=True, text=True)
            if checked.stdout.strip() != f'Checked {pending} distinct, correctly assigned candidates':
                raise ValueError('Unexpected raw candidate audit')
            log['checked_rows'] = pending
        for short, flipped in [(10, False), (9, False), (10, True), (9, True), (8, False), (8, True)]:
            dest = tmp / f'cut{short}-{flipped}.txt'
            command = [tools[f'recut{short}'], tools[f'prefix{short}'], str(n), '1000', str(cut)]
            if flipped:
                command.append('dual')
            with current.open('rb') as inp, dest.open('wb') as out:
                result = subprocess.run(command, stdin=inp, stdout=out, stderr=subprocess.PIPE, check=True, text=True)
            fields = result.stderr.split()
            accepted = int(fields[fields.index('cached') + 1]) + int(fields[fields.index('searched') + 1])
            left = int(fields[fields.index('remaining') + 1])
            if left + accepted != pending:
                raise ValueError(f'Unaccounted inputs for cut {short}')
            log['steps'].append([short, flipped, accepted, left])
            pending = left
            current.unlink()
            current = dest
        flex_out = tmp / 'individual.txt'
        with current.open('rb') as inp, flex_out.open('wb') as out:
            result = subprocess.run([tools['flex'], str(n), '180', '12', '13', '14', '15', '7'], stdin=inp, stdout=out, stderr=subprocess.PIPE, text=True, check=True)
        stats = result.stderr.split()
        left = int(stats[stats.index('pending') + 1])
        accepted = int(stats[stats.index('sorted') + 1])
        if left + accepted != pending:
            raise ValueError('Flexible cut input count does not match')
        log['flex'] = [accepted, left]
        current.unlink()
        cert = output.parent/f'candidate-{first[0]}'
        answer = subprocess.run([tools['python'], str(Path(__file__).with_name('settle.py')), str(n), str(flex_out), str(tmp/'words.txt.gz'), '--certificate', str(cert)], capture_output=True, text=True)
        if answer.returncode:
            cert.with_suffix('.result').write_text(answer.stdout + answer.stderr)
            print(answer.stdout, answer.stderr, flush=True)
            answer.check_returncode()
        with flex_out.open() as inputs, gzip.open(tmp/'words.txt.gz', 'rt') as answers:
            if sum(1 for _ in inputs) != left:
                raise ValueError('SAT input length does not match')
            inputs.seek(0)
            validate(inputs, answers)
        (tmp/'closure.json').write_text(json.dumps(log, separators=(',', ':')) + '\n')
        output.mkdir()
        for part in ['individual.txt', 'words.txt.gz', 'closure.json']:
            os.replace(tmp/part, output/part)
    print(f'{output.name} {len(chunk)} ranks {sum(row[1] for row in chunk)} candidates {left} literal words', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('tools', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--row-target', type=int, default=600000)
    parser.add_argument('--length', type=int, default=19)
    parser.add_argument('--cut', type=int, default=11)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=True, parents=True)
    tools = json.loads(args.tools.read_text())
    jobs = []
    for line in args.manifest.read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        name, start, stop, stride, log, raw = line.split()
        rows = read_ranks(Path(log), Path(raw), start, int(stop), int(stride), args.length, args.cut)
        completed = set()
        for cached in args.output.glob(f'{name}--*/closure.json'):
            completed.update(r for r, _ in json.loads(cached.read_text())['ranks'])
        chunk, count = [], 0
        for row in rows:
            if row[0] in completed:
                if chunk:
                    jobs.append((name, Path(raw), chunk))
                    chunk, count = [], 0
                continue
            chunk.append(row)
            count += row[1]
            if count >= args.row_target or len(chunk) >= 48:
                jobs.append((name, Path(raw), chunk))
                chunk, count = [], 0
        if chunk:
            jobs.append((name, Path(raw), chunk))
    for name, raw, chunk in sorted(jobs, key=lambda job: job[2][0][0]):
        dest = args.output/f'{name}--{chunk[0][0]}-{chunk[-1][0]}'
        close(raw, chunk, dest, tools, args.length, args.cut)


if __name__ == '__main__':
    main()
