#pragma once
#include <array>
#include <cerrno>
#include <cstdio>
#include <filesystem>
#include <stdexcept>
#include <string>
#include <unistd.h>
#include <vector>

// These offers depend only on the suffix order, selected earlier layouts and
// DFS budget. They are identical for every contiguous head interval.
namespace earlier_cache {
struct Header {
  std::uint64_t tag = 0x31464f4b545345ULL, digest = 0;
  unsigned n, k, order, fuel;
  std::array<unsigned, 64> columns;
};
inline std::uint64_t digest(const auto &entries) {
  std::uint64_t value = 1469598103934665603ULL;
  for (auto entry : entries)
    value = (value ^ entry) * 1099511628211ULL;
  return value;
}
class File {
  std::filesystem::path path;
  Header expected;

public:
  File(const std::string &dir, Header header) : expected(header) {
    if (!dir.empty())
      path = std::filesystem::path(dir) /
             ("offers-" + std::to_string(header.n) + "-" +
              std::to_string(header.k) + "-" + std::to_string(header.fuel) +
              "-" + std::to_string(digest(header.columns)) + "-" +
              std::to_string(header.order) + ".bin");
  }
  bool enabled() const { return !path.empty(); }
  bool read(std::vector<std::uint64_t> &rows) const {
    if (!enabled())
      return false;
    FILE *file = fopen(path.c_str(), "rb");
    if (!file) {
      if (errno == ENOENT)
        return false;
      throw std::runtime_error("Cannot read earlier offers");
    }
    Header h{};
    bool ok =
        fread(&h, sizeof(h), 1, file) == 1 && h.tag == expected.tag &&
        h.n == expected.n && h.k == expected.k && h.fuel == expected.fuel &&
        h.order == expected.order && h.columns == expected.columns &&
        fread(rows.data(), sizeof(rows[0]), rows.size(), file) == rows.size() &&
        fgetc(file) == EOF && !ferror(file) && h.digest == digest(rows);
    fclose(file);
    if (!ok)
      throw std::runtime_error("Incorrect cached earlier offers");
    return true;
  }
  void write(const std::vector<std::uint64_t> &rows) const {
    if (!enabled())
      return;
    auto name = path.string() + ".new.XXXXXX";
    int fd = mkstemp(name.data());
    if (fd < 0)
      throw std::runtime_error("Cannot create earlier offers file");
    FILE *file = fdopen(fd, "wb");
    if (!file) {
      close(fd);
      unlink(name.c_str());
      throw std::runtime_error("Cannot open earlier offers file");
    }
    auto h = expected;
    h.digest = digest(rows);
    bool ok =
        fwrite(&h, sizeof(h), 1, file) == 1 &&
        fwrite(rows.data(), sizeof(rows[0]), rows.size(), file) == rows.size();
    if (fclose(file) != 0)
      ok = false;
    if (!ok || rename(name.c_str(), path.c_str()) != 0) {
      unlink(name.c_str());
      throw std::runtime_error("Cannot publish earlier offers");
    }
  }
};
} // namespace earlier_cache
