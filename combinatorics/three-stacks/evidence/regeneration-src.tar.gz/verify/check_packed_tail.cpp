// Independent streaming reader for the packed-tail on-disk format.
// Uses neither the packer's type definitions nor its row-lookup routine.
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <vector>

static std::uint64_t choose(unsigned n, unsigned k) {
  std::uint64_t x = 1;
  for (unsigned i = 1; i <= k; i++)
    x = x * (n + 1 - i) / i;
  return x;
}
static std::uint32_t factorial(unsigned n) {
  unsigned x = 1;
  for (unsigned i = 1; i <= n; i++)
    x *= i;
  return x;
}
template <class T>
static void read_exact(std::ifstream &f, T *ptr, size_t count) {
  f.read(reinterpret_cast<char *>(ptr), sizeof(T) * count);
  if (!f)
    throw std::runtime_error("Unexpected end of input");
}
template <class T> static T read_one(std::ifstream &f) {
  T x;
  read_exact(f, &x, 1);
  return x;
}
static std::uint64_t size(std::ifstream &file) {
  file.seekg(0, std::ios::end);
  auto len = file.tellg();
  if (len < 0)
    throw std::runtime_error("Missing or inaccessible input");
  file.seekg(0);
  return len;
}
int main(int argc, char **argv) {
  if (argc != 5)
    throw std::runtime_error("usage: check-packed-tail N K RAW PACKED");
  unsigned n = std::stoul(argv[1]), k = std::stoul(argv[2]);
  if (k >= n || n - k > 9 || n > 20)
    throw std::runtime_error("Unsupported deck dimensions");
  unsigned m = n - k - 1, words = (1 + 2 * k + 3 * k * (k - 1) + 63) / 64;
  auto sets = choose(n - 1, m), orders = std::uint64_t(factorial(m));
  if (sets > 65535)
    throw std::runtime_error("Value-set count exceeds identifier type");
  std::ifstream raw(argv[3], std::ios::binary),
      packed(argv[4], std::ios::binary);
  auto full = size(raw), compressed = size(packed);
  if (full != orders * sets * words * 8)
    throw std::runtime_error("Wrong raw file length");
  const auto magic = read_one<std::uint64_t>(packed),
             entries = read_one<std::uint64_t>(packed),
             expected_digest = read_one<std::uint64_t>(packed);
  if (magic != 0x314c4941544b5453ULL || read_one<std::uint32_t>(packed) != n ||
      read_one<std::uint32_t>(packed) != k ||
      read_one<std::uint32_t>(packed) != words ||
      read_one<std::uint32_t>(packed) != orders ||
      read_one<std::uint32_t>(packed) != sets)
    throw std::runtime_error("Incompatible packed header");
  packed.seekg(4096);
  std::vector<std::uint64_t> start(orders + 1);
  read_exact(packed, start.data(), start.size());
  auto id_start = 4096 + 8 * start.size(),
       dict_start = (id_start + 2 * orders * sets + 7) & ~std::uint64_t(7);
  if (start.front() != 0 || start.back() != entries ||
      compressed != dict_start + entries * words * 8)
    throw std::runtime_error("Bad dictionary extent");
  std::vector<std::uint64_t> raw_words(sets * words), dictionary(sets * words);
  std::vector<std::uint16_t> ids(sets);
  std::vector<unsigned char> used(sets);
  std::uint64_t digest = 1469598103934665603ULL;
  for (std::uint64_t o = 0; o < orders; ++o) {
    if (start[o + 1] <= start[o] || start[o + 1] - start[o] > sets)
      throw std::runtime_error("Bad per-order dictionary extent");
    auto count = start[o + 1] - start[o];
    packed.seekg(id_start + 2 * o * sets);
    read_exact(packed, ids.data(), sets);
    packed.seekg(dict_start + start[o] * words * 8);
    read_exact(packed, dictionary.data(), count * words);
    read_exact(raw, raw_words.data(), sets * words);
    std::fill_n(used.data(), count, 0);
    for (size_t i = 0; i < sets; ++i) {
      if (ids[i] >= count)
        throw std::runtime_error("Invalid dictionary identifier");
      auto row = raw_words.data() + i * words;
      if (std::memcmp(row, dictionary.data() + ids[i] * words, words * 8) != 0)
        throw std::runtime_error("Raw and packed rows differ");
      used[ids[i]] = 1;
      std::uint64_t h = 1;
      for (unsigned j = 0; j < words; j++)
        h = (h ^ row[j]) * 0x9e3779b97f4a7c15ULL;
      digest = (digest ^ h ^ (h >> 32)) * 1099511628211ULL;
    }
    if (std::find(used.begin(), used.begin() + count, 0) !=
        used.begin() + count)
      throw std::runtime_error("Unreferenced dictionary entry");
  }
  if (digest != expected_digest)
    throw std::runtime_error("Incorrect header digest");
  std::cout << "n=" << n << " k=" << k << ", compared all " << orders * sets
            << " rows of " << words * 8 << " bytes across " << orders
            << " suffix orders and " << sets << " value sets.\n"
            << "Raw bytes " << full << ", packed bytes " << compressed
            << ", dictionary entries " << entries << ", digest " << digest
            << ".\n";
}
