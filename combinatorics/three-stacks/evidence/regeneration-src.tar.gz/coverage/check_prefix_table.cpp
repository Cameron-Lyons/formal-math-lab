#include "prefix.hpp"
#include <iostream>
#include <random>
int main(int argc,char**argv){
    if(argc<2)throw std::runtime_error("usage: check_prefix_table table [samples]");
    unsigned samples=argc>2?std::stoul(argv[2]):100000;
    const auto shapes=layout::layouts(prefix::size);
    std::ifstream file(argv[1],std::ios::binary|std::ios::ate);
    if(!file || file.tellg()!=static_cast<std::streamoff>(prefix::count)*sizeof(prefix::Mask))throw std::runtime_error("Invalid table size");
    std::mt19937_64 rng(634132+prefix::size);
    for(unsigned q=0;q<samples;q++){
        int index=q==0?0:q==1?prefix::count-1:rng()%prefix::count;
        auto word=prefix::permutation(index);
        std::array<unsigned char,prefix::size> p;std::copy(word.begin(),word.end(),p.begin());
        prefix::Mask stored;
        file.seekg(static_cast<std::streamoff>(index)*sizeof(stored));
        file.read(reinterpret_cast<char*>(stored.data()),sizeof(stored));
        for(unsigned j=0;j<shapes.size();j++){
            layout::Prepare check{p.data(),prefix::size,shapes[j]};
            if(bool(prefix::has(stored,j))!=check.test())throw std::logic_error("Layout mismatch");
        }
    }
    std::cout<<"Matched the direct layout search on "<<samples<<" prefix orders of length "<<prefix::size<<"\n";
}
