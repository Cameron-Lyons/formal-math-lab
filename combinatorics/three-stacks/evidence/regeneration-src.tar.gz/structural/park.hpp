#pragma once
#include "reach.hpp"
#include "two.hpp"
#include <algorithm>
#include <bit>
#include <cstdint>
#include <numeric>
#include <vector>
namespace park {
static std::vector<unsigned short> masks[11];
// To leave rank v on stack 2, use the first two stacks to send all
// other prefix cards to stack 3 in decreasing order followed by v.
// Omit the last transfer of v. rank v is measured in complemented input.
inline void compute(int k, const std::vector<char> &table) {
  masks[k].resize(table.size());
  int p[20];
  std::iota(p, p + k, 0);
  do {
    int r = two::rankword(p, k, false), q[20];
    unsigned set = 0;
    for (int v = 0; v < k; v++) {
      for (int i = 0; i < k; i++)
        q[i] = p[i] < v ? p[i] : p[i] == v ? k - 1 : p[i] - 1;
      if (table[two::rankword(q, k, false)])
        set |= 1u << v;
    }
    masks[k][r] = set;
  } while (std::next_permutation(p, p + k));
}
// The input positions of the suffix together with the prefix value set
// determine its entire order. A cached positive therefore reuses precisely
// the same physical sorting problem.
static std::uint64_t cacheKeys[1 << 20];
static unsigned char cacheFlags[1 << 20];
inline std::uint64_t rankSuffix(const int *p, int n) {
  std::uint64_t result = 0;
  unsigned seen = 0;
  for (int i = 0; i < n; i++) {
    result = result * (i + 1) + std::popcount(seen >> p[i]);
    seen |= 1u << p[i];
  }
  return result;
}
inline bool check(const int *p, int n, int k, int compRank, int budget) {
  unsigned members = 0;
  for (int i = 0; i < k; i++)
    members |= 1u << p[i];
  unsigned avail = masks[k][compRank];
  const std::uint64_t base = (rankSuffix(p + k, n - k - 1) << n) + members;
  const reach::Node empty{31, 31, 0, nullptr};
  reach::Search s{p, n, budget};
  for (unsigned rem = members, v = 1u << (k - 1); rem;
       rem &= rem - 1, v >>= 1) {
    if ((avail & v) == 0)
      continue;
    int z = __builtin_ctz(rem);
    const auto key = (base << 5) + z;
    auto hash = key ^ (key >> 27);
    hash *= 0x9e3779b97f4a7c15ull;
    hash ^= hash >> 31;
    auto slot = hash & ((1u << 20) - 1);
    if (cacheFlags[slot] && cacheKeys[slot] == key) {
      if (cacheFlags[slot] == 2)
        return true;
      continue;
    }
    const reach::Node parked{z, z, 0, &empty};
    s.nodes = 0;
    s.exhausted = false;
    bool works = s.dfs(0, &parked, members ^ (1u << z), k, 0);
    cacheKeys[slot] = key;
    cacheFlags[slot] = 1 + works;
    if (works)
      return true;
  }
  return false;
}
} // namespace park
