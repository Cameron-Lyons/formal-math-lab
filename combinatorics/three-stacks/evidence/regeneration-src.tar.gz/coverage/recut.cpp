#include "gaps.hpp"
#include "prefix.hpp"
#include "tail.hpp"
#include <chrono>
#include <iostream>
#include <memory>
#include <unordered_map>

// A join run groups by the relative order of the positive tail after input
// position 10. Moving the cut to 9 creates up to eight extended tail orders at
// n=18. Keep each order's compressed continuations and per-embedding results
// until the original tail order changes. Output only undecided input rows.
namespace {
constexpr int k = prefix::size;
struct Offered {
  gap::Embedding embedding;
  prefix::Mask checked{}, good{};
  Offered(int n, unsigned set) : embedding(k, n, set) {}
};
struct OrderCache {
  gap::Table table;
  std::unordered_map<unsigned, Offered> embeddings;
  OrderCache(int n, int budget, const int *suffix) : table(k, n, budget) {
    table.reset(suffix);
  }
};
class Filter {
  int n, fuel, group_cut;
  int previous = -1;
  const std::vector<prefix::Mask> head;
  const std::vector<layout::Shape> shapes = layout::layouts(k);
  std::unordered_map<int, std::unique_ptr<OrderCache>> orders;

public:
  std::uint64_t unsolved = 0, cached = 0, found = 0;
  Filter(const char *filename, int n, int budget, int group_cut)
      : n(n), fuel(budget), group_cut(group_cut), head(prefix::read(filename)) {
    if (k > group_cut || group_cut >= n || n - k - 1 > 11 || n > 23 ||
        budget < 1)
      throw std::runtime_error("Unsupported cut, length or fuel");
  }
  bool accepts(const int *p) {
    int group = tail::rank_order(p + group_cut, n - group_cut - 1);
    if (group != previous) {
      orders.clear();
      previous = group;
    }
    int order = tail::rank_order(p + k, n - k - 1);
    auto &tail = orders[order];
    if (!tail)
      tail = std::make_unique<OrderCache>(n, fuel, p + k);
    unsigned suffix = 0;
    for (int i = k; i < n - 1; ++i)
      suffix |= 1U << p[i];
    auto [it, _] = tail->embeddings.try_emplace(suffix, n, suffix);
    auto &offers = it->second;
    unsigned left = ((1U << n) - 1) ^ (suffix | 1U);
    int rank = 0;
    for (int i = 0; i < k; ++i) {
      rank = rank * (k - i) + std::popcount(left & ((1U << p[i]) - 1));
      left ^= 1U << p[i];
    }
    const auto &available = head[rank];
    if (prefix::any(available, offers.good)) {
      ++cached;
      return true;
    }
    for (unsigned w = 0; w < available.size(); ++w) {
      unsigned long long unchecked = available[w] & ~offers.checked[w];
      for (; unchecked; unchecked &= unchecked - 1) {
        unsigned id = w * 64 + std::countr_zero(unchecked);
        prefix::add(offers.checked, id);
        if (tail->table.test(offers.embedding, shapes[id])) {
          prefix::add(offers.good, id);
          ++found;
          return true;
        }
      }
    }
    ++unsolved;
    return false;
  }
};
using Deck = std::array<int, 24>;
void output(const Deck &p, int n, int flag) {
  std::cout << "Hard " << flag;
  for (int i = 0; i < n; ++i)
    std::cout << ' ' << p[i] + 1;
  std::cout << '\n';
}
Deck dual(const Deck &p, int n) {
  Deck d{};
  for (int i = 0; i < n; ++i)
    d[n - 1 - p[i]] = n - 1 - i;
  return d;
}
struct Work {
  Deck d;
  std::uint64_t key;
  int flag;
  bool sorted = false;
};
void run_batch(std::vector<Work> &batch, Filter &filter, int n) {
  std::vector<unsigned> indices(batch.size());
  std::iota(indices.begin(), indices.end(), 0);
  std::sort(indices.begin(), indices.end(), [&](unsigned a, unsigned b) {
    return batch[a].key < batch[b].key;
  });
  for (unsigned i : indices)
    batch[i].sorted = filter.accepts(batch[i].d.data());
  for (const auto &item : batch)
    if (!item.sorted)
      output(dual(item.d, n), n, item.flag);
  batch.clear();
}
} // namespace
int main(int argc, char **argv) {
  if (argc < 3 || argc > 6)
    throw std::runtime_error(
        "usage: recut prefix-table n [node-budget [original-cut [dual]]]");
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  int n = std::stoi(argv[2]), fuel = argc > 3 ? std::stoi(argv[3]) : 1000,
      group_cut = argc > 4 ? std::stoi(argv[4]) : 10;
  bool reversed = argc > 5 && std::string(argv[5]) == "dual";
  if (argc > 5 && !reversed)
    throw std::runtime_error("Unknown recut mode");
  Filter filter(argv[1], n, fuel, reversed ? k : group_cut);
  std::vector<Work> batch;
  auto t0 = std::chrono::steady_clock::now();
  std::array<int, 24> p{};
  std::string label;
  int exhausted;
  while (std::cin >> label >> exhausted) {
    if (label != "Hard")
      throw std::runtime_error("Expected a Hard row");
    unsigned seen = 0;
    for (int i = 0; i < n; ++i) {
      int v;
      if (!(std::cin >> v) || v < 1 || v > n || (seen & (1U << (v - 1))))
        throw std::runtime_error("Invalid deck");
      p[i] = v - 1;
      seen |= 1U << (v - 1);
    }
    if (p[n - 1] != 0)
      throw std::runtime_error("Expected final card 1");
    if (reversed) {
      auto d = dual(p, n);
      std::uint64_t rank = tail::rank_order(d.data() + k, n - k - 1);
      unsigned mask = 0;
      for (int i = k; i < n - 1; ++i)
        mask |= 1U << d[i];
      batch.push_back({d, (rank << 32) | mask, exhausted});
      if (batch.size() >= 65536)
        run_batch(batch, filter, n);
    } else if (!filter.accepts(p.data()))
      output(p, n, exhausted);
  }
  if (!batch.empty())
    run_batch(batch, filter, n);
  std::cerr << "cut " << k << " n " << n << " cached " << filter.cached
            << " searched " << filter.found << " remaining " << filter.unsolved
            << " seconds "
            << std::chrono::duration<double>(std::chrono::steady_clock::now() -
                                             t0)
                   .count()
            << '\n';
}
