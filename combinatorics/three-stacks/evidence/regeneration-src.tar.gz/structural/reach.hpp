#pragma once
#include <algorithm>
#include <bit>
#include <cstdint>
namespace reach {
struct Node {
  int value;
  int smallest;
  unsigned forbidden;
  const Node *below;
};
struct Search {
  const int *p;
  int n;
  int allowance;
  int nodes;
  bool exhausted;
  bool dfs(unsigned A, const Node *B, unsigned C, int index, int target) {
    if (++nodes > allowance) {
      exhausted = true;
      return false;
    }
    while (target < n) {
      const int b = B->value;
      const int c = C ? __builtin_ctz(C) : 31;
      const int ai = A ? 31 - __builtin_clz(A) : 0;
      const int a = A ? p[ai] : 31;
      const int in = index < n ? p[index] : 31;
      if (c == target) {
        C ^= 1u << target++;
        continue;
      }
      if (b == target) {
        B = B->below;
        target++;
        continue;
      }
      if (a == target) {
        A ^= 1u << ai;
        target++;
        continue;
      }
      if (in == target) {
        index++;
        target++;
        continue;
      }
      if (b + 1 == c && b < n) {
        C |= 1u << b;
        B = B->below;
        continue;
      }
      const bool send = a < n && !(B->forbidden & (1u << a)) &&
                        !(C & ((1u << a) - 1) & ~((1u << B->smallest) - 1));
      if (send) {
        unsigned bad = B->forbidden;
        if (a > B->smallest)
          bad |= ((1u << a) - 1) & ~((2u << B->smallest) - 1);
        const Node next{a, std::min(a, B->smallest), bad, B};
        if (dfs(A ^ (1u << ai), &next, C, index, target))
          return true;
        if (exhausted)
          return false;
      }
      if (b < c) {
        if (dfs(A, B->below, C | (1u << b), index, target))
          return true;
        if (exhausted)
          return false;
      }
      if (in == 31)
        return false;
      A |= 1u << index++;
    }
    return true;
  }
  bool test(int initial, unsigned C) {
    const Node empty{31, 31, 0, nullptr};
    nodes = 0;
    exhausted = false;
    return dfs(0, &empty, C, initial, 0);
  }
};
} // namespace reach
