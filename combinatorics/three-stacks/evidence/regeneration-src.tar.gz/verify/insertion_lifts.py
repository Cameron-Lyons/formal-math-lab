"""Lift a known sort to all feasible insertion positions in its two intermediate orders."""
from check import operation_word
from replay import replay

def exits(deck, word):
    if len(word)!=4*len(deck) or not replay(deck,word):
        raise ValueError('Invalid base sorting word')
    stacks=[list(reversed(deck)),[],[],[],[]]
    orders=[[],[],[],[]]
    for digit in word:
        i=int(digit)-1
        v=stacks[i].pop()
        stacks[i+1].append(v);orders[i].append(v)
    return tuple(orders[1]),tuple(orders[2])

def insert(word, i):
    return word[:i]+(0,)+word[i:]

def possible(source, output):
    stack=[];read=0
    for v in output:
        while (not stack or stack[-1]!=v) and read<len(source):
            stack.append(source[read]);read+=1
        if not stack or stack.pop()!=v:return False
    return True

def compatible(source, dest):
    return [[j for j,y in enumerate(dest) if possible(x,y)] for x in source]

def lifts(parent, first, second, needed):
    """Return literal certificates for canonical, ending-in-minimum extensions."""
    p=tuple(parent);n=len(p)+1
    levels=[[insert(order,i) for i in range(n)] for order in (p,tuple(first),tuple(second),tuple(sorted(p)))]
    lower,middle,upper=(compatible(a,b) for a,b in zip(levels,levels[1:]))
    found={}
    for i in range(n-1):
        left=levels[0][i];placed={}
        for j in lower[i]:
            for k in middle[j]:
                for r in upper[k]:
                    if r:placed.setdefault(r,(j,k))
        for rank,(j,k) in placed.items():
            card=rank+1
            def relabel(order):return tuple(card if v==0 else v+(v>=card) for v in order)
            deck=relabel(left);inverse=bytearray(n)
            for pos,v in enumerate(deck):inverse[n-v]=n-pos
            direct=bytes(deck);key=min(direct,bytes(inverse))
            if key not in needed or key in found:continue
            orders=[relabel(levels[1][j]),relabel(levels[2][k]),tuple(range(1,n+1))]
            word=operation_word(deck,orders)
            if key!=direct:word=''.join(str(5-int(x)) for x in reversed(word))
            if not replay(key,word):raise ValueError('Insertion witness did not replay')
            found[key]=word
    return found

def cover(parents, words, requested, trials=6):
    from check import check
    from extend_hard19 import normalized
    remaining=set(requested);result={}
    for p in parents:
        sources={}
        for card in range(2,len(p)+2):
            lifted=bytes(v+(v>=card) for v in p)
            for i in range(len(p)):
                source=lifted[:i]+bytes([card])+lifted[i:]
                key=normalized(source)
                if key in remaining:sources[key]=(source,card)
        if not sources:continue
        good=lifts(p,*exits(p,words[p]),sources)
        result.update(good);remaining.difference_update(good)
        failed=set()
        for turn in range(trials):
            todo=sorted((sources.keys()&remaining)-failed)
            if not todo:break
            key=todo[(turn*73+len(todo)//2)%len(todo)]
            source,x=sources[key]
            witness=check(source)
            if witness is None:
                failed.add(key)
                continue
            def remove(order):return tuple(v-(v>x) for v in order if v!=x)
            a,b=exits(source,witness)
            good=lifts(p,remove(a),remove(b),sources.keys()&remaining)
            if key not in good:raise ValueError('Restricted sorting word did not lift back to its source')
            result.update(good);remaining.difference_update(good)
    return result
