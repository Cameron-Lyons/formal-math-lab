"""Verify the independent two-corner count and the four final sorting words."""
import gzip
from math import factorial
from pathlib import Path
from corner_counts import count_patterns
from replay import replay

root = Path(__file__).resolve().parent/'published'
heads = set()
for line in (root/'weak20-heads11.txt').read_text().splitlines():
    rank = int(line)
    free = list(range(11))
    word = []
    while free:
        i, rank = divmod(rank, factorial(len(free)-1))
        word.append(free.pop(i))
    heads.add(tuple(word))
if len(heads) != 144:
    raise ValueError('Incorrect number of heads')
count = count_patterns(11, 11, heads, heads)[2]
stats = (root/'weak20-counters.txt').read_text().splitlines()
w = stats[0].split()
if int(w[1]) != len(heads) or int(w[3]) != count:
    raise ValueError('Physical enumeration and independent count disagree')
remaining = int(w[5])
for s in stats[1:4]:
    label, verb, solved, pending, left = s.split()
    if (label, verb, pending) != ('Fully', 'replayed', 'pending') or int(solved)+int(left)!=remaining:
        raise ValueError('Physical replay totals disagree')
    remaining=int(left)
_, solved, _, left=stats[4].split()
if int(left)+int(solved)!=remaining:
    raise ValueError('Flexible cut totals disagree')
found=set()
with gzip.open(root/'weak20-last-words.gz', 'rt') as words:
    for line in words:
        *cards, moves = line.split()
        deck = tuple(map(int, cards))
        if len(moves)!=80 or sorted(deck)!=list(range(1,21)) or deck in found or not replay(deck,moves):
            raise ValueError('Invalid individual certificate')
        dual=[0]*20
        for i,v in enumerate(deck):
            dual[20-v]=20-i
        for form in (deck,dual):
            values=sorted(form[:11])
            if tuple(values.index(x) for x in form[:11]) not in heads:
                raise ValueError('Final deck outside the family')
        found.add(deck)
if len(found)!=int(left):
    raise ValueError('Missing final certificate')
print(f'{count:,} weak-corner inputs accounted for; {len(found)} individual schedules replayed.')
