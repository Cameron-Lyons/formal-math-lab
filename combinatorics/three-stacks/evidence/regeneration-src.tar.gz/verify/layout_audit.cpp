// Independent literal-move audit of the prefix layout and two-stack tail
// tables.
#include "../coverage/tail.hpp"
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>
#include <vector>

#include "physical_route.hpp"

std::uint64_t audit_prefix(const Word &deck) {
  const int n = deck.size();
  std::vector<unsigned char> bytes(deck.begin(), deck.end());
  Word reverse_input(deck.rbegin(), deck.rend());
  std::uint64_t checked = 0;
  for (const auto &shape : layout::layouts(n)) {
    if (!layout::Prepare{bytes.data(), n, shape}.test())
      continue;
    Word committed;
    for (int card = n - 1; card >= 0; --card)
      if (std::count(shape.first.begin(), shape.first.end(), card) == 0 &&
          std::count(shape.second.begin(), shape.second.end(), card) == 0)
        committed.push_back(card);
    // Undo the prefix physically, obtaining a word. Then run the inverse
    // word forward from the real input and compare all three exact piles.
    Route undo({committed, shape.second, shape.first}, reverse_input);
    if (!undo.find())
      throw std::logic_error("Unreachable accepted prefix layout");
    std::array<Word, 4> actual;
    actual[0] = reverse_input;
    for (auto it = undo.moves.rbegin(); it != undo.moves.rend(); ++it) {
      int source = 2 - *it;
      move(actual[source], actual[source + 1]);
    }
    if (!actual[0].empty() || actual[1] != shape.first ||
        actual[2] != shape.second || actual[3] != committed)
      throw std::logic_error("Prefix layout failed physical replay");
    ++checked;
  }
  return checked;
}

void audit_tail(int ordinary) {
  const tail::Table table(10, 11 + ordinary);
  Word perm(ordinary);
  std::iota(perm.begin(), perm.end(), 0);
  std::uint64_t checked = 0, positive = 0;
  do {
    // Use actual active card labels, not the relabeling or rank arguments
    // used by the table builder. Reconstruct the all-important gaps from
    // the literal values, then exercise the public lookup interface.
    for (int role = tail::empty; role <= tail::both_second; ++role) {
      int parked = (role == tail::empty ? 0 : role <= tail::second ? 1 : 2);
      int count = 1 + ordinary + parked;
      for (int a = 1; a < (parked ? count : 2); ++a) {
        for (int b = 1; b < (parked == 2 ? count : 2); ++b) {
          if (parked == 2 && a == b)
            continue;
          layout::Shape shape;
          switch (role) {
          case tail::empty:
            break;
          case tail::first:
            shape.first = {a};
            break;
          case tail::second:
            shape.second = {a};
            break;
          case tail::both_first:
            shape.first = {a, b};
            break;
          case tail::split:
            shape.first = {a};
            shape.second = {b};
            break;
          case tail::both_second:
            shape.second = {a, b};
            break;
          }
          Word loose, target(count);
          for (int value = 1; value < count; ++value)
            if (!(parked && value == a) && !(parked == 2 && value == b))
              loose.push_back(value);
          Word input;
          for (int j : perm)
            input.push_back(loose[j]);
          input.push_back(0);
          std::array<int, 32> gaps{};
          for (int i = 0; i < count; ++i)
            gaps[i] = std::count_if(loose.begin(), loose.end(),
                                    [i](int x) { return x < i; });
          int row = tail::rank_order(input.data(), ordinary);
          int col = table.column(shape, gaps.data());
          bool expected = table.row(row)[col];
          Piles actual{Word(input.rbegin(), input.rend()), shape.first,
                       shape.second};
          std::iota(target.begin(), target.end(), 0);
          Route route(actual, target);
          if (route.find() != expected)
            throw std::logic_error("Tail table disagrees with physical solver");
          if (expected) {
            Word emitted;
            for (int src : route.moves) {
              if (src < 2)
                move(actual[src], actual[src + 1]);
              else
                move(actual[src], emitted);
            }
            if (emitted != target || !actual[0].empty() || !actual[1].empty() ||
                !actual[2].empty())
              throw std::logic_error("Tail word failed replay");
            ++positive;
          }
          ++checked;
        }
      }
    }
  } while (std::next_permutation(perm.begin(), perm.end()));
  std::cout << "Tail ordinary " << ordinary << " checked " << checked
            << " positive replays " << positive << "\n";
}

int main() {
  for (int n = 1; n <= 7; ++n) {
    std::uint64_t positives = 0, words = 0;
    Word deck(n);
    std::iota(deck.begin(), deck.end(), 0);
    do {
      positives += audit_prefix(deck);
      ++words;
    } while (std::next_permutation(deck.begin(), deck.end()));
    std::cout << "Prefix length " << n << " words " << words
              << " accepted layouts replayed " << positives << std::endl;
  }
  Word sample(10);
  std::iota(sample.begin(), sample.end(), 0);
  std::mt19937 rng(314159265);
  std::uint64_t positives = 0;
  for (int i = 0; i < 512; ++i) {
    std::shuffle(sample.begin(), sample.end(), rng);
    positives += audit_prefix(sample);
  }
  std::cout << "Prefix length 10 sampled 512 accepted layouts replayed "
            << positives << std::endl;
  for (int ordinary = 0; ordinary <= 6; ++ordinary)
    audit_tail(ordinary);
}
