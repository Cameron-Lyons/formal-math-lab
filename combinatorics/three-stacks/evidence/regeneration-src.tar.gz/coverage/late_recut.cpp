// Filter existing residual rows with the same two-stack split as range_join.
#include "late_split.hpp"
#include <iostream>
#include <stdexcept>
#include <string>
#ifndef CARD_COUNT
#define CARD_COUNT 19
#endif
namespace {
constexpr unsigned n = CARD_COUNT, k = n - 8;
using Deck = std::array<unsigned char, n>;
unsigned head_rank(const Deck &p) {
  unsigned left = 0, rank = 0;
  for (unsigned i = 0; i < k; i++)
    left |= 1u << p[i];
  for (unsigned i = 0; i < k; i++) {
    auto bit = 1u << p[i];
    rank = rank * (k - i) + std::popcount(left & (bit - 1));
    left ^= bit;
  }
  return rank;
}
} // namespace
int main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  late_split::Filter<n, k> late;
  std::string tag;
  int flag;
  Deck p{}, dual{};
  uint64_t direct = 0, reflected = 0, remainder = 0;
  while (std::cin >> tag >> flag) {
    if (tag != "Hard")
      throw std::runtime_error("Malformed residual row");
    unsigned used = 0;
    for (unsigned i = 0; i < n; i++) {
      int x;
      if (!(std::cin >> x) || x < 1 || x > int(n) || (used & (1u << (x - 1))))
        throw std::runtime_error("Invalid permutation");
      p[i] = x - 1;
      used |= 1u << p[i];
      dual[n - x] = n - 1 - i;
    }
    if (p.back() != 0)
      throw std::runtime_error("Expected a final 1");
    if (late.accepts(p, head_rank(p))) {
      ++direct;
      continue;
    }
    if (late.accepts(dual, head_rank(dual))) {
      ++reflected;
      continue;
    }
    ++remainder;
    std::cout << "Hard " << flag;
    for (unsigned x : p)
      std::cout << ' ' << x + 1;
    std::cout << '\n';
  }
  std::cerr << "direct " << direct << " dual " << reflected << " pending "
            << remainder << " searches " << late.searches << '\n';
}
