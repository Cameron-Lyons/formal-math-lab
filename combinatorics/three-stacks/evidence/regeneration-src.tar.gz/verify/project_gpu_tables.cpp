// Produce raw uint64 vectors for the GPU joiner's direct prefix rows and
// dictionary tail rows, in exactly the layout numbering of the source tables.
#include "dual_projection.hpp"
#include "join_tables.hpp"
#include <filesystem>
namespace fs = std::filesystem;
using Projector = dual_projection::Map<cut>;
Projector load_columns(const char *path) {
  std::ifstream f(path);
  unsigned j;
  Mask selected{};
  while (f >> j) {
    if (j >= columns || ((selected[j / 64] >> (j % 64)) & 1))
      throw std::runtime_error("Invalid or repeated selected column");
    selected[j / 64] |= 1ULL << (j % 64);
  }
  if (!f.eof())
    throw std::runtime_error("Cannot parse selected column file");
  return Projector(selected);
}
void convert(const char *source, std::uint64_t offset, std::uint64_t count,
             const char *output, const Projector &map) {
  if (fs::exists(output))
    throw std::runtime_error("Choose a new projected GPU filename");
  std::ifstream input(source, std::ios::ate | std::ios::binary);
  if (!input || input.tellg() != std::streamoff(offset + sizeof(Mask) * count))
    throw std::runtime_error("Incorrect length of source rows");
  input.seekg(offset);
  std::string tmp = std::string(output) + ".tmp." + std::to_string(getpid());
  constexpr size_t width = 16384;
  std::vector<Mask> buffer(width);
  std::vector<std::uint64_t> out(width);
  std::array<unsigned, Mask{}.size()> starts{};
  unsigned prefix = 0;
  for (unsigned w = 0; w < starts.size(); w++) {
    starts[w] = prefix;
    prefix += std::popcount(map.selected[w]);
  }
  std::uint64_t digest = 1469598103934665603ULL;
  try {
    std::ofstream file(tmp, std::ios::binary);
    for (std::uint64_t first = 0; first < count; first += width) {
      auto rows = std::min<std::uint64_t>(count - first, width);
      if (!input.read(reinterpret_cast<char *>(buffer.data()),
                      rows * sizeof(Mask)))
        throw std::runtime_error("Reading mask rows failed");
      for (unsigned r = 0; r < rows; r++) {
        auto bits = map(buffer[r]);
        // Reverse the projection. Every selected source column must survive
        // the round trip in its own layout position.
        for (unsigned w = 0; w < starts.size(); w++)
          if (map.selected[w]) {
            std::uint64_t compact = bits >> starts[w], restored = 0;
#ifdef __BMI2__
            restored = _pdep_u64(compact, map.selected[w]);
#else
            for (auto dest = map.selected[w]; dest; dest &= dest - 1) {
              if (compact & 1)
                restored |= dest & -dest;
              compact >>= 1;
            }
#endif
            if (restored != (buffer[r][w] & map.selected[w]))
              throw std::runtime_error("Projection round trip failed");
          }
        out[r] = bits;
        digest = (digest ^ bits) * 1099511628211ULL;
      }
      if (!file.write(reinterpret_cast<char *>(out.data()), rows * 8))
        throw std::runtime_error("Writing projection failed");
    }
    file.close();
    if (!file || link(tmp.c_str(), output))
      throw std::runtime_error("Could not publish GPU table");
    fs::remove(tmp);
  } catch (...) {
    fs::remove(tmp);
    throw;
  }
  std::cout << output << " rows " << count << " bytes " << count * 8
            << " digest " << digest << " payload offset 0\n"
            << std::flush;
}
int main(int argc, char **argv) {
  if (argc != 6)
    throw std::runtime_error(
        "usage: project-gpu-tables COLUMNS FULL_PREFIX PACKED_TAIL "
        "RAW_GPU_PREFIX RAW_GPU_TAIL_DICTIONARY");
  auto map = load_columns(argv[1]);
  std::ifstream packed(argv[3], std::ios::binary);
  packed_tail::Header h;
  if (!packed.read(reinterpret_cast<char *>(&h), sizeof(h)) ||
      h.tag != packed_tail::magic || h.prefix_size != cut || h.deck_size != n ||
      h.row_words != Mask{}.size() || h.order_count != tail_orders ||
      h.sets_per_order != embeddings || h.masks > blocks)
    throw std::runtime_error("Invalid packed dictionary source");
  convert(argv[2], 0, heads, argv[4], map);
  convert(argv[3], packed_tail::masks_position, h.masks, argv[5], map);
  std::cout << "Original packed offsets at " << packed_tail::offsets_position
            << ", u16 row IDs at " << packed_tail::ids_position
            << ", original Mask dictionary at " << packed_tail::masks_position
            << ".\n";
}
