# Joining a prefix interval

`sharded_range.cpp` joins a contiguous interval of lexicographic prefix ranks against a range of relative suffix orders. It derives the prefix words from their ranks and maps the source masks for its interval. It checks local sorting duals immediately. For a remote dual that survives any earlier cuts, it writes the dual prefix rank and its suffix-table row into a file grouped by target prefix rank. These two 32-bit integers uniquely identify the dual. Taking the dual again recovers the original input.

Build the length-20 driver with `c++ -O3 -std=c++20 -march=native -DCARD_COUNT=20 coverage/sharded_range.cpp -o shard`. Length 19 uses `-DCARD_COUNT=19`. The default cuts are 12 and 11, respectively. The suffix table may use the raw or packed format.

```text
shard scan HEAD_TABLE TAIL_TABLE HEAD_BEGIN HEAD_END ORDER_BEGIN ORDER_END STRIDE NEW_SPOOL_DIR GROUP_ROWS [EARLIER_TABLE [FUEL [LEAF_FUEL [NEXT_CUT [LAST_CUT]]]]] [--early-cache DIR] [--dual-projection FILE] [--prefix-depth DEPTH]
shard finish HEAD_TABLE TAIL_TABLE TARGET_GROUP SPOOL_DIR [SPOOL_DIR ...]
```

Rank intervals are half-open. A source rank interval and suffix-order progression identify one set of inputs for the primary pass. Use a new spool directory per primary job. Use the same positive `GROUP_ROWS` in jobs whose output you finish together. Both commands print any unresolved original decks on standard output. The primary pass also writes a manifest upon completion. A finishing job checks each deferred file's length and every key's membership in its target group. Run `finish` once per target group using all primary spool directories, and retain both sources of unresolved decks for further sorting.

`scan-slice` and `finish-slice` use a physical head file beginning at the specified interval, as produced by `coverage/build_prefix.cpp OUTPUT FIRST END`. With a full table, `scan` and `finish` map only the requested interval. They can read a prefix table that is still being built once all rows through the end of their interval have been written. `finish - TAIL_TABLE ...` directly computes the queried prefix layouts and can serve sparse groups before their head data exists.

`EARLIER_TABLE`, `NEXT_CUT` and `LAST_CUT` refer to prefix tables with one, two and three fewer cards than the primary cut. A dash skips one of these inputs. For a length-20 primary pass those tables have cuts 11, 10 and 9. `--early-cache` reuses 64-bit earlier-cut continuation masks across source intervals. Cache entries include the selected layout positions, search budget, suffix order and a checksum. `--dual-projection` takes the output of `verify/project_prefix.cpp` and tests its certified layouts before deferring a remote dual.

At length 20 a target interval of ten million heads occupies 560 MB of the raw prefix table. A deferred request occupies eight bytes. The terminal-1 universe has 5,040 suffix orders, 50,388 numerical suffix sets, and 479,001,600 prefix orders. A full sweep must partition all three factors, finish every remote query, resolve the remaining decks, and establish the shorter-length result used for descending-pair contraction.

An interval of normalized heads can have a common initial sequence. For each suffix value set the scan prunes the interval when this sequence already contains a descending bond, or when it lexicographically exceeds the largest dual prefix compatible with the set. To construct that upper bound, take the positions of the highest card labels in decreasing value order, using the earliest remaining unfixed input position whenever a position is unknown. These positions determine the largest compatible dual prefix. The optional `--prefix-depth` subdivides the current head interval by its first one or two normalized ranks and shares earlier-cut preparation across all groups.

The synthetic regression partitions all 362,880 terminal-1 decks at length 10 into ten prefix intervals. It includes a singleton interval, physically separate slices, and both local and remote duals. It checks the exact residual set against direct permutation enumeration under the same synthetic masks.

```sh
c++ -O2 -std=c++20 -DCARD_COUNT=10 -DCUT_SIZE=6 coverage/sharded_range.cpp -o small-shard
python coverage/check_shards.py ./small-shard
```
