"""Count both-corner pattern families without constructing their members."""

import argparse
from collections import Counter
from math import comb, factorial
from replay import PANTONE_VATTER


def patterns(length, retained=20, seed=PANTONE_VATTER):
    from itertools import combinations

    out = set()
    for omitted in combinations(range(len(seed)), len(seed)-retained):
        deck = [v for i,v in enumerate(seed) if i not in omitted]
        ranks = {v:i for i,v in enumerate(sorted(deck))}
        p = [ranks[v] for v in deck]
        i = p.index(0)
        p[-1],p[i] = p[i],p[-1]
        dual = [0]*retained
        for j,v in enumerate(p):
            dual[retained-1-v] = retained-1-j
        for full in (p,dual):
            prefix = full[:length]
            norm = {v:i for i,v in enumerate(sorted(prefix))}
            out.add(tuple(norm[v] for v in prefix))
    return out


def count(k, ell, retained=20, seed=PANTONE_VATTER):
    a, b = patterns(k, retained, seed), patterns(ell, retained, seed)
    return count_patterns(k, ell, a, b, retained)


def count_patterns(k, ell, a, b, retained=20):
    suffix = retained-1-k
    low_labels = retained-1-ell
    totals = {}
    for high_in_prefix in range(min(k, ell)+1):
        d_head = k-high_in_prefix
        d_tail = ell-high_in_prefix
        if d_head>low_labels or d_tail>suffix:
            continue
        common = Counter()
        for x in a:
            positions = [x.index(v) for v in reversed(range(d_head,k))]
            common[tuple(sum(q>p for q in positions) for p in positions)] += 1
        compatible = sum(common[tuple(v-d_tail for v in y if v>=d_tail)] for y in b)
        totals[high_in_prefix] = compatible * comb(low_labels,d_head) * comb(suffix,d_tail) * factorial(low_labels-d_head)
    return len(a),len(b),sum(totals.values()),totals


def union(rectangles, retained=20):
    """Inclusion-exclusion on (source pattern set, dual pattern set) restrictions."""
    from itertools import combinations
    def common(parts):
        # An empty pattern in the singleton set {()} imposes no restriction.
        if any(not p for p in parts):
            return set()
        longest = max(parts, key=lambda p: len(next(iter(p))))
        result = set()
        for word in longest:
            for choices in parts:
                prefix = word[:len(next(iter(choices)))]
                ranks = {v:i for i,v in enumerate(sorted(prefix))}
                if tuple(ranks[v] for v in prefix) not in choices:
                    break
            else:
                result.add(word)
        return result
    total = 0
    for size in range(1, len(rectangles) + 1):
        for group in combinations(rectangles, size):
            first = common([entry[0] for entry in group])
            second = common([entry[1] for entry in group])
            if first and second:
                k, ell = len(next(iter(first))), len(next(iter(second)))
                total += (-1)**(size+1) * count_patterns(k, ell, first, second, retained)[2]
    return total


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('front',type=int)
    parser.add_argument('dual_front',type=int)
    parser.add_argument('--n',type=int,default=20)
    parser.add_argument('--head-ranks',action='store_true')
    parser.add_argument('--seed', type=argparse.FileType('r'), help='Whitespace-separated source permutation')
    o=parser.parse_args()
    seed = tuple(map(int, o.seed.read().split())) if o.seed else PANTONE_VATTER
    if sorted(seed) != list(range(1, len(seed)+1)) or len(seed) < o.n:
        parser.error('The seed must be a permutation at least as long as the requested deck')
    if o.head_ranks:
        def lex(p):
            r=0
            for i,v in enumerate(p):
                r=r*(len(p)-i)+sum(a<v for a in p[i+1:])
            return r
        for r in sorted(map(lex,patterns(o.front,o.n,seed))):
            print(r)
    else:
        print(count(o.front,o.dual_front,o.n,seed))
