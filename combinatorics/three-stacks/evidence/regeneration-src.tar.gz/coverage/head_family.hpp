#pragma once
#include <array>
#include <bit>
#include <cstdint>

namespace head_family {
// Position zero is the first arrival in the normalized head. ranks[0] is the
// position of its smallest value, ranks[1] the position of its next value, etc.
template <unsigned K> struct Index {
  static_assert(K > 0 && K <= 12);
  static constexpr unsigned count(unsigned b) {
    unsigned v = 1;
    for (unsigned r = 0; r < b; r++)
      v *= K - r;
    return v;
  }
  static constexpr std::uint64_t offset(unsigned b) {
    std::uint64_t sum = 0, level = 1;
    for (unsigned r = 0; r < b; r++) {
      sum += level;
      level *= K - r;
    }
    return sum;
  }
  template <class Position>
  static unsigned local(const Position *ranks, unsigned b) {
    unsigned available = (1U << K) - 1, code = 0;
    for (unsigned r = 0; r < b; r++) {
      unsigned bit = 1U << ranks[r];
      code = code * (K - r) + std::popcount(available & (bit - 1));
      available ^= bit;
    }
    return code;
  }
  template <class Position>
  static std::uint64_t id(const Position *ranks, unsigned b) {
    return offset(b) + local(ranks, b);
  }
  static std::array<unsigned char, K> decode(unsigned code, unsigned b) {
    std::array<unsigned char, K> positions{}, digits{};
    for (unsigned r = b; r; --r) {
      unsigned base = K - r + 1;
      digits[r - 1] = code % base;
      code /= base;
    }
    unsigned available = (1U << K) - 1;
    for (unsigned r = 0; r < b; ++r) {
      unsigned choices = available;
      for (unsigned i = 0; i < digits[r]; ++i)
        choices &= choices - 1;
      positions[r] = std::countr_zero(choices);
      available ^= 1U << positions[r];
    }
    return positions;
  }
};
struct Key {
  unsigned b;
  unsigned local;
  std::uint64_t row;
};
// suffix[0..N-K-2] are the positive, zero-based actual values, in arrival
// order. Their positions are fixed. Among the dual head, the smallest ranks
// arise at precisely the high labels of this suffix in reverse arrival order.
template <unsigned N, unsigned K, class Card>
Key from_suffix(const Card *suffix) {
  constexpr unsigned m = N - 1 - K;
  std::array<unsigned char, K> positions{};
  unsigned b = 0;
  for (unsigned i = m; i; i--) {
    unsigned value = suffix[i - 1];
    if (value > m)
      positions[b++] = N - 1 - value;
  }
  unsigned local = Index<K>::local(positions.data(), b);
  return {b, local, Index<K>::offset(b) + local};
}
} // namespace head_family
