#pragma once
#include <array>
#include <stdexcept>
#include <utility>
#include <vector>
using Piles = std::array<std::vector<int>, 3>;
using Word = std::vector<int>;

// All cards start on three piles. Move only from pile 0 to 1, pile 1 to 2,
// and pile 2 to the required output. Retain a successful literal move word.
class Route {
public:
  Route(Piles piles, const Word &target)
      : piles_(std::move(piles)), target_(target) {
    for (std::size_t i = 0; i < target.size(); ++i)
      ranks_[target[i]] = i;
  }
  bool find() { return visit(0); }
  Word moves;

private:
  Piles piles_;
  const Word &target_;
  std::array<int, 32> ranks_{};

  bool step(int src, int done) {
    int card = piles_[src].back();
    piles_[src].pop_back();
    if (src < 2)
      piles_[src + 1].push_back(card);
    moves.push_back(src);
    if (visit(done + (src == 2)))
      return true;
    moves.pop_back();
    if (src < 2)
      piles_[src + 1].pop_back();
    piles_[src].push_back(card);
    return false;
  }

  bool visit(int done) {
    if (done == int(target_.size()))
      return piles_[0].empty() && piles_[1].empty() && piles_[2].empty();
    const auto &last = piles_[2];
    // An exposed next output can always leave immediately.
    if (!last.empty() && last.back() == target_[done])
      return step(2, done);
    // A transfer onto the output pile is possible in a successful run
    // only if the newcomer is due earlier than the current top.
    if (!piles_[1].empty() &&
        (last.empty() || ranks_[piles_[1].back()] < ranks_[last.back()]) &&
        step(1, done))
      return true;
    return !piles_[0].empty() && step(0, done);
  }
};

void move(std::vector<int> &from, std::vector<int> &to) {
  if (from.empty())
    throw std::logic_error("Physical replay popped an empty pile");
  to.push_back(from.back());
  from.pop_back();
}
