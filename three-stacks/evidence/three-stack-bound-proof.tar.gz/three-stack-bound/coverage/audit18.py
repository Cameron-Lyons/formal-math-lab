"""Verify all six observed length-18 rank progressions, counts, and schedules."""
import gzip
from math import comb, factorial
from pathlib import Path
import re
import sys
from replay import validate

ROOT = Path(__file__).resolve().parent / 'results'
PARTS = ('0', '1', '2a', '3a', '2b', '3b')
SETS = comb(17, 7)
HEADS = factorial(10)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def fields(line, names):
    words = line.split()
    return [int(words[words.index(key) + 1]) for key in names]


def read_progress(directory, ranks, canonical):
    tag = 'Through rank ' if canonical else 'through '
    with gzip.open(directory / 'progress.txt.gz', 'rt') as file:
        lines = [line for line in file if line.startswith(tag)]
    chunk = 8 if canonical else 1
    endpoints = [min(i + chunk, len(ranks)) for i in range(0, len(ranks), chunk)]
    require(len(lines) == len(endpoints), f'{directory}: missing progress records')
    with gzip.open(directory / 'residual-counts.txt.gz', 'rt') as file:
        raw = [tuple(map(int, line.split())) for line in file]
    require(len(raw) == len(ranks) and all(rank == observed and count >= 0
            for rank, (observed, count) in zip(ranks, raw)),
            f'{directory}: incorrect ranks in the residual stream')
    previous = [0, 0]
    raw_done = 0
    raw_count = 0
    for line, done in zip(lines, endpoints):
        last, blocks, missed, pending = fields(line, [
            'rank' if canonical else 'through', 'blocks', 'disjoint' if canonical else 'no_common', 'pending'])
        require(last == ranks[done - 1] and blocks == done * SETS,
                f'{directory}: incorrect rank progression at {last}')
        raw_count += sum(count for _, count in raw[raw_done:done])
        raw_done = done
        require(raw_count == pending, f'{directory}: residual stream differs at rank {last}')
        require(missed >= previous[0] and pending >= previous[1] and pending <= missed,
                f'{directory}: inconsistent cumulative progress at {last}')
        if not canonical:
            decks, bond, dual = fields(line, ['decks', 'bonds', 'dual'])
            require(decks == blocks * HEADS and missed == bond + dual + pending,
                    f'{directory}: incorrect intermediate count at {last}')
        previous = [missed, pending]
    return previous


def suffix_rank(cards):
    rank = 0
    for i, v in enumerate(cards):
        rank = rank * (i + 1) + sum(w > v for w in cards[:i])
    return rank


def audit(root=ROOT):
    seen_ranks = []
    sums = dict.fromkeys(['decks', 'first', 'bond', 'dual', 'symmetry', 'recuts', 'word'], 0)
    for part in PARTS:
        directory = root / f'n18-{part}'
        first, stop, stride, mode = (directory / 'range.txt').read_text().split()
        first, stop, stride = map(int, (first, stop, stride))
        require(0 <= first < stop <= 5040 and stride > 0 and mode in ('standard', 'canonical'),
                f'{directory}: invalid declared range')
        batch = range(first, stop, stride)
        seen_ranks.extend(batch)
        canonical = mode == 'canonical'
        last_counts = read_progress(directory, batch, canonical)
        term = (directory / 'join.txt').read_text()
        if canonical:
            decks = int(re.search(r'Universally enumerated (\d+)', term)[1])
            missed, bond, dual, sym, pending = [int(re.search('^' + name + r' (\d+)$', term, re.M)[1])
                for name in ['Disjoint', 'Bond', 'Dual', 'By symmetry', 'Residual']]
        else:
            final = [line for line in term.splitlines() if line.startswith('through ')][-1]
            last, decks, missed, bond, dual, pending = fields(final, ['through', 'decks', 'no_common', 'bonds', 'dual', 'pending'])
            require(last == batch[-1], f'{directory}: incorrect final rank')
            sym = 0
        require([missed, pending] == last_counts and decks == len(batch) * SETS * HEADS
                and missed == bond + dual + sym + pending, f'{directory}: join totals differ')
        sums['decks'] += decks
        sums['first'] += decks - missed
        sums['bond'] += bond
        sums['dual'] += dual
        sums['symmetry'] += sym
        for label in ['first', 'second', 'dual-first', 'dual-second']:
            line = (directory / (label + '.txt')).read_text()
            match = re.fullmatch(r'cut (\d+) n 18 cached (\d+) searched (\d+) remaining (\d+) seconds [\d.e+\-]+\n', line)
            require(match is not None, f'{directory}: invalid {label} stage')
            cut, cached, searched, left = map(int, match.groups())
            require(cut == (9 if label.endswith('first') else 8) and cached + searched + left == pending,
                    f'{directory}: {label} counts differ')
            sums['recuts'] += cached + searched
            pending = left
        with (directory / 'individual.txt').open() as src, gzip.open(directory / 'words.txt.gz', 'rt') as words:
            count = 0
            for line in src:
                p = tuple(map(int, line.split()[2:]))
                require(sorted(p) == list(range(1, 19)) and p[-1] == 1 and suffix_rank(p[10:-1]) in batch,
                        f'{directory}: invalid residual deck or wrong rank')
                count += 1
            require(count == pending, f'{directory}: wrong number of residuals')
            src.seek(0)
            validate(src, words)
        sums['word'] += pending
    require(sorted(seen_ranks) == list(range(5040)), 'Observed length-18 rank ranges overlap or leave a gap')
    require(sums['decks'] == factorial(17) and sums['decks'] == sum(v for k,v in sums.items() if k != 'decks'),
            'Length-18 totals differ')
    print(sums)


if __name__ == '__main__':
    if len(sys.argv) > 2:
        raise SystemExit('Usage: python coverage/audit18.py [results-directory]')
    audit(Path(sys.argv[1]) if len(sys.argv) == 2 else ROOT)
