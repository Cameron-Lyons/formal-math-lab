"""Check all 20-card one-point extensions of 19-card patterns of the published 21."""

from argparse import ArgumentParser
from itertools import combinations
from neighborhood import PANTONE_VATTER, VariableInput, variants
from check import check


def normalize(seq):
    rank = {x: i + 1 for i, x in enumerate(sorted(seq))}
    return [rank[x] for x in seq]


def extensions(deck):
    for rank in range(1, len(deck) + 2):
        lifted = [x + (x >= rank) for x in deck]
        for pos in range(len(deck) + 1):
            yield bytes(lifted[:pos] + [rank] + lifted[pos:])


def all_candidates():
    candidates = set()
    for x, y in combinations(PANTONE_VATTER, 2):
        base = normalize([v for v in PANTONE_VATTER if v != x and v != y])
        candidates.update(extensions(base))
    return candidates


def four_position_family():
    family = set()
    for missing in PANTONE_VATTER:
        deck = normalize([x for x in PANTONE_VATTER if x != missing])
        family.update(bytes(variant) for variant in variants(deck, 4))
    return family


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument(
        "--counts-only",
        action="store_true",
        help="count the neighborhoods and their overlap",
    )
    args = parser.parse_args()
    candidates = all_candidates()
    family = four_position_family()
    print(f"Distinct four-position candidates: {len(family)}", flush=True)
    print(f"Distinct extension candidates: {len(candidates)}", flush=True)
    common = len(family & candidates)
    print(f"Intersection: {common}", flush=True)
    print(f"Union: {len(family) + len(candidates) - common}", flush=True)
    if args.counts_only:
        raise SystemExit
    del family
    engine = VariableInput(20)
    for candidate in sorted(candidates):
        if not engine.solve(candidate):
            assert check(candidate, "verify/candidate") is None
            print("UNSORTABLE", *candidate, flush=True)
            break
    else:
        print(f"All {len(candidates)} candidates sort.", flush=True)
