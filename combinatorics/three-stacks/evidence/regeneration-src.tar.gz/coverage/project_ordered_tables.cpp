// Store a fixed set of reachable-layout columns in one 16-bit row per key.
#define CARD_COUNT 19
#include "../verify/join_tables.hpp"
#include "../verify/dual_projection.hpp"
#include <filesystem>

int main(int argc, char **argv) {
  if (argc != 3)
    throw std::runtime_error("usage: project_ordered_tables WORKDIR RANKED_COLUMNS");
  std::filesystem::path root=argv[1];
  std::ifstream source(argv[2]);
  Mask mask{};
  for (unsigned i=0;i<16;i++) {
    unsigned bit;
    if (!(source>>bit) || bit>=columns || (mask[bit/64]&(1ull<<(bit%64))))
      throw std::runtime_error("Invalid selected layout column");
    mask[bit/64]|=1ull<<(bit%64);
  }
  dual_projection::Map<cut> project(mask);
  TableFile head((root/"prefix11.bin").c_str(),heads);
  TableFile tail((root/"verify-tail19-packed.bin").c_str(),blocks,true);
  auto h=root/"ordered19-head16.bin", t=root/"ordered19-tail16.bin";
  if (std::filesystem::exists(h)||std::filesystem::exists(t))
    throw std::runtime_error("Choose a fresh destination for projected rows");
  std::ofstream prefix(h,std::ios::binary), suffix(t,std::ios::binary);
  std::vector<uint16_t> buffer(embeddings);
  for(Id i=0;i<heads;) {
    Id count=std::min(embeddings,heads-i);
    for(Id j=0;j<count;j++)buffer[j]=project(head[i+j]);
    prefix.write(reinterpret_cast<char*>(buffer.data()),count*sizeof(uint16_t));
    i+=count;
  }
  std::vector<uint16_t> dictionary;
  for (unsigned order=0;order<tail_orders;order++) {
    auto first=tail.packed.offsets[order], end=tail.packed.offsets[order+1];
    dictionary.resize(end-first);
    for(unsigned j=0;j<dictionary.size();j++)dictionary[j]=project(tail.packed.dictionary[first+j]);
    for(unsigned j=0;j<embeddings;j++) {
      unsigned k=tail.packed.ids[order*embeddings+j];
      if(k>=dictionary.size())throw std::runtime_error("Invalid suffix dictionary index");
      buffer[j]=dictionary[k];
    }
    suffix.write(reinterpret_cast<char*>(buffer.data()),buffer.size()*sizeof(uint16_t));
  }
  prefix.close();suffix.close();
  if(!prefix||!suffix)throw std::runtime_error("Incomplete projected layout tables");
}
