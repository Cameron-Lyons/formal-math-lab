"""Produce and independently replay a sorting schedule for each remaining input."""
import argparse
import gzip
from itertools import combinations
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "verify"))
from check import check, encode, operation_word, pair_table, replay, unpack
from pysat.solvers import Solver


def settle(n, source, words, proof):
    cards = list(range(1, n + 1))
    incoming = pair_table(cards, n * (n - 1))
    first, second, clauses = encode(cards, incoming)
    tested = 0
    with Solver(name="cadical195", bootstrap_with=clauses) as solver:
        for line in source:
            bits = line.split()
            if bits[:2] != ["Hard", "1"]:
                raise ValueError("Expected a residual input")
            deck = list(map(int, bits[2:]))
            if sorted(deck) != cards:
                raise ValueError("Expected a permutation of the stated length")
            assumptions = [incoming[a, b] for a, b in combinations(deck, 2)]
            if not solver.solve(assumptions=assumptions):
                if check(deck, proof) is not None:
                    raise RuntimeError("Independent encoding disagreed")
                print("UNSORTABLE", *deck, flush=True)
                return False
            model = set(solver.get_model())
            word = operation_word(deck, [unpack(deck, first, model),
                                        unpack(deck, second, model), cards])
            if not replay(deck, word):
                raise RuntimeError("Invalid sorting schedule")
            print(*deck, word, file=words)
            tested += 1
    print(f"Replayed {tested} sorting schedules")
    return True


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("n", type=int)
    p.add_argument("inputs")
    p.add_argument("words_gz")
    p.add_argument("--certificate", default="candidate")
    args = p.parse_args()
    with open(args.inputs) as src, gzip.open(args.words_gz, "wt", compresslevel=5) as out:
        if not settle(args.n, src, out, args.certificate):
            raise SystemExit(2)


if __name__ == "__main__":
    main()
