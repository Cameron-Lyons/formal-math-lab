// Bounded memory reader for packed tail rows visited by suffix order.
#pragma once
struct StreamTail {
  std::ifstream file;
  std::vector<std::uint64_t> offsets =
      std::vector<std::uint64_t>(tail_orders + 1);
  std::vector<Mask> dictionary = std::vector<Mask>(embeddings);
  std::vector<std::uint16_t> ids = std::vector<std::uint16_t>(embeddings);
  Id last = tail_orders;
  template <class T> void read(T *p, size_t count) {
    if (!file.read(reinterpret_cast<char *>(p), count * sizeof(T)))
      throw std::runtime_error("Packed stream read failed");
  }
  explicit StreamTail(const char *path)
      : file(path, std::ios::binary | std::ios::ate) {
    auto size = file.tellg();
    file.seekg(0);
    packed_tail::Header h;
    read(&h, 1);
    if (h.tag != packed_tail::magic || h.deck_size != n ||
        h.prefix_size != cut || h.row_words != Mask{}.size() ||
        h.order_count != tail_orders || h.sets_per_order != embeddings ||
        h.masks > blocks ||
        size != std::streamoff(packed_tail::masks_position +
                               h.masks * sizeof(Mask)))
      throw std::runtime_error("Bad packed stream header or size");
    file.seekg(packed_tail::offsets_position);
    read(offsets.data(), offsets.size());
    if (offsets.front() != 0 || offsets.back() != h.masks)
      throw std::runtime_error("Bad packed stream dictionary offsets");
  }
  unsigned select(Id order) {
    if (order >= tail_orders)
      throw std::runtime_error("Invalid packed suffix order");
    auto count = offsets[order + 1] - offsets[order];
    if (!count || count > embeddings)
      throw std::runtime_error("Bad packed order extent");
    if (last != order) {
      file.seekg(packed_tail::masks_position + offsets[order] * sizeof(Mask));
      read(dictionary.data(), count);
      file.seekg(packed_tail::ids_position +
                 std::uint64_t(order) * embeddings * 2);
      read(ids.data(), ids.size());
      for (auto id : ids)
        if (id >= count)
          throw std::runtime_error("Invalid packed dictionary id");
      last = order;
    }
    return count;
  }
  const Mask &operator[](Id block) {
    select(block / embeddings);
    return dictionary[ids[block % embeddings]];
  }
};
