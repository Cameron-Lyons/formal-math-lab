// Independent cross-check of tail.hpp and gaps.hpp on complete physical
// configurations. Build with c++ -std=c++20 -O3 coverage/check_tail.cpp.
#include "gaps.hpp"
#include "tail.hpp"
#include <algorithm>
#include <array>
#include <iostream>
#include <numeric>
#include <random>
#include <vector>

using Stacks = std::array<std::vector<int>, 3>;

bool physical(const std::vector<int> &input, int index, Stacks &s, int target,
              int n, bool direct) {
  if (target == n)
    return true;
  if (!s[2].empty() && s[2].back() == target) {
    s[2].pop_back();
    bool sorted = physical(input, index, s, target + 1, n, direct);
    s[2].push_back(target);
    return sorted;
  }
  for (int to = 2; to >= 0; --to) {
    if (to == 0 ? index == static_cast<int>(input.size()) : s[to - 1].empty())
      continue;
    int card = to == 0 ? input[index] : s[to - 1].back();
    if (to == 2 &&
        ((direct && card != target) || (!s[2].empty() && card > s[2].back())))
      continue;
    if (to)
      s[to - 1].pop_back();
    s[to].push_back(card);
    bool sorted = physical(input, index + (to == 0), s, target, n, direct);
    s[to].pop_back();
    if (to)
      s[to - 1].push_back(card);
    if (sorted)
      return true;
  }
  return false;
}

int main() {
  std::mt19937 rng(124);
  int checked = 0;
  for (int n : {7, 8, 9, 17}) {
    int cut = n == 17 ? 10 : 4;
    int length = n - cut - 1;
    std::vector<int> pattern(length), pool(n - 1);
    std::iota(pool.begin(), pool.end(), 1);
    auto shapes = layout::layouts(cut);
    gap::Table full(cut, n, 1000000);
    tail::Table direct(cut, n);
    for (int trial = 0; trial < (n == 17 ? 15 : 100); ++trial) {
      std::shuffle(pool.begin(), pool.end(), rng);
      std::copy_n(pool.begin(), length, pattern.begin());
      full.reset(pattern.data());
      auto row = direct.row(tail::rank_order(pattern.data(), length));
      auto sorted_pattern = pattern;
      std::sort(sorted_pattern.begin(), sorted_pattern.end());
      for (int sample = 0; sample < 3; ++sample) {
        std::shuffle(pool.begin(), pool.end(), rng);
        std::sort(pool.begin(), pool.begin() + length);
        unsigned mask = 0;
        std::vector<int> actual;
        for (int v : pattern) {
          auto rank = std::lower_bound(sorted_pattern.begin(),
                                       sorted_pattern.end(), v) -
                      sorted_pattern.begin();
          actual.push_back(pool[rank]);
          mask |= 1U << actual.back();
        }
        actual.push_back(0);
        gap::Embedding embedding(cut, n, mask);
        for (const auto &shape : shapes) {
          if (n == 17 && rng() % 30)
            continue;
          Stacks state;
          unsigned placed = mask | 1;
          for (int pile = 0; pile < 2; ++pile) {
            for (int rank : pile ? shape.second : shape.first) {
              int card = embedding.value[rank];
              state[pile].push_back(card);
              placed |= 1U << card;
            }
          }
          for (int v = n - 1; v >= 0; --v)
            if (!(placed & (1U << v)))
              state[2].push_back(v);
          bool expected = physical(actual, 0, state, 0, n, false);
          bool expected_direct = physical(actual, 0, state, 0, n, true);
          if (expected != full.test(embedding, shape) ||
              expected_direct !=
                  static_cast<bool>(
                      row[direct.column(shape, embedding.below.data())])) {
            std::cerr << "Disagreement in physical state at n=" << n << "\n";
            return 1;
          }
          ++checked;
        }
      }
    }
  }
  std::cout << checked << " physical configurations agreed with each table\n";
}
