// Check the contraction record by decoding its 19-card key from scratch.
#ifndef CARD_COUNT
#define CARD_COUNT 20
#endif
#include "bond_spool.hpp"
namespace fs = std::filesystem;
using Smaller = std::array<unsigned char, 19>;
int main(int argc, char **argv) {
  if (argc != 2)
    throw std::runtime_error("usage: check-bond-spool NEW_TEMP_DIR");
  fs::path dir = argv[1];
  BondSpool spool(dir);
  std::mt19937 random(324651);
  std::vector<Smaller> expected, decoded;
  for (unsigned test = 0; test < 100000; test++) {
    Smaller q;
    std::iota(q.begin(), q.end() - 1, 1);
    q.back() = 0;
    std::shuffle(q.begin(), q.end() - 1, random);
    unsigned pos = test % 19, x = q[pos], j = 0;
    Deck p;
    for (unsigned i = 0; i < q.size(); i++) {
      if (i == pos)
        p[j++] = x + 1;
      p[j++] = q[i] + (q[i] > x);
    }
    unsigned at = 0;
    while (p[at] != p[at + 1] + 1)
      ++at;
    std::vector<unsigned> rest(p.begin(), p.end());
    rest.erase(rest.begin() + at);
    auto sorted = rest;
    std::sort(sorted.begin(), sorted.end());
    Smaller expected_q;
    for (unsigned i = 0; i < rest.size(); i++)
      expected_q[i] = std::lower_bound(sorted.begin(), sorted.end(), rest[i]) -
                      sorted.begin();
    if (!spool.add(p))
      throw std::logic_error("Lost injected bond");
    expected.push_back(expected_q);
  }
  spool.finish();
  std::vector<unsigned> sets;
  for (unsigned s = 0; s < (1u << 18); s++)
    if (std::popcount(s) == 7)
      sets.push_back(s);
  std::array<std::array<int, 7>, 5040> suffixes;
  std::array<int, 7> seq;
  std::iota(seq.begin(), seq.end(), 0);
  do {
    unsigned rank = 0;
    for (unsigned i = 0; i < seq.size(); i++) {
      unsigned prior = 0;
      for (unsigned j = 0; j < i; j++)
        prior += seq[j] > seq[i];
      rank = rank * (i + 1) + prior;
    }
    suffixes[rank] = seq;
  } while (std::next_permutation(seq.begin(), seq.end()));
  for (auto f : fs::directory_iterator(dir)) {
    std::ifstream in(f.path(), std::ios::binary);
    std::array<Id, 2> key;
    while (in.read(reinterpret_cast<char *>(key.data()), sizeof(key))) {
      auto [h, b] = key;
      auto set = sets.at(b % sets.size());
      std::vector<unsigned> front, back;
      for (unsigned v = 1; v <= 18; v++)
        ((set & (1u << (v - 1))) ? back : front).push_back(v);
      Smaller q{};
      unsigned ways = factorial_of(11);
      for (unsigned i = 0; i < 11; i++) {
        ways /= 11 - i;
        unsigned d = h / ways;
        h %= ways;
        q[i] = front.at(d);
        front.erase(front.begin() + d);
      }
      auto &s = suffixes.at(b / sets.size());
      for (unsigned i = 0; i < 7; i++)
        q[11 + i] = back[s[i]];
      decoded.push_back(q);
    }
    if (!in.eof() || in.gcount())
      throw std::logic_error("Truncated query file");
  }
  std::sort(decoded.begin(), decoded.end());
  std::sort(expected.begin(), expected.end());
  if (decoded != expected)
    throw std::logic_error("Contraction spool disagrees with direct deletion");
  std::cout << "Decoded all " << decoded.size()
            << " random contraction records, including inflation at each of "
               "the 19 positions.\n";
}
