// Lossless per-order dictionaries for large immutable continuation tables.
// Mask, Id, n, cut, embeddings, tail_orders, blocks and MaskHash are supplied
// by the independent join which includes this header.
#pragma once

namespace packed_tail {
constexpr std::uint64_t magic = 0x314c4941544b5453ULL;
struct Header {
  std::uint64_t tag, masks, digest;
  std::uint32_t deck_size, prefix_size, row_words, order_count, sets_per_order;
};
constexpr std::size_t offsets_position = 4096;
constexpr std::size_t ids_position =
    offsets_position + (std::size_t(tail_orders) + 1) * 8;
constexpr std::size_t masks_position =
    (ids_position + std::size_t(blocks) * 2 + 7) & ~std::size_t(7);
static_assert(embeddings < 65535);

struct View {
  const std::uint64_t *offsets = nullptr;
  const std::uint16_t *ids = nullptr;
  const Mask *dictionary = nullptr;
  void attach(const void *mapping, std::size_t size) {
    if (size < masks_position)
      throw std::runtime_error("Truncated packed tail");
    const auto *bytes = static_cast<const std::uint8_t *>(mapping);
    const auto &h = *static_cast<const Header *>(mapping);
    if (h.tag != magic || h.deck_size != n || h.prefix_size != cut ||
        h.row_words != Mask{}.size() || h.order_count != tail_orders ||
        h.sets_per_order != embeddings || h.masks > blocks ||
        size != masks_position + h.masks * sizeof(Mask))
      throw std::runtime_error("Incompatible packed tail");
    offsets = reinterpret_cast<const std::uint64_t *>(bytes + offsets_position);
    ids = reinterpret_cast<const std::uint16_t *>(bytes + ids_position);
    dictionary = reinterpret_cast<const Mask *>(bytes + masks_position);
    if (offsets[0] != 0 || offsets[tail_orders] != h.masks)
      throw std::runtime_error("Bad packed tail directory");
    for (Id t = 0; t < tail_orders; ++t)
      if (offsets[t + 1] <= offsets[t] ||
          offsets[t + 1] - offsets[t] > embeddings)
        throw std::runtime_error("Bad packed tail order offset");
  }
  const Mask &get(Id row) const {
    return dictionary[offsets[row / embeddings] + ids[row]];
  }
};

void write_at(int fd, const void *data, std::size_t size, std::size_t pos) {
  auto *next = static_cast<const std::uint8_t *>(data);
  while (size) {
    auto written = pwrite(fd, next, size, pos);
    if (written < 0 && errno == EINTR)
      continue;
    if (written <= 0)
      throw std::runtime_error("Writing packed tail failed");
    pos += written;
    size -= written;
    next += written;
  }
}

template <class Raw> void build(const Raw &raw, const char *destination) {
  std::string temp = std::string(destination) + ".tmp.XXXXXX";
  int fd = mkstemp(temp.data());
  if (fd < 0)
    throw std::runtime_error("Cannot open temporary packed tail");
  try {
    std::vector<std::uint64_t> offsets(tail_orders + 1);
    std::vector<std::uint16_t> ids(embeddings);
    auto capacity = std::bit_ceil(2u * embeddings);
    std::vector<std::uint16_t> slots(capacity);
    std::vector<Mask> dict;
    dict.reserve(embeddings);
    std::uint64_t digest = 1469598103934665603ULL;
    for (Id order = 0; order < tail_orders; ++order) {
      dict.clear();
      std::fill(slots.begin(), slots.end(), std::uint16_t(-1));
      for (Id set = 0; set < embeddings; ++set) {
        const auto &m = raw[order * embeddings + set];
        auto h = MaskHash{}(m);
        digest = (digest ^ h) * 1099511628211ULL;
        auto where = h & (capacity - 1);
        while (slots[where] != std::uint16_t(-1) && dict[slots[where]] != m)
          where = (where + 1) & (capacity - 1);
        if (slots[where] == std::uint16_t(-1)) {
          slots[where] = dict.size();
          dict.push_back(m);
        }
        ids[set] = slots[where];
      }
      write_at(fd, ids.data(), ids.size() * sizeof(ids[0]),
               ids_position + std::size_t(order) * embeddings * 2);
      write_at(fd, dict.data(), dict.size() * sizeof(Mask),
               masks_position + offsets[order] * sizeof(Mask));
      offsets[order + 1] = offsets[order] + dict.size();
    }
    Header h{magic, offsets.back(), digest,      n,
             cut,   Mask{}.size(),  tail_orders, embeddings};
    write_at(fd, offsets.data(), offsets.size() * 8, offsets_position);
    write_at(fd, &h, sizeof(h), 0);
    if (fsync(fd) != 0 || rename(temp.c_str(), destination) != 0)
      throw std::runtime_error("Cannot finalize packed tail");
    close(fd);
    std::cerr << "Packed " << blocks << " rows into " << offsets.back()
              << " local dictionary entries, "
              << masks_position + offsets.back() * sizeof(Mask)
              << " bytes, digest " << digest << "\n";
  } catch (...) {
    close(fd);
    unlink(temp.c_str());
    throw;
  }
}
} // namespace packed_tail
