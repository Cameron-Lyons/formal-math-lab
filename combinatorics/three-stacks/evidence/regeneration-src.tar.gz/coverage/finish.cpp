#include "prefix.hpp"
#include "../structural/reach.hpp"
#include <iostream>

// Positive-only layout test for individual residual decks. The first ten input
// cards take a layout from the prefix table. The remainder is searched from
// that physical configuration.
int main(int argc,char**argv){
    using namespace prefix;
    if(argc<3)throw std::runtime_error("usage: finish prefix-file n [budget] [both]");
    int n=std::stoi(argv[2]),budget=argc>3?std::stoi(argv[3]):200;
    int directions=argc>4 && std::string(argv[4])=="both"?2:1;
    if(n<10||n>23)throw std::runtime_error("Unsupported deck length");
    auto table=read(argv[1]);
    auto shapes=layout::layouts(size);
    std::array<int,24> original, p, local, ranks;
    std::string label;
    int extra;
    std::uint64_t ok=0,failed=0;
    while(std::cin>>label>>extra){
        if(label!="Hard")throw std::runtime_error("Expected a Hard row");
        unsigned seen=0;
        for(int i=0;i<n;i++){
            if(!(std::cin>>original[i]))throw std::runtime_error("Incomplete input row");
            if(original[i]<1 || original[i]>n || (seen&(1u<<(original[i]-1))))throw std::runtime_error("Invalid permutation");
            --original[i];seen|=1u<<original[i];
        }
        bool accepted=false;
        for(int d=0;d<directions&&!accepted;d++){
            if(!d)p=original;
            else for(int j=0;j<n;j++)p[n-1-original[j]]=n-1-j;
            unsigned values=0;
            for(int j=0;j<size;j++)values |= 1u<<p[j];
            int rank=0;unsigned left=values;
            for(int j=0;j<size;j++){
                rank=rank*(size-j)+std::popcount(left & ((1u<<p[j])-1));left^=1u<<p[j];
            }
            int l=0;for(unsigned x=values;x;x&=x-1)ranks[l++]=std::countr_zero(x);
            local=p;
            reach::Search search{local.data(),n,budget,0,false};
            for(unsigned w=0;w<table[rank].size()&&!accepted;w++)
                for(auto bits=table[rank][w];bits;bits&=bits-1){
                    auto& shape=shapes[64*w+std::countr_zero(bits)];
                    unsigned C=values,A=0;
                    const reach::Node empty{31,31,0,nullptr};
                    const reach::Node* B=&empty;
                    reach::Node items[2];
                    for(unsigned j=0;j<shape.first.size();j++){
                        local[j]=ranks[shape.first[j]];A|=1u<<j;C^=1u<<local[j];
                    }
                    for(unsigned j=0;j<shape.second.size();j++){
                        int x=ranks[shape.second[j]];
                        items[j]={x,std::min(x,B->smallest),0,B};B=&items[j];C^=1u<<x;
                    }
                    search.nodes=0;search.exhausted=false;
                    if(search.dfs(A,B,C,size,0)){accepted=true;break;}
                }
        }
        if(accepted)++ok;
        else {
            ++failed;std::cout<<"Hard 1";for(int j=0;j<n;j++)std::cout<<' '<<original[j]+1;std::cout<<'\n';
        }
    }
    std::cerr<<"layout completions "<<ok<<" pending "<<failed<<"\n";
}
