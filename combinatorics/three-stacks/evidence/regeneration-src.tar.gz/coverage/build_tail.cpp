#include "dimensions.hpp"
#include "gaps.hpp"
#include "tail.hpp"
#include <iostream>

using namespace dimensions;
using Keys = std::array<PackedKey, prefix::layout_count>;

int main(int argc, char **argv) {
  if (argc < 2 || argc > 5)
    throw std::runtime_error("usage: build_tail output-file [node-budget "
                             "[first-rank past-last-rank]]");
  int budget = argc > 2 ? std::stoi(argv[2]) : 2400;
  int first = argc > 3 ? std::stoi(argv[3]) : 0;
  int past_last = argc > 4 ? std::stoi(argv[4]) : orders;
  if (budget < 1 || first < 0 || past_last > orders || first >= past_last)
    throw std::runtime_error("Invalid budget or suffix-rank range");
  const auto shapes = layout::layouts(prefix::size);
  gap::Table cache(prefix::size, n, budget);
  tail::Table direct(prefix::size, n);
  std::vector<Keys> embeddings;
  embeddings.reserve(sets);
  for (unsigned values = 0; values < (1u << (n - 1)); ++values) {
    if (std::popcount(values) != ordinary)
      continue;
    gap::Embedding embedding(prefix::size, n, values << 1);
    Keys codes;
    for (unsigned j = 0; j < shapes.size(); ++j) {
      unsigned code = cache.key(embedding, shapes[j]);
      if (code >= keys || int(code / stride) !=
                              direct.column(shapes[j], embedding.below.data()))
        throw std::logic_error("Inconsistent layout code");
      codes[j] = static_cast<PackedKey>(code);
    }
    embeddings.push_back(codes);
  }
  if (embeddings.size() != sets)
    throw std::logic_error("Wrong embedding count");
  std::ofstream out(argv[1], std::ios::binary);
  if (!out)
    throw std::runtime_error("Cannot create output file");
  std::vector<prefix::Mask> block(embeddings.size());
  std::vector<std::uint8_t> pass(keys);
  // Consecutive rank shards are independent. Concatenating them in increasing
  // order makes exactly the same file as a single full-range invocation.
  for (int rank = first; rank < past_last; ++rank) {
    auto tau = order(rank);
    if (tail::rank_order(tau.data(), ordinary) != rank)
      throw std::logic_error("Incorrect inversion of the suffix rank");
    cache.reset(tau.data());
    const auto *baseline = direct.row(rank);
    std::fill(pass.begin(), pass.end(), 0);
    for (unsigned i = 0; i < embeddings.size(); ++i) {
      auto &mask = block[i];
      mask = {};
      for (unsigned j = 0; j < shapes.size(); ++j) {
        unsigned key = embeddings[i][j];
        auto &flag = pass[key];
        if (flag == 0)
          flag = 1 + (baseline[key / stride] || cache.test(key));
        if (flag == 2)
          prefix::add(mask, j);
      }
    }
    out.write(reinterpret_cast<const char *>(block.data()),
              sizeof(prefix::Mask) * block.size());
    if ((rank + 1 - first) % 60 == 0)
      std::cerr << rank + 1 - first << " suffix orders\n";
  }
  out.close();
  if (!out)
    throw std::runtime_error("Suffix enumeration write failed");
}
