// Independent validation by enumeration in the opposite direction: assign each
// successive smallest rank to a free position, then enumerate all completions.
#include "head_family.hpp"
#include "prefix.hpp"
#include <fcntl.h>
#include <iostream>
#include <random>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
namespace {
constexpr unsigned k = prefix::size, n = 19;
using Family = head_family::Index<k>;
using Mask = prefix::Mask;
struct File {
  const Mask *rows;
  std::size_t bytes;
  File(const char *path, std::size_t count) : bytes(count * sizeof(Mask)) {
    int fd = open(path, O_RDONLY);
    struct stat info{};
    if (fd < 0 || fstat(fd, &info) != 0 || std::size_t(info.st_size) != bytes)
      throw std::runtime_error("Wrong input size");
    auto p = mmap(nullptr, bytes, PROT_READ, MAP_SHARED, fd, 0);
    close(fd);
    if (p == MAP_FAILED)
      throw std::runtime_error("Cannot map input");
    rows = static_cast<const Mask *>(p);
  }
  ~File() { munmap(const_cast<Mask *>(rows), bytes); }
};
struct Check {
  const File &raw, &stored;
  unsigned depth;
  std::array<unsigned, k + 1> factorial{}, families{};
  std::array<std::uint64_t, k + 1> members{}, used_bits{};
  std::array<unsigned char, k> word{}, ordered{};
  Check(const File &a, const File &b, unsigned d)
      : raw(a), stored(b), depth(d) {
    factorial[0] = 1;
    for (unsigned i = 1; i <= k; ++i)
      factorial[i] = factorial[i - 1] * i;
  }
  Mask visit(unsigned b, unsigned free) {
    unsigned family = families[b]++;
    auto row = Family::id(ordered.data(), b);
    if (row != Family::offset(b) + family)
      throw std::logic_error("Family rank mismatch");
    Mask result;
    result.fill(~uint64_t(0));
    auto take = [&](const Mask &child) {
      for (unsigned w = 0; w < result.size(); ++w)
        result[w] &= child[w];
    };
    if (b == depth) {
      std::array<unsigned, k> positions{}, values{};
      unsigned z = 0;
      for (unsigned i = 0; i < k; ++i)
        if (free & (1u << i)) {
          positions[z] = i;
          values[z] = b + z;
          ++z;
        }
      unsigned count = 0;
      do {
        for (unsigned i = 0; i < z; ++i)
          word[positions[i]] = values[i];
        unsigned rank = 0, seen = 0;
        for (int i = k - 1; i >= 0; --i) {
          unsigned bit = 1u << word[i];
          rank += factorial[k - 1 - i] * std::popcount(seen & (bit - 1));
          seen |= bit;
        }
        take(raw.rows[rank]);
        ++count;
      } while (std::next_permutation(values.begin(), values.begin() + z));
      if (count != factorial[k - b])
        throw std::logic_error("Wrong direct completion count");
    } else {
      for (unsigned choice = free; choice; choice &= choice - 1) {
        unsigned pos = std::countr_zero(choice);
        ordered[b] = pos;
        word[pos] = b;
        take(visit(b + 1, free ^ (1u << pos)));
      }
    }
    if (result != stored.rows[row])
      throw std::logic_error("Incorrect family intersection");
    members[b] += factorial[k - b];
    for (auto m : result)
      used_bits[b] += std::popcount(m);
    return result;
  }
};
void test_duals() {
  static_assert(n == 19 && k == 11);
  std::array<unsigned char, n> deck{}, dual{};
  std::iota(deck.begin(), deck.end() - 1, 1);
  std::mt19937 rng(1181923);
  for (unsigned t = 0; t < 100000; ++t) {
    std::shuffle(deck.begin(), deck.end() - 1, rng);
    for (unsigned i = 0; i < n; ++i)
      dual[n - 1 - deck[i]] = n - 1 - i;
    auto key = head_family::from_suffix<n, k>(deck.data() + k);
    std::array<unsigned char, k> positions;
    std::iota(positions.begin(), positions.end(), 0);
    std::sort(positions.begin(), positions.end(),
              [&](auto a, auto b) { return dual[a] < dual[b]; });
    unsigned small = std::count_if(dual.begin(), dual.begin() + k,
                                   [](auto v) { return v <= n - 1 - k; });
    if (small != key.b || Family::id(positions.data(), small) != key.row)
      throw std::logic_error("Incorrect dual family");
  }
}
} // namespace
int main(int argc, char **argv) {
  if (argc != 4)
    throw std::runtime_error("check_head_family PREFIX FAMILIES DEPTH");
  unsigned depth = std::stoul(argv[3]);
  if (depth > k)
    throw std::runtime_error("Invalid depth");
  File source(argv[1], prefix::count),
      table(argv[2], Family::offset(depth + 1));
  Check check(source, table, depth);
  check.visit(0, (1u << k) - 1);
  for (unsigned b = 0; b <= depth; ++b) {
    if (check.families[b] != Family::count(b) ||
        check.members[b] != prefix::count)
      throw std::logic_error("Incomplete family level");
    std::cout << "b " << b << " masks checked " << check.families[b]
              << " total members " << check.members[b] << " set bits "
              << check.used_bits[b] << '\n';
  }
  test_duals();
  std::cout
      << "100000 explicit sorting duals matched their direct suffix family\n";
}
