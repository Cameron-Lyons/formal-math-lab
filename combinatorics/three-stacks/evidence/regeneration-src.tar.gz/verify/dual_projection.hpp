// A positive projected intersection certifies the same full layout column.
// Layouts selected for a prefix file are ordered by their original column id.
#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <stdexcept>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef __BMI2__
#include <immintrin.h>
#endif
namespace dual_projection {
template <unsigned K> struct Map {
  static constexpr unsigned columns = 1 + 2 * K + 3 * K * (K - 1);
  static constexpr unsigned words = (columns + 63) / 64;
  using Mask = std::array<std::uint64_t, words>;
  Mask selected{};
  std::array<unsigned, words> shift{};
  explicit Map(Mask bits) : selected(bits) {
    if constexpr (columns % 64)
      if (bits.back() >> (columns % 64))
        throw std::runtime_error("Column exceeds full layout table");
    unsigned offset = 0;
    for (unsigned j = 0; j < words; j++) {
      shift[j] = offset;
      offset += std::popcount(bits[j]);
    }
    if (!offset || offset > 64)
      throw std::runtime_error("Projection needs 1 to 64 columns");
  }
  std::uint64_t operator()(const Mask &row) const {
    std::uint64_t out = 0;
    for (unsigned w = 0; w < words; w++) {
      auto bits = selected[w];
      if (!bits)
        continue;
#ifdef __BMI2__
      auto gathered = _pext_u64(row[w], bits);
#else
      std::uint64_t gathered = 0, place = 1;
      while (bits) {
        auto bit = bits & -bits;
        if (row[w] & bit)
          gathered |= place;
        bits ^= bit;
        place <<= 1;
      }
#endif
      out |= gathered << shift[w];
    }
    return out;
  }
};
template <unsigned K> struct File {
  using Mapping = Map<K>;
  using Mask = typename Mapping::Mask;
  using Header = std::array<std::uint64_t, 16>;
  static constexpr std::uint64_t magic = 0x315052504c5453ULL;
  static Header header(std::uint64_t first, std::uint64_t count,
                       const Mapping &m) {
    Header h{magic, K, m.words, first, count};
    std::copy(m.selected.begin(), m.selected.end(), h.begin() + 5);
    return h;
  }
  void *data = MAP_FAILED;
  size_t bytes = 0;
  std::uint64_t first = 0, count = 0;
  Mapping map;
  static Mask read_header(int fd, size_t bytes, std::uint64_t &first,
                          std::uint64_t &count) {
    Header h{};
    if (pread(fd, h.data(), sizeof(h), 0) != sizeof(h) || h[0] != magic ||
        h[1] != K || h[2] != Mapping::words)
      throw std::runtime_error("Incorrect projected prefix header");
    first = h[3];
    count = h[4];
    if (bytes < sizeof(h) || count != (bytes - sizeof(h)) / 8 ||
        (bytes - sizeof(h)) % 8)
      throw std::runtime_error("Incorrect projected prefix length");
    Mask out;
    std::copy_n(h.begin() + 5, out.size(), out.begin());
    return out;
  }
  struct Open {
    int fd;
    size_t bytes;
    explicit Open(const char *path) : fd(open(path, O_RDONLY)) {
      struct stat s;
      if (fd < 0 || fstat(fd, &s) != 0) {
        if (fd >= 0)
          close(fd);
        throw std::runtime_error("Could not open projected prefix");
      }
      bytes = s.st_size;
    }
    Open(const Open &) = delete;
    ~Open() { close(fd); }
  };
  explicit File(const char *path) : File(Open(path)) {}

private:
  explicit File(const Open &f)
      : bytes(f.bytes), map(read_header(f.fd, bytes, first, count)) {
    data = mmap(nullptr, bytes, PROT_READ, MAP_PRIVATE, f.fd, 0);
    if (data == MAP_FAILED)
      throw std::runtime_error("Cannot map projected prefix");
  }

public:
  File(const File &) = delete;
  ~File() {
    if (data != MAP_FAILED)
      munmap(data, bytes);
  }
  const std::uint64_t &operator[](std::uint64_t id) const {
    return (reinterpret_cast<const std::uint64_t *>(data) + 16)[id - first];
  }
  bool accepts(std::uint64_t id, const Mask &tail) const {
    return id >= first && id - first < count && ((*this)[id] & map(tail));
  }
};
} // namespace dual_projection
