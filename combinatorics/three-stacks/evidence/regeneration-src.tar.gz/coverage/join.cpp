#include "dimensions.hpp"
#include "earlier_cut.hpp"
#include "hierarchy.hpp"
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <cerrno>
#include <cstring>
#include <span>
#include <unistd.h>
#include "tail.hpp"
#include <chrono>
#include <iostream>
#include <limits>
#include <unordered_map>
#include <random>
using namespace prefix;
using dimensions::n;
using dimensions::ordinary;
using dimensions::orders;
using dimensions::sets;
using Deck=std::array<int,n>;
using Index=std::uint32_t;
constexpr int width=15;
constexpr unsigned bins=1u<<width;
struct Projection {
    std::array<unsigned,width> columns;
    std::array<Index,bins+1> begin{};
    std::array<Index,bins> subsets{};
    std::vector<Index> rows;
    struct Chunk { Index first, end; Mask common; };
    std::vector<Chunk> chunks;
    std::array<Index,bins+1> chunk_start{};
    std::vector<Mask> common;


    unsigned bucket(const Mask& mask) const {
        unsigned code=0;
        for(int i=0;i<width;i++) if(has(mask,columns[i]))code|=1u<<i;
        return code;
    }
    Projection(std::span<const Mask> masks,std::mt19937_64& rng):rows(count) {
        // Build several short lists of layouts that together accept a large
        // fraction of all prefixes. The indices accelerate an exact join.
        std::array<bool,layout_count> used{};
        std::vector<Index> left(count);
        std::iota(left.begin(),left.end(),0);
        for(int depth=0;depth<width;depth++){
            if(left.empty()){left.resize(count);std::iota(left.begin(),left.end(),0);}
            std::array<int,layout_count> hits{};
            int sample=std::min(800,int(left.size()));
            for(int i=0;i<sample;i++){
                const auto& mask=masks[left[left.size()<=800?i:rng()%left.size()]];
                for(unsigned w=0;w<mask.size();w++){
                    for(auto bits=mask[w];bits;bits&=bits-1) hits[w*64+std::countr_zero(bits)]++;
                }
            }
            std::vector<unsigned> choices;
            for(unsigned j=0;j<layout_count;j++)if(!used[j])choices.push_back(j);
            std::partial_sort(choices.begin(),choices.begin()+5,choices.end(),
                [&](auto a,auto b){return hits[a]>hits[b] || (hits[a]==hits[b]&&a<b);});
            unsigned j=choices[rng()%5];
            columns[depth]=j;used[j]=true;
            left.erase(std::remove_if(left.begin(),left.end(),[&](Index id){return has(masks[id],j);}),left.end());
        }
        for(auto& mask:masks) begin[bucket(mask)+1]++;
        std::partial_sum(begin.begin(),begin.end(),begin.begin());
        auto cursor=begin;
        for(Index id=0;id<count;id++)rows[cursor[bucket(masks[id])]++]=id;
        // All prefix masks in a chunk include its common layouts. An offered
        // common layout eliminates the entire chunk with one exact AND test.
        common.resize(bins);
        for(unsigned code=0; code<bins; ++code){
            chunk_start[code]=chunks.size();
            auto &bucket_common=common[code]; bucket_common.fill(~std::uint64_t(0));
            for(Index first=begin[code];first<begin[code+1];first+=64){
                Chunk chunk{first,std::min<Index>(first+64,begin[code+1]),masks[rows[first]]};
                for(Index j=first+1;j<chunk.end;j++)for(unsigned w=0;w<chunk.common.size();w++)
                    chunk.common[w]&=masks[rows[j]][w];
                for(unsigned w=0;w<bucket_common.size();w++)bucket_common[w]&=chunk.common[w];
                chunks.push_back(chunk);
            }
        }
        chunk_start[bins]=chunks.size();
        for(unsigned code=0;code<bins;code++)subsets[code]=begin[code+1]-begin[code];
        for(unsigned bit=1;bit<bins;bit<<=1) for(unsigned code=0;code<bins;code++)
            if(code&bit)subsets[code]+=subsets[code^bit];
    }
};
int prefix_rank(const Deck& p){
    unsigned left=0;
    for(int j=0;j<size;j++)left|=1u<<p[j];
    int rank=0;
    for(int j=0;j<size;j++){
        rank=rank*(size-j)+std::popcount(left&((1u<<p[j])-1));left^=1u<<p[j];
    }
    return rank;
}
// Joining reads two kinds of rows: a sequential suffix slice and occasional
// rows for sorting duals. A read-only file mapping lets parallel workers
// share pages, and allows the kernel to reclaim pages under memory pressure.
class MappedMasks {
    void* mapping=nullptr;
    std::size_t bytes,rows;
    const Mask* data=nullptr;
    const std::uint64_t* offsets=nullptr;
    const std::uint16_t* ids=nullptr;
    void attach_dictionary(){
        // Binary format written by verify/packed_tail.hpp. Each suffix order
        // has its own lossless dictionary of masks and 16-bit local indices.
        struct Header {std::uint64_t magic,count,digest;std::uint32_t n,k,words,orders,sets;};
        const auto* raw=static_cast<const std::uint8_t*>(mapping);
        auto offsets_at=std::size_t(4096),ids_at=offsets_at+(orders+1)*sizeof(std::uint64_t);
        auto masks_at=(ids_at+rows*sizeof(std::uint16_t)+7)&~std::size_t(7);
        if(bytes<masks_at)throw std::runtime_error("Truncated packed tail");
        const auto& h=*reinterpret_cast<const Header*>(raw);
        if(h.magic!=0x314c4941544b5453ULL || h.n!=n || h.k!=size || h.words!=Mask{}.size()
            || h.orders!=orders || h.sets!=sets || h.count>rows || bytes!=masks_at+h.count*sizeof(Mask))throw std::runtime_error("Incompatible packed tail");
        offsets=reinterpret_cast<const std::uint64_t*>(raw+offsets_at);
        ids=reinterpret_cast<const std::uint16_t*>(raw+ids_at);
        data=reinterpret_cast<const Mask*>(raw+masks_at);
        if(offsets[0]!=0 || offsets[orders]!=h.count)throw std::runtime_error("Invalid packed tail registry");
        for(int i=0;i<orders;i++)if(offsets[i+1]<=offsets[i]||offsets[i+1]-offsets[i]>sets)throw std::runtime_error("Invalid packed tail offsets");
    }
public:
    MappedMasks(const char* path,std::size_t rows,bool allow_packed=false):rows(rows){
        int fd=open(path,O_RDONLY);
        if(fd<0)throw std::runtime_error(std::string("Cannot open table: ")+path);
        struct stat info{};
        if(fstat(fd,&info)!=0||info.st_size<=0){close(fd);throw std::runtime_error("Cannot measure table");}
        bytes=info.st_size;
        if(bytes!=rows*sizeof(Mask) && !allow_packed){close(fd);throw std::runtime_error(std::string("Incomplete table: ")+path);}
        mapping=mmap(nullptr,bytes,PROT_READ,MAP_SHARED,fd,0);close(fd);
        if(mapping==MAP_FAILED)throw std::runtime_error(std::string("Cannot map table: ")+path);
        if(bytes==rows*sizeof(Mask))data=static_cast<const Mask*>(mapping);
        else {try{attach_dictionary();}catch(...){munmap(mapping,bytes);throw;}}
    }
    MappedMasks(const MappedMasks&)=delete;
    MappedMasks& operator=(const MappedMasks&)=delete;
    ~MappedMasks(){munmap(mapping,bytes);}
    const Mask& operator[](std::size_t i)const{
        if(!ids)return data[i];
        auto base=offsets[i/sets],local=std::uint64_t(ids[i]);
        if(base+local>=offsets[i/sets+1])throw std::runtime_error("Invalid packed mask ID");
        return data[base+local];
    }
    std::span<const Mask> span()const{return {data,rows};}
};
struct MaskHash {
    std::size_t operator()(const Mask& m) const {
        std::uint64_t h=1469598103934665603ULL;
        for(auto v:m)h=(h^v)*0x9e3779b185ebca87ULL;
        return h^(h>>31);
    }
};
struct PrefixWord {
    std::uint32_t earlier_rank;
    std::array<std::uint8_t,size> word;
    std::uint16_t bonds;
};
struct Candidates {
    Index projected=0;
    int reorder_by=-1;
    std::vector<Index> ranks;
};
struct Universe {
    MappedMasks head,tailmask;
    std::vector<std::array<int,size>> prefix_values;
    std::vector<std::array<int,ordinary>> suffix_values;
    std::array<int,1u<<(n-1)> set_index{};
    std::array<std::array<int,ordinary>,orders> suffix_orders{};
    std::vector<Projection> indices;
    std::vector<PrefixWord> words;
    std::vector<unsigned> consecutive;
    std::unique_ptr<earlier::Filter> extra;
    Universe(const char* prefix_file,const char* tail_file,int nindices,const std::string& extra_file,int fuel):head(prefix_file,count),tailmask(tail_file,dimensions::rows,true){
        if(!extra_file.empty())extra=std::make_unique<earlier::Filter>(extra_file,fuel);
        for(unsigned m=0;m<(1u<<(n-1));m++)if(std::popcount(m)==ordinary){
            set_index[m]=prefix_values.size();
            std::array<int,size> a;
            std::array<int,ordinary> b;
            int i=0,j=0;
            for(int v=1;v<n;v++)if(m&(1u<<(v-1)))b[j++]=v;else a[i++]=v;
            prefix_values.push_back(a);suffix_values.push_back(b);
            unsigned adjacent=0;
            for(int i=0;i+1<size;i++)if(a[i]+1==a[i+1])adjacent|=1U<<i;
            consecutive.push_back(adjacent);
        }
        if(prefix_values.size()!=sets)throw std::logic_error("Incorrect value-set enumeration");
        std::array<int,ordinary> tau;
        std::iota(tau.begin(),tau.end(),0);
        do{suffix_orders[tail::rank_order(tau.data(),ordinary)]=tau;}while(std::next_permutation(tau.begin(),tau.end()));
        words.reserve(count);
        for(int id=0;id<count;++id){
            auto ranks=permutation(id);
            PrefixWord word{};
            if(extra)word.earlier_rank=earlier::prefix_rank(ranks);
            for(int i=0;i<size;++i){
                word.word[i]=static_cast<std::uint8_t>(ranks[i]);
                if(i && ranks[i-1]==ranks[i]+1)word.bonds|=1U<<ranks[i];
            }
            words.push_back(word);
        }
        std::mt19937_64 rng(234202);
        indices.reserve(nindices);
        for(int i=0;i<nindices;i++)indices.emplace_back(head.span(),rng);
    }
    bool certified(const Deck& p)const{
        unsigned set=0;
        for(int j=size;j<n-1;j++)set|=1u<<(p[j]-1);
        int tail_rank=tail::rank_order(p.data()+size,ordinary);
        return any(head[prefix_rank(p)],tailmask[std::size_t(tail_rank)*sets+set_index[set]]);
    }
    struct Bound {Index count;unsigned which,sub;};
    Bound projection(const Mask& mask) const {
        Bound best{std::numeric_limits<Index>::max(),0,0};
        for(unsigned i=0;i<indices.size();i++){
            unsigned free=(bins-1)^indices[i].bucket(mask);
            if(indices[i].subsets[free]<best.count){best={indices[i].subsets[free],i,free};if(!best.count)break;}
        }
        return best;
    }
    Candidates candidates(const Mask& mask,std::size_t limit=std::numeric_limits<std::size_t>::max()) const {
        Candidates result;
        auto [projected,which,sub]=projection(mask);result.projected=projected;
        if(!projected)return result;
        const auto& index=indices[which];
        for(unsigned code=sub;;code=(code-1)&sub){
            if(!any(index.common[code],mask)){
                for(auto chunk_id=index.chunk_start[code];chunk_id<index.chunk_start[code+1];++chunk_id){
                    const auto& c=index.chunks[chunk_id];
                    if(any(c.common,mask))continue;
                    for(Index pos=c.first;pos<c.end;++pos){
                        Index id=index.rows[pos];
                        if(!any(head[id],mask)){result.ranks.push_back(id);if(result.ranks.size()>=limit)return result;}
                    }
                }
            }
            if(!code)break;
        }
        return result;
    }
    Candidates filtered(const Mask& m,const hierarchy::Anchor& anchor)const {
        Candidates result;auto b=projection(m);result.projected=b.count;
        if(!b.count)return result;
        for(Index id:anchor.ranks)if(!any(anchor.root?anchor.root->masks[id]:head[id],m))result.ranks.push_back(anchor.root?anchor.root->ids[id]:id);
        if(anchor.projection!=b.which && result.ranks.size()>1)result.reorder_by=b.which;
        return result;
    }
    bool use_hierarchy=false,show_timing=false;
    void run(int start,int stop,int stride,std::size_t pre_threshold){
        std::uint64_t blocks=0,projected=0,after_join=0,reduced=0,dual_ok=0,open=0;
        std::uint64_t early=0,late=0,anchor_queries=0;
        double prep_time=0,candidate_time=0;
        auto clock=[](){return std::chrono::steady_clock::now();};
        auto elapsed=[&](auto t){return std::chrono::duration<double>(clock()-t).count();};
        hierarchy::Bank bank;
        const auto t0=std::chrono::steady_clock::now();
        constexpr std::size_t cache_bytes=40U<<20;
        for(int tau=start;tau<stop;tau+=stride){
            if(extra)extra->new_order();
            std::unique_ptr<hierarchy::Groups> groups;
            if(use_hierarchy){auto start=clock();
                groups=std::make_unique<hierarchy::Groups>([&](unsigned i)->const Mask&{return tailmask[std::size_t(tau)*sets+i];},sets,bank,
                    [&](const Mask& m){return projection(m);},[&](const Mask&m,std::size_t cap){return candidates(m,cap);},[&](Index i)->const Mask&{return head[i];});
                prep_time+=elapsed(start);
            }
            std::unordered_map<Mask,Candidates,MaskHash> cache;
            std::size_t estimated_bytes=0;
            for(int s=0;s<sets;s++){
                blocks++;
                const auto& mask=tailmask[std::size_t(tau)*sets+s];
                auto found=cache.find(mask);
                if(found==cache.end()){
                    if(estimated_bytes>=cache_bytes){cache.clear();estimated_bytes=0;}
                    auto t=show_timing?clock():t0;
                    auto anchor=groups?groups->get(mask):hierarchy::Ptr{};
                    if(anchor)++anchor_queries;
                    found=cache.try_emplace(mask,anchor?filtered(mask,*anchor):candidates(mask)).first;
                    if(show_timing)candidate_time+=elapsed(t);
                    estimated_bytes+=sizeof(*found)+3*sizeof(void*)+sizeof(Index)*found->second.ranks.capacity();
                }
                const auto& list=found->second;
                projected+=list.projected;
                after_join+=list.ranks.size();
                if(list.ranks.empty())continue;
                Deck p{};
                for(int i=0;i<ordinary;i++)p[size+i]=suffix_values[s][suffix_orders[tau][i]];
                bool tail_bond=false;
                if constexpr(n>=17)
                    for(int i=size+1;i<n;i++)if(p[i-1]==p[i]+1){tail_bond=true;break;}
                if(tail_bond){reduced+=list.ranks.size();continue;}
                bool first_cut=extra && list.ranks.size()>=pre_threshold;
                if(extra)extra->new_block(p.data()+size,prefix_values[s]);
                auto output=[&](){
                    std::cout<<"Hard 1";for(int v:p)std::cout<<' '<<v+1;std::cout<<'\n';
                };
                std::vector<std::uint64_t> waiting;
                for(Index id:list.ranks){
                    const auto& h=words[id];
                    if constexpr(n>=17)
                        if((h.bonds&consecutive[s]) || prefix_values[s][h.word.back()]==p[size]+1){++reduced;continue;}
                    if(first_cut && extra->accepts(h.earlier_rank,h.word.back())){++early;continue;}
                    for(int i=0;i<size;i++)p[i]=prefix_values[s][h.word[i]];
                    Deck dual;
                    for(int i=0;i<n;i++)dual[n-1-p[i]]=n-1-i;
                    if(certified(dual)){++dual_ok;continue;}
                    if(extra && !first_cut && extra->accepts(h.earlier_rank,h.word.back())){++late;continue;}
                    open++;
                    if(list.reorder_by<0)output();
                    else {
                        unsigned bucket=indices[list.reorder_by].bucket(head[id]);
                        waiting.push_back((std::uint64_t(bins-1-bucket)<<32)|id);
                    }
                }
                std::sort(waiting.begin(),waiting.end());
                for(std::uint64_t key:waiting){
                    const auto& h=words[static_cast<Index>(key)];
                    for(int i=0;i<size;++i)p[i]=prefix_values[s][h.word[i]];
                    output();
                }
            }
            std::cerr<<"through "<<tau<<" blocks "<<blocks<<" decks "<<blocks*count
                <<" projected "<<projected<<" no_common "<<after_join<<" bonds "<<reduced
                <<" dual "<<dual_ok<<" pending "<<open;
            if(extra)std::cerr<<" earlier_before_dual "<<early<<" earlier_after_dual "<<late;
            if(after_join!=reduced+early+dual_ok+late+open)throw std::logic_error("Unaccounted join candidate");
            if(show_timing)std::cerr<<" hierarchy_setup "<<prep_time<<" candidate_seconds "<<candidate_time<<" classification_seconds "<<elapsed(t0)-prep_time-candidate_time<<" anchor_queries "<<anchor_queries;
            std::cerr<<" seconds "
                <<std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count()<<'\n';
            std::cout.flush();
        }
        std::uint64_t expected_ranks=1+(stop-start-1)/stride;
        if(blocks!=expected_ranks*sets)throw std::logic_error("Incomplete suffix-rank range");
    }
};
namespace {
void redirect_to(const std::string& name,int dest){
    int fd=open(name.c_str(),O_CREAT|O_WRONLY|O_TRUNC,0666);
    if(fd<0||dup2(fd,dest)<0){if(fd>=0)close(fd);throw std::runtime_error("Cannot redirect worker stream to "+name);}
    if(fd!=dest)close(fd);
}
int fan_out(Universe& universe,int first,int stop,int stride,std::size_t threshold,int workers,const std::string& output){
    int ranks=1+(stop-first-1)/stride;
    workers=std::min(workers,ranks);
    std::vector<std::pair<pid_t,int>> children;
    children.reserve(workers);
    bool success=true;
    std::cout.flush();std::cerr.flush();
    for(int i=0;i<workers;++i){
        auto prefix=output+"."+std::to_string(i);
        pid_t pid=fork();
        if(pid<0){std::cerr<<"fork failed: "<<std::strerror(errno)<<'\n';success=false;break;}
        if(pid==0){
            try{
                redirect_to(prefix+".log",STDERR_FILENO);
                redirect_to(prefix+".out",STDOUT_FILENO);
                std::cerr<<"worker "<<i<<" first "<<first+i*stride<<" past_last "<<stop<<" stride "<<stride*workers<<'\n';
                universe.run(first+i*stride,stop,stride*workers,threshold);
                std::cout.flush();std::cerr.flush();
                _exit(std::cout&&std::cerr?0:1);
            }catch(const std::exception& e){std::cerr<<"worker "<<i<<" failed: "<<e.what()<<'\n';_exit(1);}
        }
        children.emplace_back(pid,i);
    }
    for(auto [pid,id]:children){
        int status=0;pid_t got;
        do {got=waitpid(pid,&status,0);}while(got<0&&errno==EINTR);
        if(got<0||!WIFEXITED(status)||WEXITSTATUS(status)!=0){
            std::cerr<<"worker "<<id<<" failed, wait status "<<status<<'\n';success=false;
        }
    }
    if(success)std::cerr<<"completed "<<workers<<" workers covering "<<ranks<<" suffix ranks and "<<std::uint64_t(ranks)*sets*count<<" decks\n";
    return success?0:1;
}
}
int main(int argc,char**argv){
    if(argc<3)throw std::runtime_error("usage: join prefix-table tail-table [first-rank past-last-rank stride projection-count [earlier-prefix-table [pre-dual-threshold [fuel]]]] [--workers N --output PREFIX]");
    std::vector<std::string> args;
    int workers=1;std::string output;bool tree=false,timing=false;
    for(int i=3;i<argc;i++){
        std::string value=argv[i];
        if(value=="--hierarchy"){tree=true;timing=true;continue;}
        if(value=="--timing"){timing=true;continue;}
        if(value=="--workers" || value=="--output"){
            if(i+1==argc)throw std::runtime_error("Missing worker option argument");
            if(value=="--workers")workers=std::stoi(argv[++i]);else output=argv[++i];
        }else args.push_back(value);
    }
    int first=args.size()>0?std::stoi(args[0]):0,stop=args.size()>1?std::stoi(args[1]):orders;
    int stride=args.size()>2?std::stoi(args[2]):1,projections=args.size()>3?std::stoi(args[3]):6;
    std::string earlier=args.size()>4?args[4]:"";
    int threshold=args.size()>5?std::stoi(args[5]):256,fuel=args.size()>6?std::stoi(args[6]):1000;
    if(first<0||stop>orders||first>=stop||stride<1||projections<1||threshold<0||fuel<1||args.size()>7||workers<1)
        throw std::runtime_error("Invalid join arguments");
    if(workers>1&&output.empty())throw std::runtime_error("Provide --output PREFIX for separate worker files");
    std::ios::sync_with_stdio(false);std::cin.tie(nullptr);
    auto start=std::chrono::steady_clock::now();
    Universe u(argv[1],argv[2],projections,earlier,fuel);u.use_hierarchy=tree;u.show_timing=timing;
    std::cerr<<"immutable index built in "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<" seconds\n";
    if(!output.empty())return fan_out(u,first,stop,stride,threshold,workers,output);
    u.run(first,stop,stride,threshold);
}
