"""Verify the length-20 endgame extension families against the closed length-19 run."""
import argparse
import gzip
import json
from pathlib import Path
from extend_hard19 import generate
from replay import replay

def require(condition, message):
    if not condition:raise ValueError(message)

def replay_words(file, pool):
    count=0
    with gzip.open(file,'rt') as words:
        for line in words:
            *cards, word=line.split()
            p=bytes(map(int,cards))
            require(p in pool and len(word)==80 and replay(p,word),f'Invalid extension word in {file}')
            pool.remove(p);count+=1
    return count

def audit(closures,results,partial):
    expected=set()
    ranks=set()
    for report in closures.glob('*/closure.json'):
        chunk=json.loads(report.read_text())
        for r,_ in chunk['ranks']:
            require(r not in ranks,'Duplicate length-19 rank');ranks.add(r)
        for row in (report.parent/'individual.txt').read_text().splitlines():
            p=bytes(map(int,row.split()[2:]))
            require(p not in expected and len(p)==19 and p[-1]==1,'Invalid length-19 input')
            expected.add(p)
    seen=set();raw=set();covered=set();lifted_count=last_count=0
    for batch in sorted(results.glob('batch-*')):
        stats=json.loads((batch/'report.json').read_text())
        parents=[bytes(map(int,s.split())) for s in (batch/'parents.txt').read_text().splitlines()]
        require(len(parents)==stats['parents'] and len(set(parents))==len(parents) and
                set(parents)<=expected-seen,'Incorrect parent batch')
        seen.update(parents);keys=generate(parents,raw,covered);covered.update(keys);pool=set(keys)
        require(len(pool)==stats['normalized'],'Incorrect number of normalized candidates')
        lifted=stats.get('lifted',0)
        if (batch/'insertion-words.txt.gz').exists():
            require(replay_words(batch/'insertion-words.txt.gz',pool)==lifted,'Incorrect lifted word count')
        else:require(lifted==0,'Missing insertion words')
        need=len(pool)
        for success,left in stats['stages']:
            require(min(success,left)>=0 and success+left==need,'Incomplete cut-filter accounting')
            need=left
        require(need==stats['words'] and replay_words(batch/'words.txt.gz',pool)==need,'Missing final words')
        lifted_count+=lifted;last_count+=need
    if not partial:
        summary=json.loads((results/'summary.json').read_text())
        require(ranks==set(range(5040)) and expected==seen,'Incomplete parent coverage')
        require(summary==dict(closed_ranks=len(ranks),parents=len(seen),actual_insertions=len(raw),
                             normalized=len(covered),batches=len(list(results.glob('batch-*')))),
                'Endgame summary does not match the reconstructed families')
    print(f'{len(seen)} length-19 parents, {len(raw):,} distinct physical insertions, '
          f'{len(covered):,} normalized 20-card decks, {lifted_count:,} lifted and {last_count:,} final words replayed.')

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('closures',type=Path)
    ap.add_argument('results',type=Path)
    ap.add_argument('--partial',action='store_true')
    args=ap.parse_args();audit(args.closures,args.results,args.partial)
