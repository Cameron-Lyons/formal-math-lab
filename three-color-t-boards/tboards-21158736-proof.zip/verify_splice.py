"""Independently verify the splice certificate using Cartesian T placements."""
import argparse
from itertools import permutations, product
import json
from pathlib import Path


CERTIFICATE = Path(__file__).with_name("splice_witnesses.json")
EXTENSION = CERTIFICATE.with_name("splice_extension.json")
FURTHER = CERTIFICATE.with_name("splice_further.json")
TRANSFER = CERTIFICATE.with_name("splice_transfer.json")
PATTERNS = set(product("012", repeat=4))
TERNARY_DIGITS = bytes.maketrans(b"012", bytes(range(3)))
ACTIONS = [(str.maketrans("012", "".join(colors)), reflect)
           for colors in permutations("012") for reflect in (False, True)]


def split_rows(flat, start, stop):
    """Decode the rows with indices start through stop-1."""
    if len(flat) != stop * stop - start * start or set(flat) - set("012"):
        raise ValueError(f"invalid encoding for rows {start} through {stop - 1}")
    return [flat[r*r - start*start:(r+1)**2 - start*start] for r in range(start, stop)]


def patterns(rows, start):
    grid = {(j-r, -r): color for r, row in enumerate(rows, start)
            for j, color in enumerate(row)}
    seen = set()
    for x, y in grid:
        cells = ((x, y+1), (x-1, y), (x, y), (x+1, y))
        if all(cell in grid for cell in cells):
            pattern = tuple(grid[cell] for cell in cells)
            if pattern in seen:
                raise ValueError(f"repeated T {pattern}")
            seen.add(pattern)
    return frozenset(seen)


def common_set(pieces):
    iterator = iter(pieces)
    first = next(iterator)
    if any(other != first for other in iterator):
        raise ValueError("pieces disagree on their T patterns")
    return first


def combine(base, extra):
    if base["cut"] != extra["cut"]:
        raise ValueError("the two certificates use different pivot rows")
    return {"cut": base["cut"], "groups": base["groups"] + extra["groups"]}


def load_all(base_path=CERTIFICATE):
    from prepare_splice_transfer import expand_transfer
    sources = {path.stem: json.loads(path.read_text()) for path in (EXTENSION, FURTHER)}
    sources[CERTIFICATE.stem] = json.loads(base_path.read_text())
    transfer = expand_transfer(json.loads(TRANSFER.read_text()), sources)
    return combine(combine(combine(sources[CERTIFICATE.stem], sources[EXTENSION.stem]),
                           sources[FURTHER.stem]), transfer)


def verify(data):
    cut = data["cut"]
    if not 0 < cut < 9 or not data["groups"]:
        raise ValueError("expected a nonempty certificate with an interior cut")
    signatures = set()
    # A row-wise image of the full upper prefix determines its symmetry action.
    marker_actions = {}
    representatives = cap_count = tail_count = 0
    for index, group in enumerate(data["groups"]):
        pivot = group["pivot"]
        split_rows(pivot, cut, cut+1)
        caps, tails = group["caps"], group["tails"]
        for pieces in (caps, tails):
            if not pieces or len(pieces) != len(set(pieces)):
                raise ValueError(f"empty or duplicate pieces in group {index}")
        markers = {tuple(split_rows(cap, 0, cut)) + (pivot,) for cap in caps}
        for marker in markers:
            for action, (palette, reflected) in enumerate(ACTIONS):
                image = tuple((row[::-1] if reflected else row).translate(palette) for row in marker)
                if marker_actions.setdefault(image, action) != action:
                    raise ValueError(f"ambiguous symmetry for marker {marker}")
        upper = common_set(patterns(split_rows(cap, 0, cut) + [pivot], 0)
                           for cap in caps)
        lower = common_set(patterns([pivot] + split_rows(tail, cut+1, 10), cut)
                           for tail in tails)
        if upper & lower or upper | lower != PATTERNS:
            raise ValueError(f"patterns do not partition all 81 in group {index}")
        key = (pivot, upper)
        if key in signatures:
            raise ValueError(f"duplicate group signature at group {index}")
        signatures.add(key)
        representatives += len(caps) * len(tails)
        cap_count += len(caps)
        tail_count += len(tails)
    return len(signatures), cap_count, tail_count, representatives, 12 * representatives


def check_pivot_orbit(task):
    """Check every image in a single orbit of pivot rows, using exact board encodings."""
    pivot_key, groups, earlier = task
    positions = {(j-r, -r): r*r+j for r in range(10) for j in range(2*r+1)}
    windows = []
    for x, y in positions:
        cells = ((x, y+1), (x-1, y), (x, y), (x+1, y))
        if all(cell in positions for cell in cells):
            windows.append(tuple(positions[cell] for cell in cells))
    if len(windows) != 81:
        raise ValueError("incorrect placement count")
    powers = [1 << i for i in range(81)]
    all_patterns = (1 << 81) - 1
    boards = set()
    for group in groups:
        for cap, tail in product(group["caps"], group["tails"]):
            rows = split_rows(cap + group["pivot"] + tail, 0, 10)
            flat = "".join(rows)
            mirror = "".join(row[::-1] for row in rows)
            for palette, reflected in ACTIONS:
                image = (mirror if reflected else flat).translate(palette)
                # Fixed width makes the base-three integer an exact board identifier.
                key = int(image, 3)
                if key in boards:
                    raise ValueError("duplicate full board")
                boards.add(key)
                digits = image.encode("ascii").translate(TERNARY_DIGITS)
                seen = 0
                for t, l, m, r in windows:
                    seen |= powers[27*digits[t] + 9*digits[l] + 3*digits[m] + digits[r]]
                if seen != all_patterns:
                    raise ValueError(f"invalid full board: {image}")
    if not earlier.issubset(boards):
        raise ValueError(f"an earlier board is absent at pivot {pivot_key}")
    return len(boards)


def pivot_orbit(row):
    return min((row[::-1] if reflected else row).translate(palette)
               for palette, reflected in ACTIONS)


def expanded_tasks(data):
    """Partition the images and the earlier witnesses by their exact pivot orbit."""
    by_pivot = {}
    for g in data["groups"]:
        by_pivot.setdefault(pivot_orbit(g["pivot"]), []).append(g)
    previous = json.loads(CERTIFICATE.with_name("extended_family.json").read_text())
    earlier = {key: set() for key in by_pivot}
    for rows in previous:
        key = pivot_orbit(rows[data["cut"]])
        if key not in earlier:
            raise ValueError(f"earlier pivot orbit {key} is missing")
        earlier[key].add(int("".join(rows), 3))
    tasks = [(key, groups, earlier[key]) for key, groups in by_pivot.items()]
    return tasks, len(previous)


def verify_expanded(data, expected, jobs=1):
    """Distinct pivot orbits partition all images, so their exact counts add."""
    tasks, earlier_count = expanded_tasks(data)
    if jobs == 1:
        count = sum(map(check_pivot_orbit, tasks))
    else:
        from concurrent.futures import ProcessPoolExecutor
        with ProcessPoolExecutor(max_workers=jobs) as pool:
            count = sum(pool.map(check_pivot_orbit, tasks))
    if count != expected:
        raise ValueError("expanded count differs from splice count")
    print(f"Checked all {count:,} full images, including all {earlier_count:,} earlier boards.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", type=Path, nargs="?", default=CERTIFICATE)
    parser.add_argument("--with-extension", action="store_true",
                        help="include the additional groups and verify the combined count")
    parser.add_argument("--all", action="store_true", help="include every certificate layer, including transferred tails")
    parser.add_argument("--expand", action="store_true", help="also check every labeled board directly")
    parser.add_argument("--jobs", type=int, default=1, help="parallel workers for the expanded check")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    if args.all:
        certificate = load_all(args.certificate)
    else:
        certificate = json.loads(args.certificate.read_text())
        if args.with_extension:
            certificate = combine(certificate, json.loads(EXTENSION.read_text()))
    groups, caps, tails, representatives, labeled = verify(certificate)
    print(f"Verified {groups:,} groups, {caps:,} caps, and {tails:,} tails.")
    print(f"{representatives:,} disjoint symmetry families give {labeled:,} labeled boards.")
    if args.expand:
        verify_expanded(certificate, labeled, args.jobs)
