"""Summarize the all-order pilot and compare with completed range-search logs."""
import csv
import gzip
import math
import re
import statistics
import sys
from pathlib import Path


def ranks(values):
    sort = sorted(range(len(values)), key=values.__getitem__)
    out = [0.] * len(values)
    i = 0
    while i < len(sort):
        j = i + 1
        while j < len(sort) and values[sort[i]] == values[sort[j]]:
            j += 1
        for v in sort[i:j]:
            out[v] = (i + j - 1) / 2
        i = j
    return out


def rho(a, b):
    return statistics.correlation(ranks(a), ranks(b))


def quantiles(data):
    data = sorted(data)
    return [round(data[round((len(data) - 1) * p)], 3) for p in [0, .5, .9, .95, .99, 1]]


def main(profile, log_paths):
    source = Path(profile)
    with (gzip.open(source, 'rt') if source.suffix == '.gz' else source.open()) as file:
        rows = [{k: float(v) for k,v in r.items()} for r in csv.DictReader(file)]
    if len(rows) != 5040 or [int(r['rank']) for r in rows] != list(range(5040)):
        raise ValueError('Incomplete profile')
    k = int(next(col[5:] for col in rows[0] if col.startswith('empty')))
    logs = {}
    for path in log_paths:
        for line in Path(path).read_text().splitlines():
            if not line.startswith('order '):
                continue
            def field(name):
                return float(re.search(r'(?:^| )'+name+r' (\S+)',line)[1])
            logs[int(field('order'))] = (field('seconds'),field('comparisons'),field('leaf'))
    def total(key):
        return int(sum(r[key] for r in rows))
    for key in ['sample_pairs','first_misses','unbonded','canonical',f'empty{k}',f'cut{k+1}',f'cut{k+2}','union_later','remaining',
                'unbonded_cut1','unbonded_cut2','unbonded_union']:
        if key not in rows[0]:
            continue
        print(key,total(key))
    print(f'k{k+1} suffix fails', sum(not r[f'tail{k+1}'] for r in rows),f'k{k+2} suffix fails',sum(not r[f'tail{k+2}'] for r in rows))
    for key in ['canonical','remaining','tree_per_head']:
        x=[r[key] for r in rows]; order=sorted(range(len(x)),key=x.__getitem__,reverse=True)
        print(key,'quantiles 0,50,90,95,99,100',quantiles(x),'zeros',x.count(0))
        print('top 1,5,10 pct cumulative shares',[round(sum(x[i] for i in order[:round(len(x)*f)])/sum(x),3) for f in [.01,.05,.1]],'top shapes',order[:15])
    if not logs:
        return
    keys=sorted(logs); ar=[logs[t][0] for t in keys]; ce=[logs[t][1] for t in keys]; leaf=[logs[t][2] for t in keys]
    print('completed ranks',len(keys),'rank extent',min(keys),max(keys),'observed wall second quantiles',quantiles(ar))
    for key in ['first_misses','unbonded','canonical','remaining','tree_per_head']:
        x=[rows[t][key] for t in keys]
        print('rank correlations',key,'seconds',round(rho(x,ar),3),'observed comparisons',round(rho(x,ce),3),'observed leaves',round(rho(x,leaf),3))
    # Nearest logged shapes in two standardized log-features. Keep whole rank
    # ranges in the same validation fold to test extrapolating beyond neighbors.
    def coords(r):
        return math.log1p(r['canonical']),math.log1p(r['tree_per_head'])
    zs=[coords(r) for r in rows]; scale=[statistics.pstdev(z[j] for z in zs) for j in (0,1)]
    def predict(t,training):
        def dist(other):
            return sum(((zs[t][j]-zs[other][j])/scale[j])**2 for j in (0,1))
        nn=sorted(training,key=dist)[:12]
        return statistics.mean(logs[k][0] for k in nn)
    if len(keys)<32:
        return
    test=[predict(t,[j for j in keys if j//32%4 != t//32%4]) for t in keys]
    print('held-out 32-rank block validation runtime rank correlation',round(rho(test,ar),3),'predicted/actual time',round(sum(test)/sum(ar),3))
    pred=[logs[t][0] if t in logs else predict(t,keys) for t in range(5040)]
    print('nearest-neighbor extrapolation in worker-wall hours',round(sum(pred)/3600,2),'ranks outside training range',sum(any(zs[t][j]<min(zs[k][j] for k in keys) or zs[t][j]>max(zs[k][j] for k in keys) for j in (0,1)) for t in range(5040)))
    print('This estimate is for the logged algorithm and machine load; it does not account for later changes.')


if __name__=='__main__':
    main(sys.argv[1],sys.argv[2:])
