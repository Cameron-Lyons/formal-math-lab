#pragma once
#include "head_family.hpp"
#include "tail_fiber.hpp"
#include "quadrant.hpp"
#include <filesystem>
#include <fstream>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
// A fixed suffix defines a cartesian product of possible dual prefix and
// suffix rows. Further fix (a) the last high prefix label and (b) its first
// low label. Both rules depend only on the normalized prefix and low count.
namespace dual_family {
using Bits=std::array<uint64_t,6>;
using HF=head_family::Index<11>;
struct Mapped{
 const Bits* rows;size_t bytes;
 Mapped(const std::filesystem::path& p,size_t count):bytes(count*sizeof(Bits)){
  int fd=open(p.c_str(),O_RDONLY);struct stat st;if(fd<0||fstat(fd,&st)||uint64_t(st.st_size)!=bytes)throw std::runtime_error("Invalid group table: "+p.string());rows=(const Bits*)mmap(nullptr,bytes,PROT_READ,MAP_SHARED,fd,0);close(fd);if(rows==MAP_FAILED)throw std::runtime_error("Cannot map group table");
 }
 ~Mapped(){munmap((void*)rows,bytes);}Mapped(const Mapped&)=delete;
};
inline bool hit(const Bits& x,const Bits& y){for(unsigned j=0;j<x.size();j++)if(x[j]&y[j])return true;return false;}
struct Rule {unsigned b,classes;uint32_t accepted;bool all()const{return accepted==(1u<<classes)-1;}};
struct Check{
 Mapped prefix,tail;
 std::unique_ptr<Mapped> maximum;
 explicit Check(const std::filesystem::path& root,bool detailed):prefix(root/"head-family19.bin",HF::offset(9)),tail(root/"tail19-fibers/group-and.u64",tail_fiber::base[128]){
  if(detailed)maximum=std::make_unique<Mapped>(root/"tail19-fibers/group-and-by-largest-position.u64",7ull*tail_fiber::base[128]);
 }
 bool every(unsigned level,unsigned local,const Bits& t,int& fuel)const{
  if(hit(prefix.rows[HF::offset(level)+local],t))return true;
  if(level>=8||fuel--<=0)return false;
  for(unsigned j=0;j<11-level;j++)if(!every(level+1,local*(11-level)+j,t,fuel))return false;
  return true;
 }
 template<class P,class S>Rule get(const P& values,const S& suffix,int budget=24)const{
  auto group=head_family::from_suffix<19,11>(suffix);unsigned b=group.b,a=11-b;
  unsigned small=0,key=0,used=0,number=0;
  // Dual tail contains actual value 7-i at position 7-v for low v=suffix[i].
  for(int i=6;i>=0;i--){unsigned v=suffix[i];if(v>7)continue;unsigned pos=7-v;small|=1u<<(6-i);key=key*(7-number)+std::popcount(((1u<<pos)-1)&~used);used|=1u<<pos;++number;}
  unsigned tid=tail_fiber::base[small]+key;Rule rule{b,a*std::max(1u,b),0};auto all=(1u<<rule.classes)-1;
  int fuel=budget;if(every(b,group.local,tail.rows[tid],fuel)){rule.accepted=all;return rule;}
  for(unsigned lo=0;lo<std::max(b,1u);lo++){
   auto& t=maximum&&b?maximum->rows[7ull*tid+7-values[lo]]:tail.rows[tid];
   int work=budget;if(every(b,group.local,t,work)){rule.accepted|=((1u<<a)-1)<<(lo*a);continue;}
   for(unsigned hi=0;hi<a;hi++){
    int steps=budget;if(every(b+1,group.local*a+hi,t,steps))rule.accepted|=1u<<(lo*a+hi);
   }
  }
  return rule;
 }
 template<class W>static unsigned feature(const W& w,unsigned b){
  unsigned lo=0,hi=0;if(b)for(auto r:w)if(unsigned(r)<b){lo=r;break;}
  for(auto it=w.rbegin();it!=w.rend();++it)if(unsigned(*it)>=b){hi=10-*it;break;}
  return lo*(11-b)+hi;
 }
};
}
