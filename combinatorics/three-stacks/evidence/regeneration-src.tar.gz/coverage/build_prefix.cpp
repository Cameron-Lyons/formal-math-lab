#include "prefix.hpp"
#include <iostream>
int main(int argc,char**argv){
    using namespace prefix;
    if(argc!=2 && argc!=4)throw std::runtime_error("usage: build_prefix output-file [first-rank past-last-rank]");
    int first=argc==4?std::stoi(argv[2]):0,end=argc==4?std::stoi(argv[3]):count;
    if(first<0 || first>=end || end>count)throw std::runtime_error("Invalid prefix interval");
    auto shapes=layout::layouts(size);
    std::array<unsigned char,size> word;
    auto start=permutation(first);
    std::copy(start.begin(),start.end(),word.begin());
    std::ofstream out(argv[1],std::ios::binary);
    if(!out)throw std::runtime_error("Cannot create output");
    int seen=first;
    do {
        Mask mask{};
        for(unsigned j=0;j<shapes.size();++j){
            layout::Prepare prep{word.data(),size,shapes[j]};
            if(prep.test())add(mask,j);
        }
        out.write(reinterpret_cast<const char*>(mask.data()),sizeof(mask));
        if((++seen%362880)==0)std::cerr<<seen<<" prefixes\n";
        if(seen==end)break;
    }while(std::next_permutation(word.begin(),word.end()));
    if(seen!=end || !out)throw std::runtime_error("Prefix enumeration failed");
}
