// Auditing only: decode every source-prefix/suffix-order record into physical
// cards, check its admissibility, and check the represented subsets are disjoint.
std::uint64_t ordinal_key(const std::uint8_t *values, int length) {
  std::uint64_t key = 0;
  for (int i = 0; i < length; ++i) {
    unsigned smaller = 0;
    for (int j = 0; j < length; ++j) smaller += values[j] < values[i];
    key = (key << 4) + smaller;
  }
  return key;
}

void check_geometry(const Geometry &geo, int ell,
                    const std::set<Small> &patterns,
                    const std::set<Small> &opposite, std::ostream &result = std::cout) {
  auto allowed = [](const std::set<Small> &seeds) {
    std::set<std::uint64_t> result;
    for (const auto &word : seeds) {
      std::uint64_t key = 0;
      for (int digit : word) key = (key << 4) + digit;
      result.insert(key);
    }
    return result;
  };
  auto permitted_head = allowed(patterns), permitted_dual = allowed(opposite);
  std::set<unsigned> physical_suffix_sets;
  for (const auto &embedding : geo.codec.labels) {
    if (!std::is_sorted(embedding.front.begin(), embedding.front.end()) ||
        !std::is_sorted(embedding.back.begin(), embedding.back.end()))
      throw std::logic_error("Embedding values out of order");
    unsigned head_values = 0, back_values = 0;
    for (auto v : embedding.front) head_values |= 1u << v;
    for (auto v : embedding.back) back_values |= 1u << v;
    if (std::popcount(head_values) != int(cut) ||
        std::popcount(back_values) != int(ordinary) || (head_values & back_values) ||
        (head_values | back_values) != (1u << n) - 2 ||
        !physical_suffix_sets.insert(back_values).second)
      throw std::logic_error("Invalid or duplicate physical embedding");
  }
  std::set<std::uint64_t> head_ids;
  for (const auto &info : geo.head_info) {
    auto sorted = info.word;
    std::sort(sorted.begin(), sorted.end());
    for (unsigned i = 0; i < cut; ++i)
      if (sorted[i] != i) throw std::logic_error("Malformed normalized source head");
    if (!head_ids.insert(ordinal_key(info.word.data(), cut)).second ||
        !permitted_head.contains(ordinal_key(info.word.data(), geo.k)))
      throw std::logic_error("Invalid or duplicate head");
  }
  std::vector<std::uint64_t> keys;
  std::uint64_t decks = 0, records = 0;
  for (unsigned h = 0; h <= ordinary; ++h) {
    std::vector<int> ordering(h);
    std::iota(ordering.begin(), ordering.end(), ordinary - h);
    for (const auto &bucket : geo.buckets[h]) {
      keys.clear();
      for (const auto &record : bucket) {
        const auto &values = geo.codec.labels.at(record.set);
        const unsigned high = std::count_if(values.back.begin(), values.back.end(),
                                            [ell](int v) { return v >= n - ell; });
        if (h != high)
          throw std::logic_error("Wrong number of constrained physical suffix labels");
        auto &head = geo.head_info.at(record.head).word;
        Deck position{}, opposite_head{};
        for (unsigned i = 0; i < cut; ++i)
          position[values.front[head[i]]] = i;
        // One representative: position all ordinary low cards before the highs.
        // Every completion preserves all relative positions between high cards.
        for (unsigned i = 0; i < ordinary; ++i) {
          auto rank = i < ordinary - h ? int(i) : ordering[i - (ordinary - h)];
          position[values.back[rank]] = cut + i;
        }
        for (int j = 0; j < ell; ++j) opposite_head[j] = n - 1 - position[n - 1 - j];
        if (!permitted_dual.contains(ordinal_key(opposite_head.data(), ell)))
          throw std::logic_error("Record contains physical decks outside the family");
        keys.push_back(std::uint64_t(record.head) * embeddings + record.set);
        decks += factorial_of(ordinary) / factorial_of(h);
      }
      std::sort(keys.begin(), keys.end());
      if (std::adjacent_find(keys.begin(), keys.end()) != keys.end())
        throw std::logic_error("Two records describe the same physical subset");
      records += keys.size();
      std::next_permutation(ordering.begin(), ordering.end());
    }
  }
  if (records != geo.skeletons || decks != geo.expected)
    throw std::logic_error("Duplicate records or incorrect deck count");
  result << "Physical membership, disjoint records: " << geo.k << ' ' << ell
            << ' ' << records << " records " << decks << " permutations.\n";
}
