// Enumerate inputs whose 11-card heads on both sides of sorting duality have
// at most W reachable layouts in the two-parked-card prefix table.
#define CARD_COUNT 19
#include "join_tables.hpp"
#include <unordered_map>
namespace {
constexpr unsigned size=20, k=11, positive=size-1;
using Pattern = std::array<unsigned,k>;
using Cards = std::array<unsigned,size>;
struct Menu {
  std::vector<Pattern> patterns;
  std::array<std::unordered_map<uint64_t,std::vector<unsigned>>,k+1> by_key;

  Menu(const char* source, unsigned limit, std::ostream& ids){
    TableFile prefix(source,heads);
    Pattern word;std::iota(word.begin(),word.end(),0);
    for(Id rank=0;rank<heads;rank++,std::next_permutation(word.begin(),word.end())){
      if(weight(prefix[rank])>int(limit))continue;
      ids<<rank<<'\n';
      for(unsigned d=0;d<=k;d++){
        uint64_t key=0;
        for(unsigned v:word)key=(key<<4)|(v<d?15:v);
        by_key[d][key].push_back(patterns.size());
      }
      patterns.push_back(word);
    }
  }
};
struct Scan {
  Menu& menu;Cards p{},dual{};uint64_t total=0,representatives=0;
  void tail(unsigned pos,unsigned low,const std::array<unsigned,k>& high,unsigned next){
    if(pos==positive){
      ++total;
      for(unsigned i=0;i<size;i++)dual[positive-p[i]]=positive-i;
      if(dual<p)return;
      ++representatives;
      std::cout<<"Hard 1";for(auto x:p)std::cout<<' '<<x+1;std::cout<<'\n';return;
    }
    for(unsigned v=low;v;v&=v-1){
      unsigned bit=v&-v;p[pos]=std::countr_zero(bit);tail(pos+1,low^bit,high,next);
    }
    if(next){p[pos]=high[next-1];tail(pos+1,low,high,next-1);}
  }
  void enumerate(){
    constexpr unsigned low_limit=positive-k;
    for(unsigned set=0;set<(1u<<positive);set++){
      if(std::popcount(set)!=int(k))continue;
      Pattern values{};unsigned j=0;
      for(auto bits=set;bits;bits&=bits-1)values[j++]=std::countr_zero(bits)+1;
      for(const auto& a:menu.patterns){
        std::array<unsigned,size> position;position.fill(k);
        unsigned known_positions=0;
        for(unsigned i=0;i<k;i++){
          p[i]=values[a[i]];position[p[i]]=i;
          if(p[i]>low_limit)known_positions|=1u<<i;
        }
        unsigned missing=k-std::popcount(known_positions);
        uint64_t key=0;
        for(unsigned x=positive;x>low_limit;--x){
          unsigned i=position[x];
          key=(key<<4)|(i==k?15:missing+std::popcount(known_positions>>(i+1)));
        }
        const auto& dict=menu.by_key[missing];auto hit=dict.find(key);
        if(hit==dict.end())continue;
        unsigned low=(((1u<<low_limit)-1)&~set)<<1;
        for(auto id:hit->second){
          const auto& b=menu.patterns[id];std::array<unsigned,k> high{};
          for(unsigned i=0;i<k;i++)if(b[i]<missing)high[b[i]]=positive-i;
          tail(k,low,high,missing);
        }
      }
    }
  }
};
}
int main(int ac,char**av){
  if(ac!=4)throw std::runtime_error("usage: weak_corners PREFIX11 MAXIMUM_LAYOUTS NEW_HEAD_LIST");
  std::ios::sync_with_stdio(false);std::cin.tie(nullptr);
  std::ofstream ids(av[3]);Menu menu(av[1],std::stoul(av[2]),ids);ids.close();
  if(!ids)throw std::runtime_error("Cannot write head ranks");
  Scan scan{menu};scan.enumerate();
  if(!std::cout)throw std::runtime_error("Incomplete candidate output");
  std::cerr<<"patterns "<<menu.patterns.size()<<" decks "<<scan.total<<" representatives "<<scan.representatives<<'\n';
}
