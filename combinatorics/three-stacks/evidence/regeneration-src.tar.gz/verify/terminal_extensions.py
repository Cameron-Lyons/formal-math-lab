"""Enumerate and replay extensions of the five final 19-card contractions."""

import argparse
import gzip
from pathlib import Path

from corner_counts import patterns
from replay import replay


def dual(p):
    q = [0] * len(p)
    for i, v in enumerate(p):
        q[len(p) - v] = len(p) - i
    return tuple(q)


def extend(p):
    for value in range(2, len(p) + 2):
        lifted = tuple(x + (x >= value) for x in p)
        for position in range(len(p)):
            yield lifted[:position] + (value,) + lifted[position:]


def normalize(p, length):
    front = p[:length]
    ranks = {x:i for i,x in enumerate(sorted(front))}
    return tuple(ranks[x] for x in front)


def candidates(folder):
    seeds = set()
    names = ["contract19-final.word", "corners8-contract19-words.gz", "shaikh10x9-contract19-words.gz"]
    for name in names:
        opener = gzip.open if name.endswith(".gz") else open
        with opener(folder / name, "rt") as stream:
            for line in stream:
                *raw, word = line.split()
                p = tuple(map(int, raw))
                if sorted(p) != list(range(1, 20)) or p[-1] != 1 or not replay(p, word):
                    raise ValueError("Invalid archived 19-card contraction")
                seeds.add(p)
    if len(seeds) != 5:
        raise ValueError("Unexpected number of source records")
    seeds |= {dual(p) for p in seeds}
    rows = {q for p in seeds for q in extend(p)}
    if rows != {dual(p) for p in rows}:
        raise ValueError("Missing dual in extension family")
    shaikh = tuple(map(int, (folder / "shaikh22.txt").read_text().split()))
    pv8, pv12 = patterns(8), patterns(12)
    alt9, alt10 = patterns(9, seed=shaikh), patterns(10, seed=shaikh)

    def in_corners(p):
        q = dual(p)
        return (normalize(p, 12) in pv12 or normalize(q, 12) in pv12
                or (normalize(p, 8) in pv8 and normalize(q, 8) in pv8)
                or (normalize(p, 10) in alt10 and normalize(q, 9) in alt9)
                or (normalize(q, 10) in alt10 and normalize(p, 9) in alt9))
    outside = {p for p in rows if not in_corners(p)}
    canonical = {min(p, dual(p)) for p in outside}
    if (len(seeds), len(rows), len(outside), len(canonical)) != (9, 2917, 2409, 1208):
        raise ValueError("Unexpected family size")
    return canonical


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write-candidates", type=Path)
    args = parser.parse_args()
    folder = Path(__file__).with_name("published")
    pending = candidates(folder)
    if args.write_candidates:
        with args.write_candidates.open("w") as out:
            for p in sorted(pending):
                print("Hard 1", *p, file=out)
        return
    with gzip.open(folder / "terminal19-extensions-words.gz", "rt") as words:
        for line in words:
            *raw, word = line.split()
            p = tuple(map(int, raw))
            if p not in pending or len(word) != 80 or not replay(p, word):
                raise ValueError("Duplicate, unmatched, or invalid 20-card sorting word")
            pending.remove(p)
    if pending:
        raise ValueError(f"Missing {len(pending)} words")
    print("Replayed all 1,208 sorting words for 2,409 additional normalized decks.")


if __name__ == "__main__":
    main()
