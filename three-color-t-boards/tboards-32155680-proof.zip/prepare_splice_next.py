"""Generate the fifth splice certificate, allowing disjoint tail ranges on an existing signature."""
import argparse
import json
from pathlib import Path
import subprocess

from prepare_prefix_classifier import LAYERS, generate_classifier
from prepare_splice_extension import generate_packed_data, total
from prepare_splice_transfer import expand_transfer, signature

ROOT = Path(__file__).resolve().parent
NEXT = ("SpliceNextData", "splice_next.json")


def validate_ranges(sources, new):
    """Check that each claimed extension names its actual original cap family."""
    latest_tail = {}
    for source in sources.values():
        for group in source["groups"]:
            key = signature(group["caps"][0], group["pivot"])
            if key in latest_tail:
                raise ValueError("the four historical layers must have distinct signatures")
            latest_tail[key] = group["tails"][-1]
    for i, group in enumerate(new["groups"]):
        caps, pivot, tails = group["caps"], group["pivot"], group["tails"]
        if not caps or not tails:
            raise ValueError(f"group {i} requires at least one cap and tail")
        key = signature(caps[0], pivot)
        if "extends" in group:
            parent = group["extends"]
            layer, index = parent["layer"], parent["index"]
            if layer not in sources or type(index) is not int or not 0 <= index < len(sources[layer]["groups"]):
                raise ValueError(f"group {i} names an unknown original group")
            original = sources[layer]["groups"][index]
            if (caps, pivot) != (original["caps"], original["pivot"]):
                raise ValueError(f"group {i} does not extend its named cap family")
            if tails[0] <= latest_tail[key]:
                raise ValueError(f"group {i} overlaps an earlier tail interval")
        elif key in latest_tail:
            raise ValueError(f"group {i} repeats a signature without identifying the original group")
        latest_tail[key] = tails[-1]


def write_theorem(directory, layers, count):
    group_list = layers[0][0] + ".groups"
    checked = layers[0][0] + ".checked"
    for module, _ in layers[1:]:
        group_list = f"({group_list} ++ {module}.groups)"
        checked = f"List.forall_mem_append.mpr ⟨{checked}, {module}.checked⟩"
    sizes = ",\n      ".join(module + ".size_sum" for module, _ in layers[1:])
    proof = f"""import SpliceRanges
import SpliceNextPrefixData

-- Generated from five splice certificates by prepare_splice_next.py.
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace TBoards
open Splice

private theorem firstLayerSize : (SpliceData.groups.map Group.size).sum = {total(layers[0][1]) // 12} := by
  decide +kernel

private def nextGroups : List Group :=
  {group_list}

private theorem nextChecked : ∀ g ∈ nextGroups, g.Checked :=
  {checked}

private theorem nextCut : ∀ g ∈ nextGroups, g.k = 5 := by decide +kernel

private theorem nextDistinct : (nextGroups.flatMap Group.boards).Nodup := by
  apply groups_nodup_of_separated 5 nextGroups nextChecked nextCut
  decide +kernel

/-- Distinct labeled boards certified by five row-five splice layers. -/
theorem at_least_{count} :
    ∃ f : Fin {count} → Board, (∀ i, Valid (f i)) ∧
      (∀ i j, f i = f j → i = j) := by
  apply prefix_orbit_lower_bound_of_nodup 5 nextGroups SpliceNextPrefixData.classify {count}
    nextChecked nextCut nextDistinct SpliceNextPrefixData.classified
  simp only [nextGroups, List.map_append, List.sum_append, firstLayerSize,
      {sizes}] <;> decide

end TBoards

#print axioms TBoards.at_least_{count}
"""
    path = directory / "SpliceNextCertificates.lean"
    if not path.exists() or path.read_text() != proof:
        path.write_text(proof)


def generate_next(directory):
    layers = [(module, json.loads((directory / filename).read_text()))
              for module, filename in [*LAYERS, NEXT]]
    sources = {Path(filename).stem: data for (_, filename), (_, data) in zip(LAYERS[:3], layers[:3])}
    transfer = expand_transfer(layers[3][1], sources)
    sources["splice_transfer"] = transfer
    new = layers[-1][1]
    validate_ranges(sources, new)
    generate_packed_data(layers[0][1], new, directory, further=True,
                         namespace=NEXT[0], witness=NEXT[1])
    generate_classifier(layers, directory, "SpliceNextPrefixData")
    count = sum(total(source) for source in sources.values()) + total(new)
    write_theorem(directory, layers, count)
    return count


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true", help="check the resulting theorem with Lean")
    args = parser.parse_args()
    count = generate_next(ROOT)
    print(f"Generated the five-layer Lean certificate for {count:,} labeled boards.", flush=True)
    if args.build:
        subprocess.run(["lake", "build", "SpliceNextCertificates"], cwd=ROOT, check=True)
