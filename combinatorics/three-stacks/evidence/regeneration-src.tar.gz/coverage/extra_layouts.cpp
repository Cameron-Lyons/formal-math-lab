// Select a small collection of three-card parking configurations by their
// ability to extend an already tested two-card cut on difficult examples.
#include "../knuth/layout.hpp"
#include "../structural/reach.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
using Deck=std::array<int,24>;
std::vector<layout::Shape> triples(int k){
    std::vector<layout::Shape> result;
    for(int a=0;a<k;a++)for(int b=0;b<k;b++)if(b!=a)
        for(int c=0;c<k;c++)if(c!=a&&c!=b){
            int w[]={a,b,c};
            for(int f=0;f<=3;f++)result.push_back({{w,w+f},{w+f,w+3}});
        }
    return result;
}
int main(int argc,char**argv){
    if(argc<5)throw std::runtime_error("usage: extra_layouts n k samples hard-stream");
    int n=std::stoi(argv[1]),k=std::stoi(argv[2]),cap=std::stoi(argv[3]);
    auto shapes=triples(k);
    std::ifstream src(argv[4]);
    if(!src)throw std::runtime_error("missing input");
    std::mt19937 rng(33314);
    std::vector<Deck> decks;
    int seen=0,flag;
    std::string tag;
    while(src>>tag>>flag){
        Deck p{};
        unsigned labels=0;
        for(int i=0;i<n;i++){
            if(!(src>>p[i])||p[i]<1||p[i]>n||(labels&(1u<<p[i])))throw std::runtime_error("invalid deck");
            labels|=1u<<p[i];--p[i];
        }
        int id=seen<cap?seen:rng()%(seen+1);++seen;
        if(id==int(decks.size())&&id<cap)decks.push_back(p);
        else if(id<cap)decks[id]=p;
    }
    auto sz=decks.size(),width=(sz+63)/64;
    std::vector<std::vector<std::uint64_t>> good(shapes.size(),std::vector<std::uint64_t>(width));
    int any=0;
    for(unsigned d=0;d<sz;d++){
        const auto& p=decks[d];Deck local=p,value;std::array<unsigned char,24> rank;
        unsigned prefix=0;for(int i=0;i<k;i++)prefix|=1u<<p[i];
        for(int i=0;i<k;i++)rank[i]=std::popcount(prefix&((1u<<p[i])-1));
        int t=0;for(unsigned bits=prefix;bits;bits&=bits-1)value[t++]=std::countr_zero(bits);
        reach::Search srch{local.data(),n,180,0,false};
        bool success=false;
        for(unsigned l=0;l<shapes.size();l++){
            const auto& shape=shapes[l];
            layout::Prepare pre{rank.data(),k,shape};
            if(!pre.test())continue;
            unsigned A=0,C=prefix;
            for(unsigned j=0;j<shape.first.size();j++){
                int x=value[shape.first[j]];local[j]=x;A|=1u<<j;C^=1u<<x;
            }
            const reach::Node empty{31,31,0,nullptr};
            const reach::Node* B=&empty;reach::Node saved[3];
            for(unsigned j=0;j<shape.second.size();j++){
                int x=value[shape.second[j]];saved[j]={x,std::min(x,B->smallest),0,B};B=&saved[j];C^=1u<<x;
            }
            srch.nodes=0;srch.exhausted=false;
            if(srch.dfs(A,B,C,k,0)){good[l][d/64]|=1ULL<<(d%64);success=true;}
        }
        any+=success;
    }
    std::vector<std::uint64_t> open(width,~0ULL);
    int training=0,holdout=0;
    std::cerr<<"seeded examples "<<decks.size()<<" supported by any 3-parked layout "<<any<<"\n";
    for(unsigned round=0;round<128;round++){
        unsigned best=0,score=0;
        for(unsigned j=0;j<good.size();j++){
            unsigned v=0;
            for(unsigned w=0;w<width;w++)v+=std::popcount(good[j][w]&open[w]&0x5555555555555555ULL);
            if(v>score){score=v;best=j;}
        }
        if(!score)break;
        for(unsigned w=0;w<width;w++){
            auto hit=good[best][w]&open[w];open[w]&=~hit;
            training+=std::popcount(hit&0x5555555555555555ULL);
            holdout+=std::popcount(hit&0xaaaaaaaaaaaaaaaaULL);
        }
        const auto& s=shapes[best];std::cout<<best<<" first";
        for(int v:s.first)std::cout<<' '<<v;
        std::cout<<" second";for(int v:s.second)std::cout<<' '<<v;
        std::cout<<" cumulative "<<training<<" "<<holdout<<'\n';
    }
}
