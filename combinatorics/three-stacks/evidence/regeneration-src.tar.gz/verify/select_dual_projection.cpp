// Choose a fixed family of 64 layout columns on deferred dual queries.
// Hold out entire dual prefix orders so repeated queries never span both sets.
#ifndef CARD_COUNT
#define CARD_COUNT 20
#endif
#include "../knuth/layout.hpp"
#include "join_tables.hpp"
#include <filesystem>
namespace fs = std::filesystem;
struct Query {
  Id head, block;
};
Head unrank(Id rank) {
  Head p;
  unsigned avail = (1u << cut) - 1, ways = heads;
  for (unsigned i = 0; i < cut; i++) {
    ways /= cut - i;
    unsigned pos = rank / ways;
    rank %= ways;
    auto tmp = avail;
    while (pos--)
      tmp &= tmp - 1;
    p[i] = std::countr_zero(tmp);
    avail ^= 1u << p[i];
  }
  return p;
}
unsigned partition(Id id) {
  id ^= id >> 16;
  id *= 0x7feb352du;
  id ^= id >> 15;
  id *= 0x846ca68bu;
  return (id ^ (id >> 16)) & 1u;
}
struct Example {
  Mask hit;
  bool train;
};
int main(int argc, char **argv) {
  if (argc < 4)
    throw std::runtime_error("usage: select-dual-projection PACKED_TAIL "
                             "SAMPLES [--columns FIXED_MENU] SPOOL_DIR...");
  TableFile tail(argv[1], blocks, true);
  unsigned cap = std::stoul(argv[2]);
  std::vector<Query> population;
  std::uint64_t seen = 0;
  std::mt19937_64 rng(39513);
  std::vector<unsigned> fixed;
  int start = 3;
  if (std::string(argv[3]) == "--columns") {
    if (argc < 6)
      throw std::runtime_error("Missing fixed column file or spool");
    std::ifstream file(argv[4]);
    unsigned c;
    while (file >> c) {
      if (c >= columns ||
          std::find(fixed.begin(), fixed.end(), c) != fixed.end())
        throw std::runtime_error("Incorrect fixed columns");
      fixed.push_back(c);
    }
    if (!file.eof() || fixed.empty() || fixed.size() > 64)
      throw std::runtime_error("Invalid fixed column file");
    start = 5;
  }
  for (int i = start; i < argc; i++) {
    fs::path dir = argv[i];
    std::vector<fs::path> files;
    for (auto f : fs::directory_iterator(dir))
      if (f.path().extension() == ".bin")
        files.push_back(f.path());
    std::sort(files.begin(), files.end());
    for (auto &path : files) {
      std::ifstream in(path, std::ios::binary);
      Query q;
      while (in.read(reinterpret_cast<char *>(&q), sizeof(q))) {
        if (q.head >= heads || q.block >= blocks)
          throw std::runtime_error("Invalid spool key");
        seen++;
        if (population.size() < cap)
          population.push_back(q);
        else {
          auto at = rng() % seen;
          if (at < cap)
            population[at] = q;
        }
      }
      if (!in.eof() || in.gcount())
        throw std::runtime_error("Truncated spool query");
    }
  }
  if (population.empty())
    throw std::runtime_error("No deferred queries found");
  std::sort(population.begin(), population.end(),
            [](Query a, Query b) { return a.head < b.head; });
  auto shapes = layout::layouts(cut);
  std::vector<Example> sample;
  unsigned prev = heads, distinct = 0, train = 0, test = 0, possible_train = 0,
           possible_test = 0;
  Mask offered{}, checked{};
  for (auto q : population) {
    if (q.head != prev) {
      ++distinct;
      prev = q.head;
      offered = {};
      checked = {};
    }
    Head word = unrank(q.head);
    auto t = tail[q.block];
    Example e{{}, partition(q.head) == 0};
    bool possible = false;
    for (unsigned w = 0; w < t.size(); w++) {
      for (auto bits = t[w] & ~checked[w]; bits; bits &= bits - 1) {
        auto c = std::countr_zero(bits);
        layout::Prepare prepare{word.data(), cut, shapes[64 * w + c]};
        if (prepare.test())
          offered[w] |= 1ULL << c;
      }
      checked[w] |= t[w];
      e.hit[w] = offered[w] & t[w];
      possible |= e.hit[w] != 0;
    }
    if (e.train) {
      train++;
      possible_train += possible;
    } else {
      test++;
      possible_test += possible;
    }
    sample.push_back(e);
  }
  std::cout << "Sample " << sample.size() << " of " << seen << " queries, "
            << distinct << " prefix ranks.\n"
            << "Full acceptance training " << possible_train << '/' << train
            << ", holdout " << possible_test << '/' << test << ".\n";
  std::vector<bool> done(sample.size());
  unsigned train_ok = 0, test_ok = 0;
  for (unsigned k = 0; k < (fixed.empty() ? 64 : fixed.size()); k++) {
    std::array<unsigned, columns> freq{};
    for (unsigned j = 0; j < sample.size(); j++)
      if (sample[j].train && !done[j])
        for (unsigned w = 0; w < Mask{}.size(); w++)
          for (auto bits = sample[j].hit[w]; bits; bits &= bits - 1)
            freq[64 * w + std::countr_zero(bits)]++;
    auto col = std::max_element(freq.begin(), freq.end()) - freq.begin();
    if (!fixed.empty())
      col = fixed[k];
    else if (!freq[col])
      break;
    for (unsigned j = 0; j < sample.size(); j++)
      if (!done[j] && ((sample[j].hit[col / 64] >> (col % 64)) & 1)) {
        done[j] = true;
        train_ok += sample[j].train;
        test_ok += !sample[j].train;
      }
    std::cout << k + 1 << " column " << col << " training " << train_ok
              << " holdout " << test_ok << '\n';
  }
}
