#pragma once
#include "../knuth/layout.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <numeric>
#include <stdexcept>
#include <vector>

// Last card zero, all other entries distinct and in [1,31]. Rank a list by
// its relative order. This is a mixed-radix rank using the number of earlier
// entries larger than each successive card. A decreasing word ranks last.
namespace tail {
inline int rank_order(const int *cards, int length) {
  unsigned seen = 0;
  int rank = 0;
  for (int i = 0; i < length; ++i) {
    rank = rank * (i + 1) + std::popcount(seen >> cards[i]);
    seen |= 1U << cards[i];
  }
  return rank;
}

enum Role { empty, first, second, both_first, split, both_second };

namespace detail {
// Encode stack one as a subset of positions in [initial stack; unread input].
// All positions it holds are always in index order. Stack two must already
// be decreasing from bottom to top when every transfer from it is output.
struct Continuation {
  std::array<int, 12> input{};
  int input_end = 0;
  int size = 0;

  bool sorted(int index, unsigned one, unsigned two, int target) const {
    while (target < size) {
      if (two & (1U << target)) {
        two ^= 1U << target++;
        continue;
      }
      int position = one ? std::bit_width(one) - 1 : 0;
      int card = one ? input[position] : 31;
      if (card == target) {
        one ^= 1U << position;
        ++target;
        continue;
      }
      if (index < input_end && input[index] == target) {
        ++index;
        ++target;
        continue;
      }
      int second_top = two ? std::countr_zero(two) : 31;
      if (card < second_top &&
          sorted(index, one ^ (1U << position), two | (1U << card), target))
        return true;
      if (index == input_end)
        return false;
      one |= 1U << index++;
    }
    return true;
  }
};

inline bool solve(const int *permutation, int ordinary, int role, int lower_a,
                  int lower_b) {
  // lower_a, lower_b are zero-based ranks among all *nonzero active* cards.
  int a = lower_a + 1, b = lower_b + 1;
  if (role == both_second && a < b)
    return false;
  int parked = role == empty ? 0 : role <= second ? 1 : 2;
  Continuation state;
  state.size = ordinary + 1 + parked;
  unsigned first_bits = 0, second_bits = 0;
  if (role == first || role == both_first || role == split) {
    state.input[state.input_end++] = a;
    if (role == both_first)
      state.input[state.input_end++] = b;
    first_bits = (1U << state.input_end) - 1;
  }
  if (role == second || role == both_second)
    second_bits |= 1U << a;
  if (role == split || role == both_second)
    second_bits |= 1U << b;
  int initial = state.input_end;
  std::array<int, 12> relabel{};
  for (int card = 1, i = 0; card < state.size; ++card) {
    if ((parked && card == a) || (parked == 2 && card == b))
      continue;
    relabel[i++] = card;
  }
  for (int i = 0; i < ordinary; ++i)
    state.input[state.input_end++] = relabel[permutation[i]];
  state.input[state.input_end++] = 0;
  return state.sorted(initial, first_bits, second_bits, 0);
}
} // namespace detail

struct Table {
  int ordinary, width;
  std::vector<std::uint8_t> data;

  // For layout A, B in that order (bottom to top within a stack), gapA/B
  // count ordinary suffix cards smaller than A/B. For a pair aSmaller is
  // the strict comparison A < B, also resolving a tie in gap indices.
  int column(int role, int gapA = 0, int gapB = 0,
             bool aSmaller = false) const {
    if (role == empty)
      return 0;
    if (role <= second)
      return 1 + (role - first) * (ordinary + 1) + gapA;
    int a = gapA + !aSmaller, b = gapB + aSmaller;
    return pair_column(role, a, b);
  }
  int column(const layout::Shape &shape, const int *gaps) const {
    int first_size = static_cast<int>(shape.first.size());
    int count = shape.members();
    if (count == 0)
      return 0;
    int a = first_size ? shape.first.front() : shape.second.front();
    if (count == 1)
      return column(first_size ? first : second, gaps[a]);
    int b = first_size == 2 ? shape.first.back() : shape.second.back();
    int type = first_size == 2   ? both_first
               : first_size == 1 ? split
                                 : both_second;
    return column(type, gaps[a], gaps[b], a < b);
  }
  const std::uint8_t *row(int rank) const { return data.data() + rank * width; }

  explicit Table(int cut, int n = 17) : ordinary(n - 1 - cut) {
    if (ordinary < 0 || ordinary > 8)
      throw std::invalid_argument("Need at most eight ordinary tail cards");
    width = 1 + 2 * (ordinary + 1) + 3 * (ordinary + 2) * (ordinary + 2);
    int rows = 1;
    for (int i = 2; i <= ordinary; ++i)
      rows *= i;
    data.resize(static_cast<std::size_t>(rows) * width);
    std::array<int, 10> perm{};
    std::iota(perm.begin(), perm.end(), 0);
    do {
      std::uint8_t *out =
          data.data() + rank_order(perm.data(), ordinary) * width;
      out[0] = detail::solve(perm.data(), ordinary, empty, -1, -1);
      for (int role : {first, second})
        for (int a = 0; a <= ordinary; ++a)
          out[column(role, a)] =
              detail::solve(perm.data(), ordinary, role, a, -1);
      for (int role : {both_first, split, both_second})
        for (int a = 0; a < ordinary + 2; ++a)
          for (int b = 0; b < ordinary + 2; ++b)
            if (a != b)
              out[pair_column(role, a, b)] =
                  detail::solve(perm.data(), ordinary, role, a, b);
    } while (std::next_permutation(perm.begin(), perm.begin() + ordinary));
  }

private:
  int pair_column(int role, int a, int b) const {
    return 1 + 2 * (ordinary + 1) +
           ((role - both_first) * (ordinary + 2) + a) * (ordinary + 2) + b;
  }
};
} // namespace tail
