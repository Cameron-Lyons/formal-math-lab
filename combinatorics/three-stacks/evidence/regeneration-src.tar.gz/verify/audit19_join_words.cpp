// Independently reconstruct and replay an entire sorting word for sampled
// intersections of the two physical length-19 tables.
#define CARD_COUNT 19
#include "join_tables.hpp"
#include "physical_route.hpp"
#include "../knuth/layout.hpp"
#include <filesystem>

using Machine=std::array<Word,5>;
bool finish(Machine& s, Word& path) {
  if(s[4].size()==n)return true;
  auto trial=[&](int left) {
    move(s[left],s[left+1]);path.push_back(left);
    if(finish(s,path))return true;
    path.pop_back();move(s[left+1],s[left]);return false;
  };
  if(!s[3].empty() && s[3].back()==int(s[4].size()))return trial(3);
  if(!s[2].empty() && (s[3].empty() || s[2].back()<s[3].back()) && trial(2))return true;
  if(!s[1].empty() && trial(1))return true;
  return !s[0].empty() && trial(0);
}
std::pair<Id,Id> lookup(const Word& p) {
  unsigned h=0,t=0;
  for(unsigned i=0;i<cut;i++)
    h=h*(cut-i)+std::count_if(p.begin()+i+1,p.begin()+cut,[&](int v){return v<p[i];});
  for(unsigned i=cut;i+1<n;i++)
    t=t*(i-cut+1)+std::count_if(p.begin()+cut,p.begin()+i,[&](int v){return v>p[i];});
  Word values(p.begin()+cut,p.end()-1);std::sort(values.begin(),values.end());
  unsigned set=0;
  for(unsigned j=0;j<values.size();j++)if(values[j]-1>=int(j+1))set+=choose(values[j]-1,j+1);
  return {h,t*embeddings+set};
}
void validate(const Word& p,const layout::Shape& shape) {
  Word names(p.begin(),p.begin()+cut);std::sort(names.begin(),names.end());
  Word a,b,c;
  for(int i:shape.first)a.push_back(names[i]);
  for(int i:shape.second)b.push_back(names[i]);
  for(auto it=names.rbegin();it!=names.rend();++it)
    if(std::find(a.begin(),a.end(),*it)==a.end() && std::find(b.begin(),b.end(),*it)==b.end())c.push_back(*it);
  Word reversed(p.begin(),p.begin()+cut);std::reverse(reversed.begin(),reversed.end());
  Route undo({c,b,a},reversed);
  if(!undo.find())throw std::logic_error("Positive head layout cannot be replayed");
  Machine machine;machine[0]=Word(p.rbegin(),p.rend());Word full;
  for(auto it=undo.moves.rbegin();it!=undo.moves.rend();++it){
    auto left=2-*it;move(machine[left],machine[left+1]);full.push_back(left);
  }
  if(machine[1]!=a||machine[2]!=b||machine[3]!=c||machine[0].size()!=n-cut)
    throw std::logic_error("Prefix reconstruction reached a different layout");
  if(!finish(machine,full) || full.size()!=4*n)
    throw std::logic_error("Positive continuation cannot be replayed");
  machine={};machine[0]=Word(p.rbegin(),p.rend());
  for(auto left:full)move(machine[left],machine[left+1]);
  Word goal(n);std::iota(goal.begin(),goal.end(),0);
  if(machine[4]!=goal)throw std::logic_error("Replayed output differs from the target order");
}
int main(int ac,char**av) {
  if(ac!=3)throw std::runtime_error("usage: audit19_join_words WORK DRAWS");
  std::filesystem::path dir=av[1];TableFile h((dir/"prefix11.bin").c_str(),heads);
  TableFile t((dir/"verify-tail19-packed.bin").c_str(),blocks,true);
  auto layouts=layout::layouts(cut);unsigned trials=std::stoul(av[2]);
  std::mt19937 rng(179131);Word p(n);std::iota(p.begin(),p.end()-1,1);
  std::array<unsigned,3> count{};
  for(unsigned i=0;i<trials;i++){
    std::shuffle(p.begin(),p.end()-1,rng);auto [head,block]=lookup(p);
    Mask both{};for(unsigned w=0;w<both.size();w++)both[w]=h[head][w]&t[block][w];
    unsigned hits=weight(both);if(!hits)continue;
    int choice=rng()%hits;unsigned bit=0;
    for(;bit<columns;bit++)if(((both[bit/64]>>(bit%64))&1) && choice--==0)break;
    if(bit>=layouts.size())throw std::logic_error("Invalid common layout");
    validate(p,layouts[bit]);++count[layouts[bit].members()];
  }
  std::cout<<"Sampled "<<trials<<" physical length-19 decks. Replayed full 76-move words for "
    <<count[0]<<" empty, "<<count[1]<<" one-card and "<<count[2]<<" two-card layout intersections.\n";
}
