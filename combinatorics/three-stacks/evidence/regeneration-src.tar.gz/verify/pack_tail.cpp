#include "join_tables.hpp"
int main(int argc, char **argv) {
  if (argc != 3)
    throw std::runtime_error("usage: pack-tail RAW NEW_PACKED_FILE");
  TableFile raw(argv[1], blocks);
  if (access(argv[2], F_OK) == 0)
    throw std::runtime_error("Choose a fresh output path");
  packed_tail::build(raw, argv[2]);
}
