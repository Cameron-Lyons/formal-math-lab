"""Produce or replay literal sorting words for the independent join's residue."""

import argparse
import gzip
import io
from pathlib import Path
from replay import replay


def read_decks(path):
    decks = []
    for line in path.read_text().splitlines():
        tag, indicator, *cards = line.split()
        deck = tuple(map(int, cards))
        if tag != "Hard" or indicator != "1" or sorted(deck) != list(range(1, 18)):
            raise ValueError(f"Invalid residual row: {line}")
        decks.append(deck)
    if len(set(decks)) != len(decks):
        raise ValueError("Duplicate residual rows")
    return sorted(decks)


def solve(decks, destination):
    from pysat.solvers import Solver
    from check import encode, operation_word, pair_table, unpack
    from itertools import combinations

    cards = range(1, 18)
    arrival = pair_table(cards, 17 * 16)
    a, b, clauses = encode(cards, variable_input=arrival)
    with Solver(name="cadical195", bootstrap_with=clauses) as sat:
        with (
            destination.open("wb") as raw,
            gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as zipped,
            io.TextIOWrapper(zipped, encoding="ascii") as out,
        ):
            for deck in decks:
                if not sat.solve(
                    assumptions=[arrival[x, y] for x, y in combinations(deck, 2)]
                ):
                    raise RuntimeError(f"Unsortable candidate {deck}")
                model = set(sat.get_model())
                word = operation_word(
                    deck, [unpack(deck, a, model), unpack(deck, b, model), list(cards)]
                )
                if not replay(deck, word):
                    raise RuntimeError(f"Invalid run on {deck}")
                print(*deck, word, file=out)


def validate(decks, source):
    with gzip.open(source, "rt") as file:
        for deck in decks:
            *cards, word = file.readline().split()
            if tuple(map(int, cards)) != deck or not replay(deck, word):
                raise ValueError("Missing, misordered or invalid certificate")
        if file.readline():
            raise ValueError("Extra certificate rows")
    print(f"Replayed all {len(decks)} distinct residual decks.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["solve", "replay"])
    parser.add_argument("residuals", type=Path)
    parser.add_argument("words", type=Path)
    args = parser.parse_args()
    decks = read_decks(args.residuals)
    if args.mode == "solve":
        solve(decks, args.words)
    validate(decks, args.words)
