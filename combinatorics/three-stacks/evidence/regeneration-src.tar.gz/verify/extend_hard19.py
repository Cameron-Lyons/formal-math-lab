"""Search all one-card insertions into the individual 19-card endgame inputs."""
import argparse
import gzip
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time

def dual(p):
    q = bytearray(len(p))
    for i,v in enumerate(p):
        q[len(p)-v]=len(p)-i
    return bytes(q)

def normalized(p):
    q=bytearray(p);i=q.index(1);q[i],q[-1]=q[-1],q[i]
    return min(bytes(q),dual(q))

def insertions(p):
    n=len(p)+1
    for card in range(1,n+1):
        base=bytes(v+(v>=card) for v in p)
        for i in range(n):
            yield base[:i]+bytes([card])+base[i:]

def generate(parents, raw_seen, covered):
    candidates=set()
    for parent in parents:
        for source in {parent,dual(parent)}:
            for deck in insertions(source):
                if deck in raw_seen:
                    continue
                raw_seen.add(deck)
                p=normalized(deck)
                if p not in covered:
                    candidates.add(p)
    return sorted(candidates)

def line(p):
    return ' '.join(map(str,p))+'\n'

def check(pile, parents, args, batch):
    with tempfile.TemporaryDirectory(dir=args.output) as temp:
        tmp=Path(temp)
        (tmp/'parents.txt').write_text(''.join(map(line,parents)))
        from insertion_lifts import cover
        want=set(parents);base_words={}
        for saved in args.closures.glob('*/words.txt.gz'):
            with gzip.open(saved,'rt') as entries:
                for row in entries:
                    *cards,word=row.split();p=bytes(map(int,cards))
                    if p in want:base_words[p]=word
        if set(base_words)!=want:raise ValueError('Missing verified parent word')
        lifted=cover(parents,base_words,pile)
        with gzip.open(tmp/'insertion-words.txt.gz','wt') as out:
            for p,word in sorted(lifted.items()):
                out.write(' '.join(map(str,p))+' '+word+'\n')
        current=tmp/'reps.txt'
        current.write_text(''.join('Hard 1 '+line(p) for p in pile if p not in lifted))
        count=len(pile)-len(lifted)
        stages=[]
        for program,arguments in [(args.probe,[args.tail]),(args.flex,['20','200','13','14','15','10','9','8','16','7'])]:
            following=tmp/(program.name+'.out')
            with current.open('rb') as src, following.open('wb') as dest:
                finished=subprocess.run([program,*arguments],stdin=src,stdout=dest,stderr=subprocess.PIPE,check=True)
            details=finished.stderr.decode().split()
            left=int(details[details.index('pending')+1])
            positive=(int(details[details.index('direct')+1])+int(details[details.index('dual')+1])
                      if 'direct' in details else int(details[details.index('sorted')+1]))
            if positive+left!=count:
                raise ValueError('Incomplete candidate filter')
            stages.append([positive,left]);count=left;current=following
        proofs=args.output/f'proofs-{batch}'
        words=tmp/'words.txt'
        completed=subprocess.run([sys.executable,Path(__file__).with_name('settle_candidates.py'),'20',current,words,proofs,args.drat],
                                 capture_output=True,text=True)
        if completed.returncode:
            (args.output/'candidate-report.txt').write_text(completed.stdout+completed.stderr)
            raise RuntimeError(completed.stdout+completed.stderr)
        from replay import replay
        finals={tuple(map(int,s.split()[2:])) for s in current.read_text().splitlines()}
        if len(finals)!=count:raise ValueError('Incorrect number of distinct final candidates')
        for s in words.read_text().splitlines():
            *cards,word=s.split();p=tuple(map(int,cards));finals.remove(p)
            if not replay(p,word):raise ValueError('Invalid final sorting word')
        if finals:raise ValueError('Missing final sorting words')
        with gzip.open(tmp/'words.txt.gz','wb') as out:out.write(words.read_bytes())
        (tmp/'report.json').write_text(json.dumps(dict(parents=len(parents),normalized=len(pile),lifted=len(lifted),stages=stages,words=count))+'\n')
        final=args.output/f'batch-{batch:04}'
        final.mkdir()
        for part in ('parents.txt','words.txt.gz','insertion-words.txt.gz','report.json'):
            (tmp/part).replace(final/part)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ('closures','output','probe','tail','flex','drat'):ap.add_argument(name,type=Path)
    ap.add_argument('--watch',action='store_true')
    args=ap.parse_args();args.output.mkdir(exist_ok=True,parents=True)
    done=set();raw_seen=set();covered=set();batch=0
    for old in sorted(args.output.glob('batch-*')):
        parents=[bytes(map(int,s.split())) for s in (old/'parents.txt').read_text().splitlines()]
        report=json.loads((old/'report.json').read_text())
        keys=generate(parents,raw_seen,covered)
        if len(keys)!=report['normalized'] or any(p in done for p in parents):raise ValueError('Invalid checkpoint')
        covered.update(keys);done.update(parents);batch+=1
    while True:
        newly=set();ranks=set()
        for report in args.closures.glob('*/closure.json'):
            j=json.loads(report.read_text())
            for r,c in j['ranks']:
                if r in ranks:raise ValueError('Overlapping closure ranks')
                ranks.add(r)
            if j['flex'][1]:
                for s in (report.parent/'individual.txt').read_text().splitlines():
                    p=bytes(map(int,s.split()[2:]))
                    if sorted(p)!=list(range(1,20)) or p[-1]!=1:raise ValueError('Invalid parent')
                    if p not in done:newly.add(p)
        if newly:
            parents=sorted(newly);pile=generate(parents,raw_seen,covered)
            check(pile,parents,args,batch)
            covered.update(pile);done.update(parents);batch+=1
            print(f'Parents {len(done)}, distinct actual insertions {len(raw_seen)}, normalized {len(covered)}, batches {batch}',flush=True)
        if not args.watch or len(ranks)==5040:break
        time.sleep(55)
    (args.output/'summary.json').write_text(json.dumps(dict(closed_ranks=len(ranks),parents=len(done),actual_insertions=len(raw_seen),normalized=len(covered),batches=batch))+'\n')

if __name__=='__main__':main()
