#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <vector>

namespace range_cluster {
// Sorting the suffix value sets changes only the traversal order. At every
// split both children are still included, and the caller intersects each
// child's actual layout masks before using any certificate.
template <unsigned Columns, class Mask> class Weights {
  static constexpr unsigned sample_count = 1024;
  using SampleBits = std::array<std::uint64_t, sample_count / 64>;
  std::array<SampleBits, Columns> containing{};

public:
  template <class GetSample> void train(GetSample mask) {
    containing = {};
    for (unsigned i = 0; i < sample_count; i++) {
      const auto &m = mask(i, sample_count);
      for (unsigned w = 0; w < m.size(); w++)
        for (auto bits = m[w]; bits; bits &= bits - 1) {
          unsigned j = 64 * w + std::countr_zero(bits);
          if (j < Columns)
            containing[j][i / 64] |= 1ull << (i % 64);
        }
    }
  }
  template <class Leaves>
  int partition(std::vector<int> &ids, const Leaves &data, int lo, int hi,
                unsigned depth) const {
    int count = hi - lo, middle = (lo + hi) / 2;
    if (count < 64 || depth > 8)
      return middle;
    Mask common = data[ids[lo]].mask;
    std::array<unsigned, Columns> frequency{};
    for (int i = lo; i < hi; i++) {
      const auto &mask = data[ids[i]].mask;
      for (unsigned w = 0; w < mask.size(); w++) {
        common[w] &= mask[w];
        for (auto b = mask[w]; b; b &= b - 1) {
          unsigned j = 64 * w + std::countr_zero(b);
          if (j < Columns)
            ++frequency[j];
        }
      }
    }
    SampleBits waiting;
    waiting.fill(~0ull);
    for (unsigned w = 0; w < common.size(); w++)
      for (auto b = common[w]; b; b &= b - 1) {
        unsigned j = 64 * w + std::countr_zero(b);
        if (j < Columns)
          for (unsigned k = 0; k < waiting.size(); k++)
            waiting[k] &= ~containing[j][k];
      }
    unsigned best = 0;
    std::uint64_t best_score = 0;
    for (unsigned j = 0; j < Columns; j++) {
      unsigned positive = frequency[j],
               small = std::min(positive, unsigned(count) - positive);
      if (small < 2)
        continue;
      unsigned support = 0;
      for (unsigned k = 0; k < waiting.size(); k++)
        support += std::popcount(waiting[k] & containing[j][k]);
      std::uint64_t score = std::uint64_t(positive) * support *
                            std::min(unsigned(count), 4 * small);
      if (score > best_score) {
        best_score = score;
        best = j;
      }
    }
    if (!best_score)
      return middle;
    auto split =
        std::stable_partition(ids.begin() + lo, ids.begin() + hi, [&](int id) {
          return (data[id].mask[best / 64] >> (best % 64)) & 1ull;
        });
    return split - ids.begin();
  }
};
} // namespace range_cluster
