// Independently read the regrouped length-18 join output. Check every input
// for uniqueness, rank membership, and consistency with the proof reductions.
#include <algorithm>
#include <array>
#include <bit>
#include <charconv>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unordered_set>

int main(int argc, char **argv) {
  if (argc != 6)
    throw std::runtime_error(
        "check_residual_stream FILE FIRST END STRIDE standard|canonical");
  int first = std::stoi(argv[2]), end = std::stoi(argv[3]),
      stride = std::stoi(argv[4]);
  std::string mode = argv[5];
  bool canonical = mode == "canonical";
  if (first < 0 || first >= end || end > 5040 || stride <= 0 ||
      (!canonical && mode != "standard"))
    throw std::runtime_error("Invalid shard");
  std::ifstream input(argv[1]);
  if (!input)
    throw std::runtime_error("Cannot open stream");
  std::string line;
  std::uint64_t last_block = 0;
  std::array<unsigned, 5040> totals{};
  std::unordered_set<std::uint64_t> heads;
  while (std::getline(input, line)) {
    if (!line.starts_with("Hard 1 "))
      throw std::runtime_error("Bad record type");
    const char *p = line.data() + 7;
    const char *stop = line.data() + line.size();
    std::array<unsigned char, 18> cards, dual;
    unsigned seen = 0, order = 0, set = 0;
    std::uint64_t head = 0;
    for (unsigned i = 0; i < cards.size(); ++i) {
      unsigned v;
      auto parsed = std::from_chars(p, stop, v);
      if (parsed.ec != std::errc{} || v < 1 || v > 18)
        throw std::runtime_error("Invalid card");
      p = parsed.ptr;
      if (i + 1 < cards.size() && (p == stop || *p++ != ' '))
        throw std::runtime_error("Bad separator");
      v--;
      unsigned bit = 1u << v;
      if (seen & bit)
        throw std::runtime_error("Repeated card");
      seen |= bit;
      if (i && cards[i - 1] == v + 1)
        throw std::runtime_error("Contractible residual");
      cards[i] = v;
      dual[17 - v] = 17 - i;
      if (i < 10)
        head = head * 18 + v;
      else if (i < 17) {
        order = order * (i - 9) + std::popcount(set >> v);
        set |= bit;
      }
    }
    if (p != stop || cards.back() != 0 || int(order) < first ||
        int(order) >= end || (int(order) - first) % stride)
      throw std::runtime_error("Residual outside its suffix shard");
    if (canonical && cards > dual)
      throw std::runtime_error("Noncanonical residual");
    std::uint64_t block = (std::uint64_t(order) << 18) | set;
    if (block < last_block)
      throw std::runtime_error("Residual suffixes are not grouped");
    if (block != last_block) {
      heads.clear();
      last_block = block;
    }
    if (!heads.insert(head).second)
      throw std::runtime_error("Duplicate residual");
    ++totals[order];
  }
  if (!input.eof())
    throw std::runtime_error("Residual stream read failed");
  for (int rank = first; rank < end; rank += stride)
    std::cout << rank << ' ' << totals[rank] << '\n';
}
