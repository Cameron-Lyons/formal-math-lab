#include "head_family.hpp"
#include "prefix.hpp"
#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <iostream>
#include <random>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

namespace {
constexpr unsigned k = prefix::size;
using Family = head_family::Index<k>;
using Mask = prefix::Mask;
class Mapping {
  void *data = MAP_FAILED;
  std::size_t size = 0;

public:
  Mapping(int fd, std::size_t length, bool write) : size(length) {
    data = mmap(nullptr, length, write ? PROT_READ | PROT_WRITE : PROT_READ,
                MAP_SHARED, fd, 0);
    if (data == MAP_FAILED)
      throw std::runtime_error("Cannot map family data");
  }
  Mapping(const Mapping &) = delete;
  ~Mapping() {
    if (data != MAP_FAILED)
      munmap(data, size);
  }
  Mask *rows() { return static_cast<Mask *>(data); }
};
void intersect(Mask &a, const Mask &b) {
  for (unsigned w = 0; w < a.size(); ++w)
    a[w] &= b[w];
}
void build(const char *source, const char *output, unsigned depth) {
  if (depth > k)
    throw std::runtime_error("Invalid depth");
  int in = open(source, O_RDONLY);
  struct stat info{};
  auto input_bytes = std::size_t(prefix::count) * sizeof(Mask);
  if (in < 0 || fstat(in, &info) != 0 ||
      std::size_t(info.st_size) != input_bytes) {
    if (in >= 0)
      close(in);
    throw std::runtime_error("Incorrect prefix input length");
  }
  Mapping inputs(in, input_bytes, false);
  close(in);
  std::string temp = std::string(output) + ".tmp.XXXXXX";
  int out = mkstemp(temp.data());
  if (out < 0)
    throw std::runtime_error("Cannot create output");
  try {
    auto output_size = Family::offset(depth + 1) * sizeof(Mask);
    if (ftruncate(out, output_size))
      throw std::runtime_error("Cannot size output");
    Mapping result(out, output_size, true);
    const auto *raw = inputs.rows();
    auto *rows = result.rows();
    auto *leaf = rows + Family::offset(depth);
    std::vector<std::uint32_t> hits(Family::count(depth));
    std::array<int, k> word;
    std::iota(word.begin(), word.end(), 0);
    unsigned h = 0;
    do {
      std::array<unsigned char, k> inverse;
      for (unsigned i = 0; i < k; i++)
        inverse[word[i]] = i;
      unsigned group = Family::local(inverse.data(), depth);
      if (hits[group]++)
        intersect(leaf[group], raw[h]);
      else
        leaf[group] = raw[h];
      ++h;
    } while (std::next_permutation(word.begin(), word.end()));
    if (h != prefix::count)
      throw std::logic_error("Incorrect head count");
    unsigned expected = prefix::count / Family::count(depth);
    for (unsigned count : hits)
      if (count != expected)
        throw std::logic_error("Incorrect leaf size");
    for (unsigned b = depth; b; b--) {
      unsigned fan = k - b + 1;
      auto *child = rows + Family::offset(b);
      auto *parent = rows + Family::offset(b - 1);
      for (unsigned i = 0; i < Family::count(b - 1); ++i) {
        auto &mask = parent[i];
        mask = child[i * fan];
        for (unsigned digit = 1; digit < fan; ++digit)
          intersect(mask, child[i * fan + digit]);
      }
    }
    for (unsigned b = 0; b <= depth; b++) {
      unsigned members = prefix::count / Family::count(b);
      if (std::uint64_t(Family::count(b)) * members != h)
        throw std::logic_error("Incorrect derived family sizes");
      std::cerr << "b " << b << " offset " << Family::offset(b) << " families "
                << Family::count(b) << " members " << members << '\n';
    }
    if (fsync(out) || rename(temp.c_str(), output))
      throw std::runtime_error("Cannot publish family output");
    close(out);
  } catch (...) {
    close(out);
    unlink(temp.c_str());
    throw;
  }
}
} // namespace
int main(int argc, char **argv) {
  try {
    if (argc != 4)
      throw std::runtime_error("build_head_family PREFIX OUTPUT MAX_B");
    build(argv[1], argv[2], std::stoul(argv[3]));
  } catch (const std::exception &e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
