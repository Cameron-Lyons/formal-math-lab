"""Reconcile every recorded bucket of the 20-card targeted searches."""

import gzip
import re
from pathlib import Path
from math import factorial

from corner_counts import count, count_patterns, patterns, union
from replay import replay

folder = Path(__file__).with_name("published")


def rows(filename, expression):
    text = (folder / filename).read_text()
    return [tuple(map(int, parts)) for parts in re.findall(expression, text, re.M)]


def equal(actual, expected):
    if actual != expected:
        raise ValueError(f"Expected {expected}, found {actual}")


def certificates(name, n, expected):
    source = folder / name
    read = gzip.open if source.suffix == ".gz" else open
    seen = set()
    with read(source, "rt") as lines:
        for line in lines:
            *values, seq = line.split()
            p = tuple(map(int, values))
            if p in seen or sorted(p) != list(range(1, n + 1)) or len(seq) != 4 * n or not replay(p, seq):
                raise ValueError(f"Duplicate or invalid {n}-card schedule in {source}")
            seen.add(p)
    equal(len(seen), expected)


def reconcile(name, expected, fixed=False):
    log = name + "-summary.txt"
    deferred = rows(log, r"^Deferred (\d+) sorted (\d+) pending (\d+)")
    if fixed:
        front = rows(log, r"^heads \d+ permutations (\d+) direct layout (\d+) disjoint (\d+) descending bond (\d+) deferred (\d+)")
        first, second = front
        equal(first, second)
        total, direct, disjoint, bonded, pending = first
        equal(direct + disjoint, expected)
        equal(bonded + pending, disjoint)
        dual_total, dual_good, left = deferred.pop(0)
        equal(dual_total, pending)
    else:
        (entry,) = rows(log, r"^decks (\d+) direct (\d+) descending bond (\d+) mirror (\d+) deferred (\d+)")
        total, direct, bonded, mirror, pending = entry
        equal(direct + bonded + mirror + pending, expected)
        ((dual_good, left),) = rows(log, r"^dual (\d+) pending (\d+)")
    equal(total, expected)
    equal(dual_good + left, pending)
    for sorted_words, pending in rows(log, r"^Fully replayed (\d+) pending (\d+)"):
        equal(sorted_words + pending, left)
        left = pending
    (flex_good, remaining), (contract_good, contract_remaining) = rows(log, r"^sorted (\d+) pending (\d+)")
    equal(flex_good + remaining, left)
    sat_rows = rows(log, r"^Read (\d+) rows, wrote (\d+) new replayed schedules, (\d+) distinct")
    equal(sat_rows[0], (remaining,) * 3)
    certificates(name + "-final-words.gz", 20, remaining)

    first, second = deferred
    n, covered, open_first = first
    equal(n, bonded)
    equal(covered + open_first, n)
    n, covered, open_second = second
    equal(n, open_first)
    equal(covered + open_second, n)
    ((unique, occurrences),) = rows(log, r"^Distinct contractions (\d+) occurrences (\d+)\.$")
    equal(occurrences, open_second)
    equal(unique, contract_good + contract_remaining)
    if unique > occurrences:
        raise ValueError("Too many distinct contractions")
    if fixed:
        certificates("contract19-final.word", 19, contract_remaining)
    else:
        equal(sat_rows[1], (contract_remaining,) * 3)
        if contract_remaining:
            certificates(name + "-contract19-words.gz", 19, contract_remaining)
    print(f"{name}: {total:,} decks, {bonded:,} actually contracted and resolved, {remaining} final schedules replayed.")


def lex_rank(p):
    return sum(sum(x < v for x in p[i+1:]) * factorial(len(p)-i-1) for i, v in enumerate(p))


def main():
    seed_ranks = sorted(map(lex_rank, patterns(12)))
    archived = list(map(int, (folder / "n20-head-ranks.txt").read_text().split()))
    equal(archived, seed_ranks)
    direct = {}
    for line in (folder / "corner-cardinalities.txt").read_text().splitlines():
        k, ell, value = line.split()
        k, value = int(k), int(value)
        if ell == "*":
            equal(value, len(patterns(k)) * factorial(19) // factorial(k))
        else:
            ell = int(ell)
            equal(value, count(k, ell)[2])
        direct[k, ell] = value
    for (k, ell), value in direct.items():
        if ell != "*":
            equal(direct[ell, k], value)
    # Reading the recorded physical audit of every compressed generator record
    # checks completeness against the external counter, not just an equality
    # between potential counts derived using the generator's counting formula.
    geometry = rows("corner-geometry.txt", r"^Physical membership, disjoint records: (\d+) (\d+) (\d+) records (\d+) permutations\.")
    expected_geometries = [(9, 8), (9, 9), (12, 12)]
    if (folder / "corners8-summary.txt").exists():
        expected_geometries.append((8, 8))
    equal(sorted((k, ell) for k, ell, _, _ in geometry), sorted(expected_geometries))
    for k, ell, skeletons, total in geometry:
        equal(total, direct[k, ell])
        if not skeletons:
            raise ValueError("Missing geometry")
    reconcile("fixed12", direct[12, "*"], fixed=True)
    reconcile("corners9", direct[9, 9])
    nine_union = 2 * direct[12, "*"] + direct[9, 9] - 2 * direct[12, 9]
    print(f"Fixed-12 and 9/9, both orientations: {nine_union:,} distinct permutations.")
    if (folder / "corners9x8-summary.txt").exists():
        reconcile("corners9x8", direct[9, 8])
        enlarged = 2 * direct[12, "*"] + 2 * direct[9, 8] - direct[9, 9] - 2 * direct[12, 8]
        print(f"Including 9/8 in both orientations: {enlarged:,}, adding {enlarged-nine_union:,} distinct permutations.")
    full_pv = 2 * direct[12, "*"] + direct[8, 8] - 2 * direct[12, 8]
    if (folder / "corners8-summary.txt").exists():
        reconcile("corners8", direct[8, 8])
        print(f"Including 8/8: {full_pv:,} normalized decks, certifying {20*full_pv:,} arbitrary permutations.")
    if (folder / "shaikh10-summary.txt").exists():
        shaikh = tuple(map(int, (folder / "shaikh22.txt").read_text().split()))
        alt = patterns(10, seed=shaikh)
        archived = list(map(int, (folder / "shaikh22-ten-heads.txt").read_text().split()))
        equal(archived, sorted(map(lex_rank, alt)))
        def restrict(full, small):
            length = len(next(iter(small)))
            return {word for word in full if tuple(sorted(word[:length]).index(v) for v in word[:length]) in small}
        small = restrict(alt, patterns(8))
        large = restrict(patterns(12), alt)
        counts = [count_patterns(k, ell, a, b)[2] for k, ell, a, b in
                  ((10, 10, alt, alt), (10, 10, small, small), (12, 10, large, alt), (12, 10, large, small))]
        recorded = [int(row.split()[1]) for row in (folder / "shaikh22-cardinalities.txt").read_text().splitlines()]
        equal(counts, recorded)
        total, both8, fixed12, fixed12_and_both8 = counts
        ((k, ell, records_count, geometry_total),) = rows("shaikh10-summary.txt", r"^Physical membership, disjoint records: (\d+) (\d+) (\d+) records (\d+) permutations\.")
        equal((k, ell, geometry_total), (10, 10, total))
        if records_count <= 0:
            raise ValueError("Missing alternate geometry")
        reconcile("shaikh10", total)
        if not (folder / "corners8-summary.txt").exists():
            raise ValueError("Combined result requires the original eight-card family archive")
        overlap = both8 + 2 * (fixed12 - fixed12_and_both8)
        combined = full_pv + total - overlap
        print(f"With the alternate 10/10 family: {combined:,} distinct normalized decks, certifying {20*combined:,} arbitrary permutations.")
        if (folder / "shaikh10x9-summary.txt").exists():
            nine = patterns(9, seed=shaikh)
            archived = list(map(int, (folder / "shaikh22-nine-heads.txt").read_text().split()))
            equal(archived, sorted(map(lex_rank, nine)))
            aside = [(alt, nine), (nine, alt)]
            original = [(patterns(8), patterns(8)), (patterns(12), {()}), ({()}, patterns(12))]
            direct_total = count_patterns(10, 9, alt, nine)[2]
            counts = [direct_total, union(aside), union(aside + original)]
            recorded = [int(row.split()[1]) for row in (folder / "shaikh22-nine-cardinalities.txt").read_text().splitlines()]
            equal(counts, recorded)
            ((k, ell, records_count, geometry_total),) = rows("shaikh10x9-summary.txt", r"^Physical membership, disjoint records: (\d+) (\d+) (\d+) records (\d+) permutations\.")
            equal((k, ell, geometry_total), (10, 9, direct_total))
            if records_count <= 0:
                raise ValueError("Missing asymmetric alternate geometry")
            reconcile("shaikh10x9", direct_total)
            print(f"Including alternate 10/9 in both orientations: {counts[2]:,} normalized decks, certifying {20*counts[2]:,} arbitrary permutations.")


if __name__ == "__main__":
    main()
