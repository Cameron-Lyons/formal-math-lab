"""Select and replay one-card extensions of sampled flexible-cut parents."""
import argparse
import gzip
import mmap
import sys
from functools import lru_cache
from hashlib import blake2b
from math import factorial
from pathlib import Path

from corner_counts import patterns
from extend_hard19 import dual as bytes_dual, insertions, normalized
from replay import replay
from terminal_extensions import candidates, dual, extend, normalize

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "families"))
from margin_counts import sortable2

folder = Path(__file__).with_name("published")


def tie(deck):
    return blake2b(bytes(deck), key=b"three-stacks-flex-20261126", digest_size=8).digest()


def rank(word):
    seen = 0
    result = 0
    for position, value in enumerate(word):
        used_smaller = (seen & ((1 << value) - 1)).bit_count()
        result = result * (len(word) - position) + value - used_smaller
        seen |= 1 << value
    return result


@lru_cache(maxsize=None)
def difficult(pattern):
    return not sortable2(pattern)


def failed_boundaries(deck):
    first = difficult(tuple(6 - v for v in normalize(deck, 7)))
    last = difficult(normalize(deck[-7:], 7))
    return first, last


def generate(parents, snapshot, prefix, dest):
    alt = tuple(map(int, (folder / "shaikh22.txt").read_text().split()))
    pv8, pv12 = patterns(8), patterns(12)
    alt9, alt10 = patterns(9, seed=alt), patterns(10, seed=alt)
    blocked = set()
    # Include images produced by inserting a new global minimum before
    # exchanging the minimum with the last card.
    for parent in snapshot:
        original = bytes(parent)
        for orientation in {original, bytes_dual(original)}:
            blocked.update(normalized(child) for child in insertions(orientation))
    blocked.update(map(bytes, candidates(folder)))
    eligible = set()
    picked = set()
    with prefix.open("rb") as source, mmap.mmap(source.fileno(), 0, access=mmap.ACCESS_READ) as table:
        stride = 40
        if len(table) != stride * factorial(10):
            raise ValueError("Unexpected ten-card prefix table")

        @lru_cache(maxsize=100000)
        def layouts(head):
            start = stride * rank(head)
            return int.from_bytes(table[start:start + stride], "little").bit_count()

        for parent in parents:
            local = []
            for child in extend(parent):
                if any(abs(a - b) == 1 for a, b in zip(child, child[1:])):
                    continue
                reflected = dual(child)
                if reflected == child:
                    continue
                child, reflected = sorted((child, reflected))
                if bytes(child) in blocked:
                    continue
                front, opposite = normalize(child, 10), normalize(reflected, 10)
                if (normalize(child, 12) in pv12 or normalize(reflected, 12) in pv12
                    or (normalize(child, 8) in pv8 and normalize(reflected, 8) in pv8)
                    or (front in alt10 and normalize(reflected, 9) in alt9)
                    or (opposite in alt10 and normalize(child, 9) in alt9)):
                    continue
                a, b = failed_boundaries(child), failed_boundaries(reflected)
                if all(a + b):
                    continue
                x, y = layouts(front), layouts(opposite)
                score = (-min(sum(a), sum(b)), -sum(a + b), (x + 1) * (y + 1), max(x, y), tie(child))
                eligible.add(child)
                local.append((score, child))
            picked.update(child for _, child in sorted(set(local))[:48])
    with dest.open("w") as out:
        for deck in sorted(picked, key=tie):
            print("Hard 1", *deck, file=out)
    print(f"{len(parents)} flex-solved parents; {len(snapshot)} excluded SAT parents; "
          f"{len(eligible)} distinct eligible canonical insertions; {len(picked)} selected.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--parents", type=Path, default=folder / "flex-lift-parents.txt")
    parser.add_argument("--exclude", type=Path, default=folder / "flex-lift-sat-snapshot.gz")
    args = parser.parse_args()
    parents = [tuple(map(int, line.split())) for line in args.parents.read_text().splitlines()]
    with gzip.open(args.exclude, "rt") as stream:
        excluded = [tuple(map(int, line.split())) for line in stream]
    if set(parents) & set(excluded):
        raise ValueError("Source parents overlap SAT parents")
    if args.output:
        if not args.prefix:
            parser.error("--output requires --prefix")
        generate(parents, excluded, args.prefix, args.output)
        return
    pending = set()
    with gzip.open(folder / "flex-lift-candidates.gz", "rt") as stream:
        for line in stream:
            tag, flag, *raw = line.split()
            deck = tuple(map(int, raw))
            if (tag != "Hard" or flag != "1" or sorted(deck) != list(range(1, 21))
                or deck[-1] != 1 or deck >= dual(deck) or deck in pending):
                raise ValueError("Invalid candidate archive")
            pending.add(deck)
    count = len(pending)
    reversals = str.maketrans("1234", "4321")
    with gzip.open(folder / "flex-lift-words.gz", "rt") as stream:
        for line in stream:
            *raw, word = line.split()
            deck = tuple(map(int, raw))
            if deck not in pending or len(word) != 80 or not replay(deck, word):
                raise ValueError("Invalid sorting word")
            if not replay(dual(deck), word[::-1].translate(reversals)):
                raise ValueError("Invalid reflected sorting word")
            pending.remove(deck)
    if pending:
        raise ValueError("Missing sorting words")
    print(f"Replayed {count:,} sorting words in both orientations for {2 * count:,} normalized decks.")


if __name__ == "__main__":
    main()
