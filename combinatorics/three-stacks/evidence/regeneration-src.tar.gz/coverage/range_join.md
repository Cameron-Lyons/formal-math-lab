# Exhaustive range join for 19-card decks

The scanner covers every permutation ending in 1. A fixed relative order of the seven positive suffix cards gives $11!\binom{18}{7}=1{,}270{,}312{,}243{,}200$ prefix/value-set pairs. There are $7!=5{,}040$ suffix orders. Their product is $18!$. Eliminating descending adjacent consecutive cards relies on the result for 18-card decks. Eliminating the larger member of a reflection pair relies on covering all suffix orders.

For each suffix order, enumerate its possible value sets in increasing integer bitmask order. For expensive suffix orders the scanner groups these sets by the presence of particular continuation layouts. A sample of prefix permutations guides the choice of splitting layout. Both groups continue through the exact intersection and cardinality checks. A leaf stores the mask of reachable continuations at cut 11, the bits for descending consecutive pairs, and a table of lexicographic comparisons between the first card and its image under reflection in the anti-diagonal. It also stores, for each rank of the eleventh card, 64 continuation bits for the earlier cut at 10. Taking the bitwise intersection over all descendants gives an internal node. A prefix hit at that node is a certificate for every leaf below it. A prefix which misses every certificate descends into every child.

For the upper cut, a positive layout bit means that the initial prefix can load both parked stacks as specified and leave all other cards in decreasing order in the third stack. The continuation bit for this layout certifies sorting from the resulting configuration. For the earlier cut, the eleventh card is prepended to the suffix. Its rank among the seven other positive suffix cards determines the new suffix order. Its value together with the other suffix values determines the new suffix value set. The 64-bit projection uses the same list of layouts for the prefix and continuation sides. Changing that list changes the work needed to finish residuals. Empty direct or bounded-search results always fall through to another test.

The sorting dual in zero-based notation is $D(p)_{n-1-p_i}=n-1-i$. The leaf's first-coordinate comparison can discard $p_0>D(p)_0$. If the coordinates tie, the program checks the full lexicographic comparison. A retained permutation can also sort through a layout hit for its dual. Remaining inputs pass through the full earlier-cut masks and the optional cuts at 9 and 8. For these last two cuts, the scanner batches remaining decks by the relative orders of their shorter tails so that successful continuation checks can be reused. Every bounded positive is a legal sorting schedule or a restriction of one after deleting inert cards.

The scanner checks its accounting identity on every suffix order. At an internal node a successful prefix accounts for the number of leaves below that node. Leaf processing accounts for every surviving prefix. Descending pairs inside the fixed suffix are accounted before constructing the tree. The resulting integer total must equal the full prefix count times the full value-set count, including noncanonical mirror representatives.

Build and run one shard with the already generated tables.

```sh
c++ -O3 -std=c++20 -march=native coverage/range_join.cpp -o /tmp/range19
/tmp/range19 PREFIX11 PACKED_TAIL19 INDEX11 FIRST END STRIDE PREFIX10 200 1000 PREFIX9 PREFIX8 > hard.txt 2> counts.log
```

The half-open suffix-order interval and stride support independent congruence-class shards. The final optional integer bounds how many compact root survivors are held at once. The default is 262,144. A single minus sign omits the indicated optional nested prefix table. The `pending` count is the exact number of rows emitted for that suffix order. Those rows still require individual verification. Since the gap cache can infer successful checks by deletion, the chosen traversal order can change which bounded-search cases remain pending.

For a small independent check, the optimized join was also compiled for nine cards at a cut of five. On synthetic prefix and continuation masks, brute force over all 40,320 final-1 permutations left exactly the same 1,652 canonical residuals. This checks the address and symmetry arithmetic independently of the physical layout generator.

The length-19 ordered run scans the easier suffix orders in full and assigns the remaining dual orbits by a fixed priority. Its audit and reproduction commands are recorded separately. [Ordered-run audit and reproduction](ordered19.md)
