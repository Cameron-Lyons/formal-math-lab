// Independently count length-20 source/dual prefix restrictions by fixing the
// actual values in the source prefix and reading their physical positions.
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <set>
#include <unordered_map>
#include <vector>

using Pattern = std::vector<int>;
using Patterns = std::set<Pattern>;
using Count = std::uint64_t;
constexpr int length = 20;
constexpr int known[] = {6, 3, 12, 8, 17, 5, 2, 11, 7, 19, 14, 10, 4, 18, 13, 21, 16, 9, 20, 15, 1};

Pattern relative(Pattern values) {
  auto order = values;
  std::sort(order.begin(), order.end());
  for (int &value : values)
    value = std::lower_bound(order.begin(), order.end(), value) - order.begin();
  return values;
}

Patterns seeds(int k, const Pattern &seed) {
  Patterns result;
  // Choose the 20 retained positions directly. Each deletion is then
  // standardized using a physical sort, including when two values are lost.
  std::vector<int> retained(seed.size());
  std::fill(retained.end() - length, retained.end(), 1);
  do {
    Pattern selected;
    for (unsigned i = 0; i < seed.size(); ++i)
      if (retained[i]) selected.push_back(seed[i]);
    auto deck = relative(selected);
    std::iter_swap(std::min_element(deck.begin(), deck.end()), deck.end() - 1);
    Pattern backwards;
    for (int card = length - 1; card >= 0; --card)
      backwards.push_back(length - 1 - (std::find(deck.begin(), deck.end(), card) - deck.begin()));
    for (const Pattern &orientation : {deck, backwards})
      result.insert(relative(Pattern(orientation.begin(), orientation.begin() + k)));
  } while (std::next_permutation(retained.begin(), retained.end()));
  return result;
}

Count factorial(int n) {
  Count value = 1;
  for (int i = 2; i <= n; ++i) value *= i;
  return value;
}

Count count(int k, int ell, const Patterns &heads, const Patterns &opposite) {
  // In the dual head, negative-space ranks 0..d-1 arise precisely from high
  // cards missing from the physical head. A four-bit wildcard marks each.
  std::vector<std::unordered_map<Count, unsigned>> permitted(ell + 1);
  for (const auto &pattern : opposite)
    for (int d = 0; d <= ell; ++d) {
      Count key = 0;
      for (int v : pattern) key = (key << 4) + (v < d ? 15 : v);
      ++permitted[d][key];
    }
  Count total = 0;
  for (unsigned set = 0; set < (1u << (length - 1)); ++set) {
    if (std::popcount(set) != k) continue;
    // Bits encode the positive labels 2..20. The minimum, 1, is always last.
    std::array<int, length + 1> rank{};
    rank.fill(-1);
    int ordinal = 0;
    for (int card = 2; card <= length; ++card)
      if (set & (1u << (card - 2))) rank[card] = ordinal++;
    for (const auto &head : heads) {
      std::array<int, length> position{};
      for (int i = 0; i < k; ++i) position[head[i]] = i;
      unsigned high_positions = 0;
      std::array<int, length> high{};
      for (int j = 0; j < ell; ++j) {
        int r = rank[length - j];
        high[j] = r < 0 ? -1 : position[r];
        if (high[j] >= 0) high_positions |= 1u << high[j];
      }
      int missing = ell - std::popcount(high_positions);
      Count key = 0;
      for (int j = 0; j < ell; ++j) {
        int p = high[j];
        int dual_rank = p < 0 ? 15 : missing + std::popcount(high_positions >> (p + 1));
        key = (key << 4) + dual_rank;
      }
      auto match = permitted[missing].find(key);
      if (match != permitted[missing].end())
        // Each possible order of the missing high cards occurs equally often
        // among all (19-k)! suffix completions of this fixed physical head.
        total += match->second * (factorial(length - 1 - k) / factorial(missing));
    }
  }
  return total;
}

Patterns restrict_head(const Patterns &words, const Patterns &shorter) {
  Patterns selected;
  if (shorter.empty()) return selected;
  auto n = shorter.begin()->size();
  for (const auto &p : words)
    if (shorter.contains(relative(Pattern(p.begin(), p.begin() + n))))
      selected.insert(p);
  return selected;
}

using Corner = std::pair<Patterns, Patterns>;

Patterns intersect(const Patterns &a, const Patterns &b) {
  if (a.empty() || b.empty()) return {};
  return a.begin()->size() >= b.begin()->size() ? restrict_head(a,b) : restrict_head(b,a);
}

Count union_volume(const std::vector<Corner> &families) {
  std::int64_t result = 0;
  for (unsigned subset = 1; subset < (1u << families.size()); ++subset) {
    Patterns front{Pattern{}}, back{Pattern{}};
    for (unsigned i = 0; i < families.size(); ++i)
      if (subset & (1u << i)) {
        front = intersect(front, families[i].first);
        back = intersect(back, families[i].second);
      }
    if (front.empty() || back.empty()) continue;
    auto contribution = count(front.begin()->size(), back.begin()->size(), front, back);
    result += std::popcount(subset) % 2 ? std::int64_t(contribution) : -std::int64_t(contribution);
  }
  return result;
}

int main(int argc, char **argv) {
  const Pattern published(std::begin(known), std::end(known));
  if (argc == 2 || (argc == 3 && std::string(argv[2]) == "--nine-dual")) {
    std::ifstream in(argv[1]);
    Pattern seed;
    int value;
    while (in >> value) seed.push_back(value);
    if (!in.eof() || seed.size() != 22) throw std::invalid_argument("Expected a 22-card seed");
    auto sorted = seed;
    std::sort(sorted.begin(), sorted.end());
    for (unsigned i = 0; i < sorted.size(); ++i)
      if (sorted[i] != int(i + 1)) throw std::invalid_argument("Invalid seed permutation");
    auto alt = seeds(10, seed);
    if (argc == 3) {
      const auto nine = seeds(9, seed), pv8 = seeds(8, published), pv12 = seeds(12, published);
      const Patterns any{Pattern{}};
      auto shapes = std::vector<Corner>{{alt,nine},{nine,alt}};
      auto own = count(10,9,alt,nine), reverse = count(9,10,nine,alt);
      if (own != reverse) throw std::logic_error("Transposed counts differ");
      std::cout << "Shaikh-10/9 " << own << '\n';
      std::cout << "Shaikh-10/9-dual-closure " << union_volume(shapes) << '\n';
      shapes.insert(shapes.end(), {{pv8,pv8},{pv12,any},{any,pv12}});
      std::cout << "Shaikh-10/9-and-PV-dual-closure " << union_volume(shapes) << '\n';
      return 0;
    }
    auto short_compatible = restrict_head(alt, seeds(8, published));
    auto long_compatible = restrict_head(seeds(12, published), alt);
    std::cout << "Shaikh-10/10 " << count(10, 10, alt, alt) << '\n'
              << "intersection-PV8/8 " << count(10, 10, short_compatible, short_compatible) << '\n'
              << "intersection-PV12 " << count(12, 10, long_compatible, alt) << '\n'
              << "intersection-PV12-and-PV8/8 " << count(12, 10, long_compatible, short_compatible) << '\n';
    return 0;
  }
  if (argc != 1) throw std::invalid_argument("usage: corner-counts [ALTERNATE_22_CARD_SEED [--nine-dual]]");
  for (int k : {8, 9, 12}) {
    auto front = seeds(k, published);
    std::cout << k << " * " << front.size() * (factorial(19) / factorial(k)) << '\n';
    for (int ell : {8, 9, 12})
      std::cout << k << ' ' << ell << ' ' << count(k, ell, front, seeds(ell, published)) << '\n';
  }
}
