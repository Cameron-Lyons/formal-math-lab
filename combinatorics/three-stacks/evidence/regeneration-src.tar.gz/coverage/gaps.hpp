#pragma once
#include "../knuth/layout.hpp"
#include "../structural/reach.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <stdexcept>
#include <vector>
#ifdef __BMI2__
#include <immintrin.h>
#endif

namespace gap {
struct Embedding {
  unsigned tail_and_zero;
  std::array<int, 24> value{}, below{};
  // suffix_mask contains the values of the positive unread cards. The final
  // zero is implicit. Prefix ranks run from 0 to cut-1 in ascending order.
  Embedding(int cut, int n, unsigned suffix_mask)
      : tail_and_zero(suffix_mask | 1U) {
    unsigned remaining = ((1U << n) - 1) & ~tail_and_zero;
    if (std::popcount(remaining) != cut)
      throw std::invalid_argument("Incorrect number of tail cards");
    for (int i = 0; remaining; ++i, remaining &= remaining - 1) {
      value[i] = std::countr_zero(remaining);
      below[i] = std::popcount(suffix_mask & ((1U << value[i]) - 1));
    }
  }
};

// For an active rank, the bit immediately above its actual card indicates
// whether an inert card separates it from the next greater active rank.
// An inert card above all active ranks can always be discarded.
inline unsigned marker_mask(unsigned active, int size) {
  unsigned before_gap = ~(active >> 1);
#ifdef __BMI2__
  unsigned mask = _pext_u32(before_gap, active);
#else
  unsigned mask = 0, bit = 1;
  while (active) {
    unsigned x = active & -active;
    if (before_gap & x)
      mask |= bit;
    active ^= x;
    bit <<= 1;
  }
#endif
  return mask & ((1U << (size - 1)) - 1);
}

class Table {
  struct Layout {
    int first_count, second_count, size;
    std::array<unsigned char, 2> first{}, second{};
    std::array<unsigned char, 12> input{};
  };
  struct Key {
    int column, size;
    unsigned active;
  };
  int ordinary, width, stride, budget;
  std::vector<std::uint8_t> entries;
  std::vector<Layout> layouts;
  std::array<int, 12> permutation{};
  int pair_column(int role, int a, int b) const {
    return 1 + 2 * (ordinary + 1) +
           ((role - 3) * (ordinary + 2) + a) * (ordinary + 2) + b;
  }
  void set_layout(int col, int role, int a, int b) {
    auto &x = layouts[col];
    int count = role == 0 ? 0 : role < 3 ? 1 : 2;
    x.size = ordinary + 1 + count;
    x.first_count = x.second_count = 0;
    if (role == 1 || role == 3 || role == 4)
      x.first[x.first_count++] = a + 1;
    if (role == 2 || role == 5)
      x.second[x.second_count++] = a + 1;
    if (role == 3)
      x.first[x.first_count++] = b + 1;
    if (role == 4 || role == 5)
      x.second[x.second_count++] = b + 1;
    std::array<int, 12> ordinary_rank{};
    for (int c = 1, i = 0; c < x.size; ++c)
      if (!(count >= 1 && c == a + 1) && !(count == 2 && c == b + 1))
        ordinary_rank[i++] = c;
    for (int i = 0; i < ordinary; ++i)
      x.input[i] = ordinary_rank[permutation[i]];
    x.input[ordinary] = 0;
  }
  Key layout_key(const Embedding &e, const layout::Shape &s) const {
    int fs = s.first.size(), count = s.members();
    Key k{0, ordinary + 1 + count, e.tail_and_zero};
    if (!count)
      return k;
    int a = fs ? s.first.front() : s.second.front();
    k.active |= 1U << e.value[a];
    if (count == 1) {
      k.column = 1 + (fs ? 0 : ordinary + 1) + e.below[a];
      return k;
    }
    int b = fs == 2 ? s.first.back() : s.second.back();
    k.active |= 1U << e.value[b];
    int role = fs == 2 ? 3 : fs == 1 ? 4 : 5;
    k.column = pair_column(role, e.below[a] + (b < a), e.below[b] + (a < b));
    return k;
  }
  bool search(const Layout &x, unsigned mask) const {
    std::array<int, 24> rank{}, deck{};
    unsigned third = 0;
    int n = 0;
    for (int i = 0; i < x.size; ++i) {
      rank[i] = n++;
      if (mask & (1U << i))
        third |= 1U << n++;
    }
    unsigned first = 0;
    int prefix = n - ordinary - 1;
    for (int i = 0; i < x.first_count; ++i) {
      deck[i] = rank[x.first[i]];
      first |= 1U << i;
    }
    for (int i = 0; i <= ordinary; ++i)
      deck[prefix + i] = rank[x.input[i]];
    const reach::Node empty{31, 31, 0, nullptr};
    std::array<reach::Node, 2> saved;
    const reach::Node *top = &empty;
    for (int i = 0; i < x.second_count; ++i) {
      int c = rank[x.second[i]];
      unsigned forbid = top->forbidden;
      if (c > top->smallest)
        forbid |= ((1U << c) - 1) & ~((2U << top->smallest) - 1);
      saved[i] = {c, std::min(c, top->smallest), forbid, top};
      top = &saved[i];
    }
    reach::Search r{deck.data(), n, budget, 0, false};
    return r.dfs(first, top, third, prefix, 0);
  }

public:
  Table(int cut, int n = 17, int node_budget = 4000)
      : ordinary(n - cut - 1), budget(node_budget) {
    if (ordinary < 0 || ordinary > 11)
      throw std::invalid_argument("Invalid tail length");
    width = 1 + 2 * (ordinary + 1) + 3 * (ordinary + 2) * (ordinary + 2);
    stride = 1 << (ordinary + 2);
    entries.resize(width * stride);
    layouts.resize(width);
  }
  // Set the relative order of the nonzero unread cards. Results are then
  // reused for *all* numeric embeddings of this order before the next reset.
  void reset(const int *ordered_tail) {
    for (int i = 0; i < ordinary; ++i)
      permutation[i] =
          std::count_if(ordered_tail, ordered_tail + ordinary,
                        [&](int c) { return c < ordered_tail[i]; });
    std::fill(entries.begin(), entries.end(), 0);
    set_layout(0, 0, -1, -1);
    for (int role : {1, 2})
      for (int a = 0; a <= ordinary; ++a)
        set_layout(1 + (role - 1) * (ordinary + 1) + a, role, a, -1);
    for (int role : {3, 4, 5})
      for (int a = 0; a < ordinary + 2; ++a)
        for (int b = 0; b < ordinary + 2; ++b)
          if (a != b)
            set_layout(pair_column(role, a, b), role, a, b);
  }
  // This key depends only on the embedding and occupancy, not the tail order.
  // It remains valid across resets. The high bits identify the direct-table
  // column and the low ordinary+2 bits encode occupied gaps.
  unsigned key(const Embedding &e, const layout::Shape &s) const {
    Key k = layout_key(e, s);
    return k.column * stride + marker_mask(k.active, k.size);
  }
  bool test(unsigned encoded) {
    auto &result = entries[encoded];
    if (!result) {
      unsigned mask = encoded & (stride - 1);
      if (search(layouts[encoded / stride], mask)) {
        // Deletion of any inert gap markers preserves the same sorting run.
        // Record those embeddings without launching another search.
        unsigned base = encoded - mask;
        for (unsigned sub = mask;; sub = (sub - 1) & mask) {
          entries[base + sub] = 2;
          if (sub == 0) break;
        }
      } else {
        result = 1;
      }
    }
    return result == 2;
  }
  bool test(const Embedding &e, const layout::Shape &s) {
    return test(key(e, s));
  }
};
} // namespace gap
