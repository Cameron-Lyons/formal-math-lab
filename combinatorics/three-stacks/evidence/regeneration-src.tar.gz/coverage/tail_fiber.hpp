// n19, k11: group continuation suffix rows by their actual small values and
// by the positions occupied by these values, in increasing small-value order.
// A numeric suffix set uses bit value-1 for positive card labels 1..18.
#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <numeric>
namespace tail_fiber {
constexpr unsigned m = 7, orders = 5040, subsets = 128;
constexpr unsigned permutations(unsigned choices, unsigned count) {
  unsigned p = 1;
  for (unsigned i = 0; i < count; i++)
    p *= choices - i;
  return p;
}
constexpr auto offsets() {
  std::array<unsigned, subsets + 1> base{};
  for (unsigned s = 0; s < subsets; s++)
    base[s + 1] = base[s] + permutations(m, std::popcount(s));
  return base;
}
constexpr auto base = offsets();
constexpr unsigned groups = base.back();
static_assert(groups == 130922);
template <class T> constexpr auto injection_ranks(const T *tail) {
  std::array<unsigned char, m> position{};
  for (unsigned i = 0; i < m; i++)
    position[tail[i]] = i;
  std::array<std::uint16_t, m + 1> rank{};
  unsigned available = subsets - 1;
  for (unsigned low = 0; low < m; low++) {
    unsigned bit = 1u << position[low];
    rank[low + 1] =
        rank[low] * (m - low) + std::popcount(available & (bit - 1));
    available ^= bit;
  }
  return rank;
}
using Positions = std::array<signed char, m>;
inline unsigned group_of_positions(const Positions &pos) {
  unsigned small = 0, available = subsets - 1, r = 0, n = 0;
  for (unsigned i = 0; i < m; i++)
    if (pos[i] >= 0) {
      unsigned bit = 1u << pos[i];
      small |= 1u << i;
      r = r * (m - n) + std::popcount(available & (bit - 1));
      available ^= bit;
      ++n;
    }
  return base[small] + r;
}
inline Positions positions_of_group(unsigned group) {
  unsigned small =
      std::upper_bound(base.begin(), base.end(), group) - base.begin() - 1;
  unsigned t = std::popcount(small), r = group - base[small];
  std::array<unsigned, m> digits{};
  for (int i = int(t) - 1; i >= 0; i--) {
    digits[i] = r % (m - i);
    r /= m - i;
  }
  Positions positions;
  positions.fill(-1);
  unsigned avail = subsets - 1, j = 0;
  for (unsigned bits = small; bits; bits &= bits - 1) {
    unsigned options = avail;
    for (unsigned d = 0; d < digits[j]; d++)
      options &= options - 1;
    unsigned pos = std::countr_zero(options);
    positions[std::countr_zero(bits)] = pos;
    avail ^= 1u << pos;
    ++j;
  }
  return positions;
}
inline unsigned reflected_group(unsigned group) {
  auto source = positions_of_group(group);
  Positions reflected;
  reflected.fill(-1);
  for (unsigned v = 0; v < m; v++)
    if (source[v] >= 0)
      reflected[m - 1 - source[v]] = m - 1 - v;
  return group_of_positions(reflected);
}
struct Lookup {
  std::array<std::array<std::uint16_t, m + 1>, orders> rank{};
  Lookup() {
    std::array<int, m> p;
    std::iota(p.begin(), p.end(), 0);
    do {
      unsigned key = 0, seen = 0;
      for (unsigned j = 0; j < m; j++) {
        key = key * (j + 1) + std::popcount(seen >> p[j]);
        seen |= 1u << p[j];
      }
      rank[key] = injection_ranks(p.data());
    } while (std::next_permutation(p.begin(), p.end()));
  }
  unsigned id(unsigned order, unsigned set) const {
    unsigned small = set & (subsets - 1);
    return base[small] + rank[order][std::popcount(small)];
  }
};
} // namespace tail_fiber
