"""Exact three-stack sorting via two intermediate total orders (requires python-sat)."""

from argparse import ArgumentParser
from itertools import combinations, permutations
from pathlib import Path

from pysat.solvers import Solver
from replay import replay


def pair_table(cards, offset):
    table = {}
    for number, (a, b) in enumerate(combinations(cards, 2), offset + 1):
        table[a, b] = number
        table[b, a] = -number
    return table


def encode(deck, variable_input=None):
    cards = sorted(deck)
    if len(set(cards)) != len(cards):
        raise ValueError("The deck must contain distinct cards.")
    first = pair_table(cards, 0)
    second = pair_table(cards, len(first) // 2)
    clauses = []
    # A total orientation is transitive precisely when it has no directed 3-cycle.
    for a, b, c in combinations(cards, 3):
        for layer in (first, second):
            cycle = [layer[a, b], layer[b, c], layer[c, a]]
            clauses.extend((cycle, [-v for v in cycle]))

    # One stack forbids exactly the transition a,b,c -> c,a,b on any triple.
    if variable_input is None:
        for a, b, c in combinations(deck, 3):
            clauses.append([-first[c, a], -first[a, b]])
    for a, b, c in permutations(cards, 3):
        clauses.append([-first[a, b], -first[b, c], -second[c, a], -second[a, b]])
    for c, a, b in combinations(cards, 3):
        clauses.append([-second[a, b], -second[b, c]])
    if variable_input is not None:
        for a, b, c in permutations(cards, 3):
            clauses.append(
                [
                    -variable_input[a, b],
                    -variable_input[b, c],
                    -first[c, a],
                    -first[a, b],
                ]
            )
    return first, second, clauses


def unpack(deck, layer, model):
    """A card’s position is its number of predecessors in the total order."""
    return sorted(deck, key=lambda a: sum(layer[b, a] in model for b in deck if a != b))


def operation_word(deck, orders):
    """Request the next desired element recursively from the preceding stack."""
    n = len(deck)
    positions = [0] * 4
    stacks = [[], [], []]
    word = []

    def transfer(k):
        if k == 0:
            card = deck[positions[0]]
        else:
            card = orders[k - 1][positions[k]]
            while not stacks[k - 1] or stacks[k - 1][-1] != card:
                if positions[k - 1] == n:
                    raise ValueError("Invalid intermediate order")
                transfer(k - 1)
            stacks[k - 1].pop()
        if k < 3:
            stacks[k].append(card)
        word.append(str(k + 1))
        positions[k] += 1

    for _ in deck:
        transfer(3)
    assert positions == [n] * 4
    return "".join(word)


def check(deck, certificate=None):
    first, second, clauses = encode(deck)
    nvars = len(first)
    if certificate:
        cnf = Path(str(certificate) + ".cnf")
        with cnf.open("w") as stream:
            print("p cnf", nvars, len(clauses), file=stream)
            for clause in clauses:
                print(*clause, 0, file=stream)
    with Solver(
        name="g4" if certificate else "cadical195",
        bootstrap_with=clauses,
        with_proof=bool(certificate),
    ) as sat:
        if not sat.solve():
            if certificate:
                proof = Path(str(certificate) + ".drat")
                proof.write_text("\n".join(sat.get_proof()) + "\n")
            return None
        model = set(sat.get_model())
    word = operation_word(
        deck, [unpack(deck, first, model), unpack(deck, second, model), sorted(deck)]
    )
    if not replay(deck, word):
        raise AssertionError("SAT witness failed direct stack replay")
    return word


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument(
        "deck", type=int, nargs="+", help="distinct values in arrival order"
    )
    parser.add_argument(
        "--certificate",
        metavar="PREFIX",
        help="write PREFIX.cnf and on UNSAT PREFIX.drat",
    )
    parser.add_argument(
        "--deletions", action="store_true", help="also check every one-point deletion"
    )
    args = parser.parse_args()
    word = check(args.deck, args.certificate)
    print("UNSORTABLE" if word is None else word)
    if args.deletions:
        for i, card in enumerate(args.deck):
            word = check(args.deck[:i] + args.deck[i + 1 :])
            print(f"delete {card}:", "UNSORTABLE" if word is None else word)
