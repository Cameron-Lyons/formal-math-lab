#include "../knuth/layout.hpp"
#include "../structural/reach.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <random>
#include <unordered_map>
#include <vector>

#ifndef CUT
#define CUT 9
#endif
constexpr int k=CUT, n=17;
constexpr unsigned layout_count=1+2*k+3*k*(k-1);
using Mask=std::array<std::uint64_t,(layout_count+63)/64>;
using Word=std::array<int,n>;
struct MaskHash {
    std::size_t operator()(const Mask& mask)const{
        std::size_t h=0;
        for(auto x:mask)h=(h^x)*0x85ebca6b23bbULL;
        return h^(h>>30);
    }
};
int bits(const Mask& mask){
    int count=0;for(auto x:mask)count+=std::popcount(x);
    return count;
}
bool intersects(const Mask& x,const Mask& y){
    for(std::size_t i=0;i<x.size();i++) if(x[i]&y[i])return true;
    return false;
}
bool subset(const Mask& x,const Mask& y){
    for(std::size_t i=0;i<x.size();i++) if(x[i]&~y[i])return false;
    return true;
}
struct Profile{Mask m; int count;};
const auto shapes=layout::layouts(k);
std::vector<Profile> profiles;
std::vector<Mask> minima;
void prepare(int max_min){
    std::unordered_map<Mask,int,MaskHash> counts;
    std::array<unsigned char,k> p;
    std::iota(p.begin(),p.end(),0);
    do {
        Mask mask{};
        for(unsigned j=0;j<shapes.size();j++){
            layout::Prepare prep{p.data(),k,shapes[j]};
            if(prep.test())mask[j/64]|=1ULL<<(j%64);
        }
        counts[mask]++;
    }while(std::next_permutation(p.begin(),p.end()));
    for(auto& [mask,count]: counts)profiles.push_back({mask,count});
    std::sort(profiles.begin(),profiles.end(),[](const Profile&a,const Profile&b){return bits(a.m)<bits(b.m);});
    for (const auto& item:profiles){
        if(std::none_of(minima.begin(),minima.end(),[&](const auto& m){return subset(m,item.m);}))minima.push_back(item.m);
        if(max_min && int(minima.size())>=max_min)break;
    }
    std::cerr<<"profiles "<<profiles.size()<<" minimum/maximum weights "<<bits(profiles.front().m)<<" "<<bits(profiles.back().m)<<" minima "<<minima.size()<<" cap "<<max_min<<"\n";
}
bool reachable(Word& deck,const Word& ranks,unsigned values,const layout::Shape& shape,int budget){
    reach::Search s{deck.data(),n,budget};
    const reach::Node empty{31,31,0,nullptr};
    reach::Node nodes[2];const reach::Node* top=&empty;
    unsigned first=0;
    for(std::size_t j=0;j<shape.first.size();++j){
        int card=ranks[shape.first[j]];deck[j]=card;first|=1u<<j;values^=1u<<card;
    }
    for(std::size_t j=0;j<shape.second.size();++j){
        int card=ranks[shape.second[j]];nodes[j]={card,std::min(card,top->smallest),0,top};top=&nodes[j];values^=1u<<card;
    }
    s.nodes=0;s.exhausted=false;
    return s.dfs(first,top,values,k,0);
}
int main(int argc,char**argv){
    int samples=argc>1?std::atoi(argv[1]):1000;
    int fuel=argc>2?std::atoi(argv[2]):150;
    prepare(argc>3?std::atoi(argv[3]):1500);
    std::mt19937_64 rng(642501);
    Word deck;
    std::uint64_t covered=0,missed=0,max_missed=0;
    for(int sample=1;sample<=samples;sample++){
        std::iota(deck.begin(),deck.end()-1,1);deck.back()=0;
        std::shuffle(deck.begin(),deck.end()-1,rng);
        unsigned values=0;
        Word ranks;
        for(int i=0;i<k;i++)values|=1u<<deck[i];
        int idx=0;for(unsigned rem=values;rem;rem&=rem-1)ranks[idx++]=std::countr_zero(rem);
        Mask mask{};
        for(unsigned j=0;j<shapes.size();j++) if(reachable(deck,ranks,values,shapes[j],fuel))mask[j/64]|=1ULL<<(j%64);
        std::uint64_t un=0;
        for(auto& entry:profiles)if(!intersects(mask,entry.m))un+=entry.count;
        missed+=un; max_missed=std::max(max_missed,un);
        if(!un)covered++;
        if(sample%100==0 || sample==samples)
            std::cerr<<"samples "<<sample<<" universally covered "<<covered<<" uncovered individual candidates "<<missed<<" largest block remainder "<<max_missed<<"\n";
    }
}
