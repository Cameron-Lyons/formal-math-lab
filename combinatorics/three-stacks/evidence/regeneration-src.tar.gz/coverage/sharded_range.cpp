// Scan a contiguous interval of standardized heads against many suffix orders.
// Remote sorting duals are routed by their head rank. The finishing pass can
// read each such head interval once without keeping the complete table in RAM.
#define RANGE_JOIN_LIBRARY
#include "range_join.cpp"
#include <cstdio>
#include <filesystem>
namespace shards {
namespace fs = std::filesystem;
struct Query {
  Id head, block;
};
static_assert(sizeof(Query) == 8);
struct CloseFile {
  void operator()(FILE *file) const { fclose(file); }
};
using File = std::unique_ptr<FILE, CloseFile>;

Id number(const char *text) {
  std::size_t used = 0;
  auto value = std::stoull(text, &used);
  if (text[used] || value > std::numeric_limits<Id>::max())
    throw std::runtime_error("Invalid integer");
  return value;
}
Head unrank(Id rank) {
  Head word{};
  unsigned left = (1u << cut) - 1, ways = heads;
  for (unsigned i = 0; i < cut; i++) {
    ways /= cut - i;
    unsigned digit = rank / ways;
    rank %= ways;
    auto choices = left;
    for (unsigned j = 0; j < digit; j++)
      choices &= choices - 1;
    word[i] = std::countr_zero(choices);
    left ^= 1u << word[i];
  }
  return word;
}
std::vector<WordInfo> sequence(Id first, Id end) {
  std::vector<WordInfo> words(end - first);
  Head word = unrank(first);
  for (auto &w : words) {
    w.rank = word;
    for (unsigned i = 0; i < cut; i++) {
      if (word[i] == cut - 1)
        w.max_position = i;
      if (i && word[i - 1] == word[i] + 1)
        w.descending |= 1u << word[i];
    }
    int i = int(cut) - 2;
    while (i >= 0 && word[i] >= word[i + 1])
      --i;
    if (i >= 0) {
      int j = cut - 1;
      while (word[j] <= word[i])
        --j;
      std::swap(word[i], word[j]);
      for (int a = i + 1, b = cut - 1; a < b; ++a, --b)
        std::swap(word[a], word[b]);
    }
  }
  return words;
}
fs::path part(const fs::path &dir, unsigned group) {
  return dir / ("dual-" + std::to_string(group) + ".bin");
}
struct Spool {
  fs::path path;
  Id group_size;
  std::vector<File> files;
  std::vector<std::uint64_t> counts;
  Spool(const char *dir, Id size)
      : path(dir), group_size(size), counts(1 + (heads - 1) / size) {
    if (!fs::create_directory(dir))
      throw std::runtime_error("Spool directory must be new");
    files.resize(counts.size());
  }
  static void append(void *context, Id head, Id block) {
    auto &spool = *static_cast<Spool *>(context);
    unsigned group = head / spool.group_size;
    auto &file = spool.files[group];
    if (!file) {
      file.reset(fopen(part(spool.path, group).c_str(), "wb"));
      if (!file)
        throw std::runtime_error("Cannot create deferred-dual file");
    }
    const Query entry{head, block};
    if (fwrite(&entry, sizeof(entry), 1, file.get()) != 1)
      throw std::runtime_error("Writing deferred dual failed");
    ++spool.counts[group];
  }
  void finish(Id first, Id end, Id t0, Id t1, Id stride,
              std::uint64_t expected) {
    for (auto &file : files)
      if (file && fclose(file.release()) != 0)
        throw std::runtime_error("Writing dual file failed");
    if (std::accumulate(counts.begin(), counts.end(), uint64_t{0}) != expected)
      throw std::logic_error("Incorrect deferred count");
    std::ofstream log(path / "manifest.tmp");
    log << "STACK_DUAL_1 " << n << ' ' << cut << ' ' << group_size << ' '
        << first << ' ' << end << ' ' << t0 << ' ' << t1 << ' ' << stride << ' '
        << expected << '\n';
    for (unsigned i = 0; i < counts.size(); i++)
      log << i << ' ' << counts[i] << '\n';
    log.close();
    if (!log)
      throw std::runtime_error("Writing manifest failed");
    fs::rename(path / "manifest.tmp", path / "manifest");
  }
};
int scan(int argc, char **argv, bool slice) {
  std::string cached_offers, dual_projection;
  unsigned group_depth = 0;
  while (argc >= 13) {
    std::string flag = argv[argc - 2];
    if (flag == "--early-cache")
      cached_offers = argv[argc - 1];
    else if (flag == "--dual-projection")
      dual_projection = argv[argc - 1];
    else if (flag == "--prefix-depth")
      group_depth = number(argv[argc - 1]);
    else
      break;
    argc -= 2;
  }
  if (argc < 11 || argc > 16)
    throw std::runtime_error(
        "scan HEAD_TABLE TAIL_TABLE HEAD_BEGIN HEAD_END ORDER_BEGIN ORDER_END "
        "STRIDE NEW_SPOOL_DIR GROUP_ROWS [EARLIER_TABLE [FUEL [LEAF_FUEL "
        "[NEXT_CUT [LAST_CUT]]]]]");
  Id first = number(argv[4]), end = number(argv[5]), t0 = number(argv[6]),
     t1 = number(argv[7]), stride = number(argv[8]), group = number(argv[10]);
  if (first >= end || end > heads || t0 >= t1 || t1 > tail_orders || !stride ||
      !group || group > heads)
    throw std::runtime_error("Invalid scan range");
  TableFile h(argv[2], heads, first, end, slice), t(argv[3], blocks, true);
  Coding codec(nullptr);
  auto words = sequence(first, end);
  Spool spool(argv[9], group);
  ranges::Search run(
      h, t, codec,
      argc > 11 && std::string(argv[11]) != "-" ? argv[11] : nullptr,
      argc > 12 ? number(argv[12]) : 0, argc > 13 ? number(argv[13]) : 0, true);
  if (!cached_offers.empty()) {
    if (!run.early)
      throw std::runtime_error("An earlier table is required to cache offers");
    std::filesystem::create_directories(cached_offers);
    run.early->offer_cache_directory = cached_offers;
  }
  if (!dual_projection.empty())
    run.quick_dual =
        std::make_unique<::dual_projection::File<cut>>(dual_projection.c_str());
  if (group_depth > cut)
    throw std::runtime_error("Invalid fixed-prefix depth");
  run.group_depth = group_depth;
  if (argc > 14 && std::string(argv[14]) != "-")
    run.next_cut =
        std::make_unique<nested_recut::Filter<n, cut - 2>>(argv[14], 1000);
  if (argc > 15 && std::string(argv[15]) != "-")
    run.last_cut =
        std::make_unique<nested_recut::Filter<n, cut - 3>>(argv[15], 1000);
  run.shard(first, end, words.data(), Spool::append, &spool);
  uint64_t seen = 0, deferred = 0;
  for (uint64_t tau = t0; tau < t1; tau += stride) {
    run.run(tau);
    seen += run.accounted;
    deferred += run.deferred;
  }
  uint64_t total =
      uint64_t(end - first) * embeddings * (1 + (t1 - t0 - 1) / stride);
  if (total != seen)
    throw std::logic_error("Incomplete prefix shard");
  spool.finish(first, end, t0, t1, stride, deferred);
  std::cerr << "scanned " << seen << " deferred " << deferred << " group_rows "
            << group << '\n';
  return 0;
}
struct Manifest {
  Id size;
  std::vector<uint64_t> counts;
  explicit Manifest(const fs::path &path) {
    std::ifstream in(path / "manifest");
    std::string tag;
    unsigned deck, shorter;
    Id first, end, t0, t1, step;
    uint64_t total;
    if (!(in >> tag >> deck >> shorter >> size >> first >> end >> t0 >> t1 >>
          step >> total) ||
        tag != "STACK_DUAL_1" || deck != n || shorter != cut || !size ||
        size > heads || first >= end || end > heads || t0 >= t1 ||
        t1 > tail_orders || !step)
      throw std::runtime_error("Incorrect or incomplete dual manifest");
    counts.resize(1 + (heads - 1) / size);
    for (unsigned i = 0; i < counts.size(); i++) {
      unsigned j;
      if (!(in >> j >> counts[i]) || j != i)
        throw std::runtime_error("Incorrect dual manifest groups");
    }
    if (std::accumulate(counts.begin(), counts.end(), uint64_t{0}) != total)
      throw std::runtime_error("Incorrect manifest total");
  }
};
// For sparse target groups, construct only the offered prefix layouts that
// are needed. Repeated queries at the same head share the direct checks.
class LazyPrefix {
  Id rank = heads;
  Head word;
  Mask tested{}, yes{};
  std::vector<layout::Shape> shapes = layout::layouts(cut);

public:
  bool hit(Id id, const Mask &offered) {
    if (id != rank) {
      rank = id;
      word = unrank(id);
      tested = {};
      yes = {};
    }
    if (ranges::hit(yes, offered))
      return true;
    for (unsigned w = 0; w < tested.size(); w++) {
      auto todo = offered[w] & ~tested[w];
      while (todo) {
        auto bit = todo & -todo;
        unsigned j = 64 * w + std::countr_zero(todo);
        if (j >= shapes.size())
          throw std::runtime_error("Unused tail layout bit");
        todo ^= bit;
        tested[w] |= bit;
        layout::Prepare prepare{word.data(), cut, shapes[j]};
        if (prepare.test()) {
          yes[w] |= bit;
          return true;
        }
      }
    }
    return false;
  }
};
int finish(int argc, char **argv, bool slice) {
  if (argc < 6)
    throw std::runtime_error(
        "finish HEAD_TABLE TAIL_TABLE DUAL_GROUP SPOOL_DIR [SPOOL_DIR ...]");
  unsigned group = number(argv[4]);
  auto first_manifest = Manifest(argv[5]);
  if (group >= first_manifest.counts.size())
    throw std::runtime_error("Invalid target group");
  Id width = first_manifest.size, lo = group * width,
     hi = std::min<uint64_t>(heads, uint64_t(lo) + width);
  std::unique_ptr<TableFile> h;
  if (std::string(argv[2]) != "-")
    h = std::make_unique<TableFile>(argv[2], heads, lo, hi, slice);
  TableFile t(argv[3], blocks, true);
  Coding codec(nullptr);
  LazyPrefix sparse;
  uint64_t examined = 0, accepted = 0;
  std::vector<Query> queries(131072);
  for (int arg = 5; arg < argc; arg++) {
    fs::path dir = argv[arg];
    Manifest manifest(dir);
    if (group >= manifest.counts.size() || (width && width != manifest.size))
      throw std::runtime_error("Incompatible group size or index");
    width = manifest.size;
    auto expected = manifest.counts[group];
    if (!expected)
      continue;
    auto file = part(dir, group);
    if (fs::file_size(file) != sizeof(Query) * expected)
      throw std::runtime_error("Truncated dual file");
    File input(fopen(file.c_str(), "rb"));
    if (!input)
      throw std::runtime_error("Cannot read dual file");
    while (expected) {
      auto chunk = std::min<uint64_t>(queries.size(), expected);
      expected -= chunk;
      if (fread(queries.data(), sizeof(Query), chunk, input.get()) != chunk)
        throw std::runtime_error("Reading deferred duals failed");
      std::sort(queries.begin(), queries.begin() + chunk, [](Query a, Query b) {
        return a.head < b.head || (a.head == b.head && a.block < b.block);
      });
      for (unsigned i = 0; i < chunk; i++) {
        Query q = queries[i];
        if (q.head >= heads || q.head / width != group || q.block >= blocks)
          throw std::runtime_error("Invalid deferred-dual key");
        const auto &offered = t[q.block];
        ++examined;
        if (h ? ranges::hit((*h)[q.head], offered)
              : sparse.hit(q.head, offered)) {
          ++accepted;
          continue;
        }
        Deck original{};
        auto w = unrank(q.head);
        const auto &e = codec.labels[q.block % embeddings];
        const auto &tau = codec.orders[q.block / embeddings];
        for (unsigned i = 0; i < cut; ++i)
          original[n - 1 - e.front[w[i]]] = n - 1 - i;
        for (unsigned i = 0; i < ordinary; ++i)
          original[n - 1 - e.back[tau[i]]] = n - 1 - cut - i;
        std::cout << "Hard 1";
        for (int x : original)
          std::cout << ' ' << x + 1;
        std::cout << '\n';
      }
    }
  }
  std::cerr << "dual group " << group << " examined " << examined
            << " accepted " << accepted << " pending " << examined - accepted
            << '\n';
  return 0;
}
} // namespace shards
int main(int argc, char **argv) {
  std::ios::sync_with_stdio(false);
  try {
    std::string mode = argc > 1 ? argv[1] : "";
    if (mode == "scan" || mode == "scan-slice")
      return shards::scan(argc, argv, mode == "scan-slice");
    if (mode == "finish" || mode == "finish-slice")
      return shards::finish(argc, argv, mode == "finish-slice");
    throw std::runtime_error("Expected scan or finish");
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
