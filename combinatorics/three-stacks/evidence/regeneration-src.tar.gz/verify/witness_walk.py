"""Walk between 21-card obstructions one deleted/reinserted point at a time."""
import argparse
from collections import deque
from itertools import combinations
import json
from pathlib import Path
import random
import subprocess
from check import check
from neighborhood import VariableInput
from replay import PANTONE_VATTER


def normalize(p):
    rank = {v: i + 1 for i, v in enumerate(sorted(p))}
    return bytes(rank[x] for x in p)


def representative(p):
    p = bytearray(p)
    i = p.index(1)
    p[i], p[-1] = p[-1], p[i]
    q = bytearray(len(p))
    for i, v in enumerate(p):
        q[len(p)-v] = len(p)-i
    return min(bytes(p), bytes(q))


def deletions(p):
    return {representative(normalize(p[:i]+p[i+1:])) for i in range(len(p))}


def insertions(p):
    n = len(p)
    for rank in range(2, n+2):
        q = bytes(x+(x >= rank) for x in p)
        card = bytes([rank])
        for pos in range(n):
            yield representative(q[:pos]+card+q[pos:])


def hard(pile, n, checker):
    text = ''.join('Hard 1 '+' '.join(map(str, p))+'\n' for p in pile)
    proc = subprocess.run([checker, str(n), '120', str(n-6), str(n-7), str(n-5), str(n-8), '8', '7'], input=text, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    stats = proc.stderr.split()
    if int(stats[1])+int(stats[3]) != len(pile):
        raise RuntimeError('Cut filter lost inputs')
    return [bytes(map(int, l.split()[2:])) for l in proc.stdout.splitlines()]


def walk(args):
    root = Path(args.work)
    root.mkdir(exist_ok=True)
    rng = random.Random(7734)
    solvers = {n:VariableInput(n) for n in (19,20,21,22)}
    initial = representative(PANTONE_VATTER)
    known = {initial}
    seen = {initial}
    queue = deque([initial])
    done20 = set()
    record = (root/'witnesses.jsonl').open('a', buffering=1)
    def confirm(p):
        if check(list(p)) is not None:
            raise RuntimeError('Independent verifier did not confirm UNSAT')
        if len(p)<=20:
            proof = root/f'candidate-{len(p)}'
            if check(list(p), proof) is not None:
                raise RuntimeError('Certificate solver did not confirm UNSAT')
            print('FOUND',list(p),proof,flush=True)
            raise SystemExit(2)
    def examine(p):
        if p in known:return
        confirm(p)
        for d in sorted(deletions(p)):
            if d in done20:continue
            done20.add(d)
            if not solvers[20].solve(list(d)):
                confirm(d)
        known.add(p);queue.append(p)
        print(json.dumps(list(p)),file=record)
    rounds=0
    while queue and rounds<args.rounds:
        seed = queue.popleft();rounds+=1
        candidates = {q for d in deletions(seed) for q in insertions(d)}-seen
        seen.update(candidates)
        survivors=hard(sorted(candidates),21,args.flex)
        rng.shuffle(survivors)
        for q in survivors:
            if not solvers[21].solve(list(q)):
                examine(q)
        print(f'round {rounds}, fresh inputs {len(candidates)}, SAT checks {len(survivors)}, known obstructions {len(known)}, checked 20-card neighbors {len(done20)}',flush=True)
    # Insert two replacement cards after deleting one from a known 21-card obstruction.
    # Even when the one-point component is small, a 22-card bridge can contain a different obstruction.
    bridge_seen=set()
    for batch in range(args.bridges):
        source = rng.choice(tuple(sorted(known)))
        bases = sorted(deletions(source))
        trials=set()
        for _ in range(1300):
            q=rng.choice(bases)
            for size in (21,22):
                i=rng.randrange(size-1);v=rng.randrange(2,size+1);lift=bytes(x+(x>=v) for x in q);q=lift[:i]+bytes([v])+lift[i:]
            trials.add(representative(q))
        trials.difference_update(bridge_seen)
        bridge_seen.update(trials)
        survivors=hard(sorted(trials),22,args.flex)
        found=0
        for q in survivors:
            if solvers[22].solve(list(q)):continue
            found+=1
            for d in deletions(q)-seen:
                seen.add(d)
                if not solvers[21].solve(list(d)):examine(d)
        print(f'bridge batch {batch+1}, inputs {len(trials)}, SAT checks {len(survivors)}, unsortable bridges {found}, known 21-card obstructions {len(known)}, 20-card inputs {len(done20)}',flush=True)
    record.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('work');parser.add_argument('flex');parser.add_argument('--rounds',type=int,default=35);parser.add_argument('--bridges',type=int,default=20)
    walk(parser.parse_args())
