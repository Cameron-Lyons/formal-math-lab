// Resolve deferred dual queries without a full k-card prefix table.
// The same prefix often recurs. Cache the individual tested layout columns
// while visiting its queries, including the first witness for each success.
#ifndef CARD_COUNT
#define CARD_COUNT 20
#endif
#include "../knuth/layout.hpp"
#include "join_tables.hpp"
#include "stream_tail.hpp"
#include <filesystem>
namespace fs = std::filesystem;
struct Query {
  Id h, b;
};
Head unrank(Id rank) {
  Head p;
  Id left = (1u << cut) - 1, ways = heads;
  for (unsigned i = 0; i < cut; i++) {
    ways /= cut - i;
    unsigned digit = rank / ways;
    rank %= ways;
    Id avail = left;
    for (unsigned j = 0; j < digit; j++)
      avail &= avail - 1;
    p[i] = std::countr_zero(avail);
    left ^= 1u << p[i];
  }
  return p;
}
int main(int argc, char **argv) {
  if (argc < 4)
    throw std::runtime_error("usage: lazy-dual PACKED_TAIL COLUMN_PRIORITY "
                             "[--ordered] SPOOL_DIR...");
  std::ios::sync_with_stdio(false);
  bool ordered = std::string(argv[3]) == "--ordered";
  if (ordered && argc < 5)
    throw std::runtime_error("Missing order-grouped spool");
  std::unique_ptr<StreamTail> stream;
  std::unique_ptr<TableFile> tail;
  if (ordered)
    stream = std::make_unique<StreamTail>(argv[1]);
  else
    tail = std::make_unique<TableFile>(argv[1], blocks, true);
  std::ifstream menu(argv[2]);
  unsigned x;
  std::vector<unsigned> priority;
  Mask in_priority{};
  while (menu >> x) {
    if (x >= columns || ((in_priority[x / 64] >> (x % 64)) & 1))
      throw std::runtime_error("Invalid column priority");
    in_priority[x / 64] |= 1ULL << (x % 64);
    priority.push_back(x);
  }
  if (!menu.eof())
    throw std::runtime_error("Cannot read priority list");
  auto shapes = layout::layouts(cut);
  Coding codec(nullptr);
  std::uint64_t seen = 0, ok = 0, miss = 0, tested = 0, sc = 0;
  std::vector<Query> batch(262144);
  for (int dir = ordered ? 4 : 3; dir < argc; dir++) {
    std::vector<fs::path> paths;
    for (auto f : fs::directory_iterator(argv[dir]))
      if (f.path().extension() == ".bin")
        paths.push_back(f.path());
    std::sort(paths.begin(), paths.end());
    for (auto path : paths) {
      std::ifstream file(path, std::ios::binary);
      if (!file)
        throw std::runtime_error("Cannot open query file");
      while (file) {
        file.read(reinterpret_cast<char *>(batch.data()),
                  sizeof(Query) * batch.size());
        auto count = file.gcount() / sizeof(Query);
        if (file.gcount() % sizeof(Query))
          throw std::runtime_error("Truncated query file");
        std::sort(batch.begin(), batch.begin() + count, [&](auto a, auto b) {
          if (ordered && a.b / embeddings != b.b / embeddings)
            return a.b / embeddings < b.b / embeddings;
          return a.h < b.h;
        });
        unsigned prev = heads;
        Head p;
        Mask checked{}, good{};
        for (unsigned j = 0; j < count; j++) {
          auto [h, b] = batch[j];
          if (h >= heads || b >= blocks)
            throw std::runtime_error("Invalid deferred key");
          if (h != prev) {
            p = unrank(h);
            prev = h;
            checked = {};
            good = {};
            ++sc;
          }
          const auto &t = ordered ? (*stream)[b] : (*tail)[b];
          ++seen;
          if (!disjoint(good, t)) {
            ++ok;
            continue;
          }
          auto try_row = [&](unsigned c) {
            ++tested;
            auto unit = 1ULL << (c % 64);
            checked[c / 64] |= unit;
            layout::Prepare prep{p.data(), cut, shapes[c]};
            if (!prep.test())
              return false;
            good[c / 64] |= unit;
            return true;
          };
          bool passed = false;
          for (auto c : priority)
            if (((t[c / 64] & ~checked[c / 64]) >> (c % 64)) & 1)
              if (try_row(c)) {
                passed = true;
                break;
              }
          for (unsigned w = 0; !passed && w < t.size(); w++)
            for (auto bits = t[w] & ~checked[w]; bits; bits &= bits - 1)
              if (try_row(w * 64 + std::countr_zero(bits))) {
                passed = true;
                break;
              }
          if (passed) {
            ++ok;
            continue;
          }
          ++miss;
          const auto &embedding = codec.labels[b % embeddings];
          const auto &suffix = codec.orders[b / embeddings];
          std::cout << "Hard 1";
          for (auto v : p)
            std::cout << ' ' << int(embedding.front[v]) + 1;
          for (auto v : suffix)
            std::cout << ' ' << int(embedding.back[v]) + 1;
          std::cout << " 1\n";
        }
      }
      if (!file.eof())
        throw std::runtime_error("Reading query file failed");
    }
  }
  if (ok + miss != seen || !std::cout)
    throw std::runtime_error("Incomplete dual classification");
  std::cerr << "Deferred " << seen << " sorted " << ok << " pending " << miss
            << " tested layout columns " << tested << " visited prefix runs "
            << sc << "\n";
}
