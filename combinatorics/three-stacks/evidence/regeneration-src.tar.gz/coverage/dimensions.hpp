#pragma once
#include "prefix.hpp"
#include <array>
#include <bit>
#include <cstdint>
#include <limits>
#include <type_traits>

#ifndef DECK_SIZE
#define DECK_SIZE 17
#endif

namespace dimensions {
constexpr int n = DECK_SIZE;
constexpr int ordinary = n - prefix::size - 1;
static_assert(
    ordinary >= 0 && ordinary <= 8,
    "The continuation algorithms support up to eight ordinary tail cards");
constexpr int factorial(int a) {
  int value = 1;
  for (int i = 2; i <= a; ++i)
    value *= i;
  return value;
}
constexpr int choose(int a, int b) {
  int value = 1;
  for (int i = 1; i <= b; ++i)
    value = value * (a - b + i) / i;
  return value;
}
constexpr int orders = factorial(ordinary), sets = choose(n - 1, ordinary);
constexpr unsigned stride = 1U << (ordinary + 2);
constexpr unsigned columns =
    1 + 2 * (ordinary + 1) + 3 * (ordinary + 2) * (ordinary + 2);
constexpr unsigned keys = columns * stride;
using PackedKey =
    std::conditional_t<keys - 1 <= std::numeric_limits<std::uint16_t>::max(),
                       std::uint16_t, std::uint32_t>;
constexpr std::size_t rows = std::size_t(orders) * sets;
using Order = std::array<int, ordinary>;

// Invert tail::rank_order by unpacking its ascending mixed radices backwards.
inline Order order(int rank) {
  Order out;
  unsigned available = (1U << ordinary) - 1;
  for (int i = ordinary - 1; i >= 0; --i) {
    int smaller = i - rank % (i + 1);
    rank /= i + 1;
    unsigned options = available;
    while (smaller--)
      options &= options - 1;
    out[i] = std::countr_zero(options);
    available ^= 1U << out[i];
  }
  return out;
}
} // namespace dimensions
