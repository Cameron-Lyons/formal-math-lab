// Prefer the orientation whose normalized tail is quickest to certify.
// For fixed tail labels and a fixed tail word, the dual tail word depends
// only on the relative order of the b smallest prefix letters. Enumerate
// each such subdomain together; no particular speed prediction is a premise.
#define CARD_COUNT 19
#define RANGE_JOIN_LIBRARY
#include "range_join.cpp"
#include "quadrant_codes.hpp"
#include <map>
#include <filesystem>
namespace ordered {
constexpr auto f=quadrant_codes::factorials<cut>();
struct Ranks {
 int fd;const Id* data;size_t bytes=size_t(heads)*6*sizeof(Id);
 explicit Ranks(const std::filesystem::path& src){fd=open(src.c_str(),O_RDONLY);struct stat st;if(fd<0||fstat(fd,&st)||st.st_size!=off_t(bytes))throw std::runtime_error("Invalid low-order index");data=(const Id*)mmap(nullptr,bytes,PROT_READ,MAP_SHARED,fd,0);close(fd);if(data==MAP_FAILED)throw std::runtime_error("Cannot mmap low-order index");}
 ~Ranks(){munmap((void*)data,bytes);}
 template<class Fn>void each(unsigned b,const std::vector<Id>& keys,Fn&& fn)const{
  if(keys.size()==f[b]){for(Id id=0;id<heads;id++)fn(id);return;}
  const Id count=heads/f[b];for(Id key:keys){auto from=data+size_t(b-2)*heads+key*count;for(Id i=0;i<count;i++)fn(from[i]);}
 }
};
struct Policy {
 std::array<unsigned,tail_orders> priority{};std::array<bool,tail_orders> old{};
 explicit Policy(const std::filesystem::path& file){std::ifstream in(file);std::array<bool,tail_orders> seen{};for(unsigned i=0;i<tail_orders;i++){unsigned tau,legacy;if(!(in>>tau>>legacy)||tau>=tail_orders||legacy>1||seen[tau])throw std::runtime_error("Invalid rank priority");priority[tau]=i;old[tau]=legacy;seen[tau]=true;}}
 unsigned mode(unsigned t,unsigned d)const{if(old[t]||old[d]||t==d)return 2;return priority[t]<priority[d]?1:0;}
};
struct Group {uint64_t full=0,lex=0;auto operator<=>(const Group&)const=default;};
struct Join {
 ranges::Search run;const Ranks& ids;const Policy& policy;
 std::array<std::vector<int>,128> by_low;std::vector<std::array<uint16_t,cut>> omit;
 uint64_t owned=0,skipped=0,groups=0;uint64_t probed=0;
 Join(const TableFile& table,const TableFile& tail,const Coding& code,const char* early,const Ranks& ids,const Policy& pol):run(table,tail,code,early,200,1000),ids(ids),policy(pol),omit(embeddings){}
 void scan(unsigned b,const std::vector<Id>& keys,bool lex){
  auto& r=run;auto num=uint64_t(keys.size())*(heads/f[b]);if(r.active.empty()||!num)return;
  ++groups;owned+=num*r.active.size();probed+=num;r.tree.clear();r.compare_ties=lex;for(int s:r.active)r.leaves[s].omit=lex?omit[s]:std::array<uint16_t,cut>{};
  // The regular clustered tree has little to gain on intervals of a few hundred embeddings.
  r.cluster=false;auto root=r.build(0,r.active.size());const auto& node=r.tree[root];auto before=r.accounted;
  std::vector<Id> next;next.reserve(r.batch);r.records.clear();uint64_t pass=0;
  auto flush=[&]{if(next.empty())return;if(node.leaf>=0)r.visit(root,next);else{for(int j=0;j<node.children;j++){int child=node.child[j];auto& p=r.tree[child];std::vector<Id> good;good.reserve(next.size());for(auto at:next){auto& c=r.records[at];if(!ranges::hit(c.mask,p.mask)&&!r.other_accepts(p,c))good.push_back(at);}r.accounted+=uint64_t(next.size()-good.size())*p.span;if(!good.empty())r.visit(child,good);}}next.clear();r.records.clear();};
  ids.each(b,keys,[&](Id id){auto& mask=r.heads_table[id];if(ranges::hit(mask,node.mask))return;auto& w=r.words[id];auto early=r.early->available[r.earlier_rank(w)];ranges::Record c{mask,early,r.features(w),id};if(!r.other_accepts(node,c)){next.push_back(r.records.size());r.records.push_back(c);++pass;if(r.records.size()>=r.batch)flush();}});flush();r.accounted+=(num-pass)*node.span;r.checked+=num;
  if(r.accounted-before!=num*node.span)throw std::logic_error("Incomplete grouped search");
 }
 void grouped(unsigned tau){
  auto& r=run;std::vector<int> usable=r.active;for(auto& v:by_low)v.clear();for(int s:usable){unsigned low=0;for(auto v:r.codec.labels[s].back)if(v<=7)low|=1u<<(v-1);by_low[low].push_back(s);omit[s]=r.leaves[s].omit;}
  skipped=uint64_t(embeddings-usable.size())*heads;
  for(unsigned b=0;b<=ordinary;b++){
   std::vector<unsigned> sets;for(unsigned mask=0;mask<128;mask++)if(b+std::popcount(mask)==7&&!by_low[mask].empty())sets.push_back(mask);
   std::vector<Group> status(f[b]);std::array<unsigned,cut> word;std::iota(word.begin(),word.end(),0);
   for(unsigned t=0;t<sets.size();t++){
    auto& l=r.leaves[by_low[sets[t]][0]];quadrant::Encoder<n,cut> enc(l.prefix,l.suffix);
    if(enc.low_count!=int(b))throw std::runtime_error("Wrong low-label count");std::iota(word.begin(),word.end(),0);
    do{unsigned id=quadrant_codes::encode_prefix<cut>(word.data()).low%f[b];auto key=enc.key(word.data());unsigned m=policy.mode(tau,key.order);
     if(m==1)status[id].full|=1ull<<t;else if(m==2)status[id].lex|=1ull<<t;else skipped+=uint64_t(heads/f[b])*by_low[sets[t]].size();
    }while(std::next_permutation(word.begin(),word.begin()+b));
   }
   std::map<uint64_t,std::vector<Id>> all,lex;for(unsigned j=0;j<f[b];j++){if(status[j].full)all[status[j].full].push_back(j);if(status[j].lex)lex[status[j].lex].push_back(j);}
   for(auto m:{false,true})for(auto& [bits,keys]:(m?lex:all)){r.active.clear();for(unsigned i=0;i<sets.size();i++)if((bits>>i)&1){auto& offer=by_low[sets[i]];r.active.insert(r.active.end(),offer.begin(),offer.end());}scan(b,keys,m);}
  }
  if(owned+skipped!=uint64_t(heads)*embeddings)throw std::logic_error("Missing canonical orientation blocks");
 }
 void check(unsigned tau,bool use_group){auto& r=run;r.checked=r.individual=r.noncanonical=r.dual_ok=r.remaining=r.additional=r.accounted=r.deferred=0;r.root_count=r.next_ok=r.last_ok=r.late_direct=r.late_dual=0;owned=skipped=groups=probed=0;if(r.next_cut)r.next_cut->reset();if(r.last_cut)r.last_cut->reset();auto start=std::chrono::steady_clock::now();r.prepare(tau);
#ifdef ORDERED_PROJECTED
  r.fast->prepare(r.leaves);
#endif
  auto prep=std::chrono::steady_clock::now();
  if(use_group)grouped(tau);else{for(int s:r.active)r.leaves[s].omit={};r.compare_ties=false;r.scan_active();owned=uint64_t(heads)*embeddings;}
  r.flush_nested();if(r.accounted!=owned)throw std::logic_error("Incorrect total");std::cout.flush();std::cerr<<"order "<<tau<<" decks "<<uint64_t(heads)*embeddings<<" delegated_or_bond "<<skipped<<" owned "<<owned<<" group_count "<<groups<<" head_visits "<<probed<<" leaf "<<r.individual<<" mirror "<<r.noncanonical<<" dual "<<r.dual_ok<<" extra "<<r.additional<<" late "<<r.late_direct<<" late_dual "<<r.late_dual<<" pending "<<r.remaining<<" prepare "<<std::chrono::duration<double>(prep-start).count()<<" seconds "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<'\n';
 }
};
}
int main(int ac,char**av){using namespace ordered;if(ac<7||ac>9)throw std::runtime_error("work earlier priority-list suffix-list hard-count limit [earlier9 earlier8]");std::ios::sync_with_stdio(false);std::filesystem::path root=av[1];Policy pol(av[3]);std::ifstream orders(av[4]);if(!orders)throw std::runtime_error("Cannot open suffix order list");unsigned hard=std::stoul(av[5]),limit=std::stoul(av[6]);TableFile h((root/"prefix11.bin").c_str(),heads),t((root/"verify-tail19-packed.bin").c_str(),blocks,true);IndexFile idx;idx.load((root/"verify-index11.bin").c_str(),h);Coding codec(idx.words());Ranks ids(root/"low-index11.bin");Join sorter(h,t,codec,av[2],ids,pol);
#ifdef ORDERED_PROJECTED
sorter.run.fast=std::make_unique<ordered_acceleration::Dual>(root);
#endif
if(ac>=8)sorter.run.next_cut=std::make_unique<nested_recut::Filter<n,cut-2>>(av[7],1000);if(ac>=9)sorter.run.last_cut=std::make_unique<nested_recut::Filter<n,cut-3>>(av[8],1000);unsigned count=0,tau;while(orders>>tau && (!limit||count<limit)){if(tau>=tail_orders)throw std::runtime_error("Invalid input rank");sorter.check(tau,pol.priority[tau]>=tail_orders-hard);count++;}}
