#pragma once
#include <algorithm>
#include <numeric>
#include <vector>

namespace two {
std::vector<char> tab[12], endtab[12];

// Two stacks. The final stack must decrease from bottom to top.
// Any exposed least remaining card may go straight to output.
bool twoRec(const int *p, int len, unsigned inp, unsigned A, unsigned B,
            unsigned needed) {
  if (needed == (unsigned)len)
    return true;
  unsigned val = inp < (unsigned)len ? p[inp] : 99;
  unsigned apos = A ? 31 - __builtin_clz(A) : 0;
  unsigned a = A ? p[apos] : 99;
  unsigned b = B ? __builtin_ctz(B) : 99;
  if (b == needed)
    return twoRec(p, len, inp, A, B ^ (1u << b), needed + 1);
  if (a == needed)
    return twoRec(p, len, inp, A ^ (1u << apos), B, needed + 1);
  if (val == needed)
    return twoRec(p, len, inp + 1, A, B, needed + 1);
  if (a < b && twoRec(p, len, inp, A ^ (1u << apos), B | (1u << a), needed))
    return true;
  return inp < (unsigned)len &&
         twoRec(p, len, inp + 1, A | (1u << inp), B, needed);
}
int rankword(const int *p, int length, bool complement) {
  unsigned seen = 0;
  int result = 0;
  for (int i = 0; i < length; i++) {
    unsigned greater = __builtin_popcount(seen >> p[i]);
    result = result * (i + 1) + (complement ? i - greater : greater);
    seen |= 1u << p[i];
  }
  return result;
}
bool twocheck(const int *p, int len, bool complement) {
  int pp[22];
  unsigned mask = 0;
  for (int i = 0; i < len; i++)
    mask |= 1u << p[i];
  for (int i = 0; i < len; i++) {
    int v = __builtin_popcount(mask & ((1u << p[i]) - 1));
    pp[i] = complement ? len - 1 - v : v;
  }
  return twoRec(pp, len, 0, 0, 0, 0);
}
void computeTab(int maxl) {
  int fac = 1;
  for (int m = 1; m <= maxl; m++) {
    fac *= m;
    tab[m].resize(fac);
    endtab[m].resize(fac);
    if (m < 6) {
      std::fill(tab[m].begin(), tab[m].end(), 1);
      std::fill(endtab[m].begin(), endtab[m].end(), 1);
      continue;
    }
    int p[22];
    std::iota(p, p + m, 0);
    do {
      auto rk = rankword(p, m, false);
      tab[m][rk] = twoRec(p, m, 0, 0, 0, 0);
      int q[22];
      for (int i = 0; i < m; i++)
        q[i] = p[i] + 1;
      q[m] = 0;
      endtab[m][rk] = twoRec(q, m + 1, 0, 0, 0, 0);
    } while (std::next_permutation(p, p + m));
  }
}

} // namespace two
