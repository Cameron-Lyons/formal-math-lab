#pragma once
#include "../knuth/layout.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>

namespace prefix {
#ifndef DECK_CUT
#define DECK_CUT 10
#endif
constexpr int size=DECK_CUT;
static_assert(size>=6 && size<=12);
constexpr int count=[](){int f=1;for(int i=2;i<=size;i++)f*=i;return f;}();
constexpr int layout_count=1+2*size+3*size*(size-1);
using Mask=std::array<std::uint64_t,(layout_count+63)/64>;
inline bool any(const Mask& a,const Mask& b){
    for(unsigned i=0;i<a.size();++i)if(a[i]&b[i])return true;
    return false;
}
inline bool has(const Mask& m,unsigned i){return m[i/64]&(1ULL<<(i%64));}
inline void add(Mask& m,unsigned i){m[i/64]|=1ULL<<(i%64);}
inline std::array<int,size> permutation(int rank) {
    std::array<int,size> word;
    unsigned left=(1u<<size)-1;
    int ways=count;
    for(int i=0;i<size;++i){
        ways/=size-i;
        int skip=rank/ways;
        rank%=ways;
        unsigned avail=left;
        while(skip--)avail&=avail-1;
        word[i]=std::countr_zero(avail);
        left^=1u<<word[i];
    }
    return word;
}
inline std::vector<Mask> read(const std::string& filename){
    std::ifstream file(filename,std::ios::binary|std::ios::ate);
    if(!file || file.tellg()!=static_cast<std::streamoff>(sizeof(Mask)*count))
        throw std::runtime_error("Missing or incomplete prefix layout table");
    file.seekg(0);
    std::vector<Mask> masks(count);
    file.read(reinterpret_cast<char*>(masks.data()),sizeof(Mask)*count);
    if(!file)throw std::runtime_error("Failed to read prefix table");
    return masks;
}
}
