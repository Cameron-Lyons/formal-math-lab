// Build with c++ -O3 -std=c++20 splice_search.cpp -o splice_search
// Run ./splice_search FLAT_PREFIX LIMIT. A zero limit exhausts the prefix.
#include <algorithm>
#include <array>
#include <bit>
#include <charconv>
#include <cstdint>
#include <iostream>
#include <string_view>

namespace {
constexpr int first_open_row = 6;
constexpr int last_row = 9;

class Search {
public:
    explicit Search(std::uint64_t limit) : limit_(limit) {
        available_.fill(0b111);
    }

    void run(std::string_view prefix) {
        for (int row = 0; row < first_open_row; ++row) {
            for (int col = 0; col <= 2 * row; ++col) {
                int color = prefix[row * row + col] - '0';
                rows_[row][col] = color;
                if (--remaining_top_[color] < 0) return;
                if (col >= 2) {
                    int pair = 3 * rows_[row][col - 2] + rows_[row][col - 1];
                    unsigned &choices = available_[9 * rows_[row - 1][col - 2] + pair];
                    unsigned bit = 1u << color;
                    if (!(choices & bit)) return;
                    choices ^= bit;
                }
            }
            if (row > 0) {
                ++balance_[3 * rows_[row][0] + rows_[row][1]];
                --balance_[3 * rows_[row][2 * row - 1] + rows_[row][2 * row]];
            }
        }
        int excess = 0;
        for (int degree : balance_) excess += std::max(degree, 0);
        start_row<first_open_row>(excess);
    }

    std::uint64_t found() const { return found_; }
    bool limit_reached() const { return limit_ != 0 && found_ == limit_; }

private:
    std::array<std::array<int, 2 * last_row + 1>, last_row + 1> rows_{};
    // For (top, left, middle), keep one bit per unused right color.
    std::array<unsigned, 27> available_{};
    // All 81 patterns use each top color 27 times. Rows 0 through 8
    // are exactly the cells that appear as tops, each once.
    std::array<int, 3> remaining_top_{27, 27, 27};
    // Project (top, left, middle, right) to the directed edge
    // (left, middle) -> (middle, right). The full edge set is balanced.
    // A horizontal row contributes a path with just two endpoints.
    std::array<int, 9> balance_{};
    std::uint64_t limit_;
    std::uint64_t found_ = 0;

    template<int row>
    void start_row(int excess) {
        for (int pair = 0; pair < 9 && !limit_reached(); ++pair) {
            // Having added this start, each positive unit needs a future
            // path end. The current row and all remaining rows provide one each.
            int with_start = excess + (balance_[pair] >= 0);
            if (with_start > last_row - row + 1) continue;
            int left = pair / 3;
            int middle = pair % 3;
            if constexpr (row < last_row) {
                if (remaining_top_[left] == 0 ||
                    remaining_top_[middle] <= int(left == middle)) continue;
                --remaining_top_[left];
                --remaining_top_[middle];
            }
            rows_[row][0] = left;
            rows_[row][1] = middle;
            ++balance_[pair];
            fill_row<row>(2, pair, with_start);
            --balance_[pair];
            if constexpr (row < last_row) {
                ++remaining_top_[left];
                ++remaining_top_[middle];
            }
        }
    }

    template<int row>
    void fill_row(int col, int pair, int excess) {
        int top = rows_[row - 1][col - 2];
        unsigned &available = available_[9 * top + pair];
        unsigned choices = available;
        while (choices && !limit_reached()) {
            int color = std::countr_zero(choices); // ascending color order
            choices &= choices - 1;
            if constexpr (row < last_row) {
                if (remaining_top_[color] == 0) continue;
                --remaining_top_[color];
            }
            unsigned bit = 1u << color;
            available ^= bit;
            rows_[row][col] = color;
            int next_pair = 3 * (pair % 3) + color;
            if (col < 2 * row) {
                fill_row<row>(col + 1, next_pair, excess);
            } else {
                int with_end = excess - (balance_[next_pair] > 0);
                if (with_end <= last_row - row) {
                    --balance_[next_pair];
                    if constexpr (row == last_row) emit();
                    else start_row<row + 1>(with_end);
                    ++balance_[next_pair];
                }
            }
            available |= bit;
            if constexpr (row < last_row) ++remaining_top_[color];
        }
    }

    void emit() {
        std::array<char, 100> flat;
        for (int row = 0; row <= last_row; ++row)
            for (int col = 0; col <= 2 * row; ++col)
                flat[row * row + col] = static_cast<char>('0' + rows_[row][col]);
        std::cout.write(flat.data(), flat.size()).put('\n');
        ++found_;
    }
};
} // namespace

int main(int argc, char **argv) {
    if (argc != 3) {
        std::cerr << "Usage: splice_search FLAT_PREFIX LIMIT\n";
        return 2;
    }
    std::string_view prefix(argv[1]), limit_text(argv[2]);
    if (prefix.size() != first_open_row * first_open_row ||
        prefix.find_first_not_of("012") != std::string_view::npos) {
        std::cerr << "FLAT_PREFIX must contain 36 ternary digits (rows 0 through 5).\n";
        return 2;
    }
    std::uint64_t limit = 0;
    const char *end = limit_text.data() + limit_text.size();
    auto parsed = std::from_chars(limit_text.data(), end, limit);
    if (parsed.ec != std::errc{} || parsed.ptr != end) {
        std::cerr << "LIMIT must be a nonnegative integer; 0 requests exhaustive search.\n";
        return 2;
    }
    Search search(limit);
    search.run(prefix);
    if (!std::cout.flush()) {
        std::cerr << "Could not write the boards to standard output.\n";
        return 1;
    }
    std::cerr << search.found() << " boards ("
              << (search.limit_reached() ? "limit reached" : "prefix exhausted") << ")\n";
}
