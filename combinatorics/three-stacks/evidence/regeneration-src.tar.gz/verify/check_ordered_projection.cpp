// Check the files used by the optional fast dual lookup against the original
// prefix and packed continuation masks, rebuilding the projection independently.
#define CARD_COUNT 19
#include "join_tables.hpp"
#include "../coverage/ordered_acceleration.hpp"
int main(int argc, char **argv) {
  if (argc != 3) throw std::runtime_error("usage: check_ordered_projection WORK COLUMNS");
  std::filesystem::path root = argv[1];
  TableFile a((root / "prefix11.bin").c_str(), heads);
  TableFile b((root / "verify-tail19-packed.bin").c_str(), blocks, true);
  ordered_acceleration::ProjectedRows h(root / "ordered19-head16.bin", heads);
  ordered_acceleration::ProjectedRows t(root / "ordered19-tail16.bin", blocks);
  std::ifstream selected(argv[2]); Mask layout{};
  unsigned j, count=0;
  while(count<16 && (selected >> j)) {
    if(j>=columns || (layout[j/64] & (1ull<<(j%64))))throw std::runtime_error("Invalid layout columns");
    layout[j/64]|=1ull<<(j%64);++count;
  }
  if(count!=16)throw std::runtime_error("Invalid layout projection");
  // Four sets of 16-bit extraction tables avoid sharing the production PEXT implementation.
  std::array<std::array<std::vector<uint64_t>,4>, Mask{}.size()> extract;
  unsigned offset=0;
  for(unsigned w=0;w<layout.size();w++)for(unsigned lane=0;lane<4;lane++){
    auto &piece=extract[w][lane];piece.assign(65536,0);
    for(unsigned bit=0;bit<16;bit++)if((layout[w]>>(16*lane+bit))&1){
      for(unsigned i=0;i<65536;i++)if((i>>bit)&1)piece[i]|=(1ull<<offset);
      ++offset;
    }
  }
  auto projection=[&](const Mask& mask){uint64_t result=0;for(unsigned w=0;w<mask.size();++w)
    for(unsigned lane=0;lane<4;++lane)result|=extract[w][lane][(mask[w]>>(16*lane))&65535];return result;};
  quadrant_codes::File<cut> codes((root/"quadrant-codes11.bin").c_str());
  std::array<unsigned,cut> p;std::iota(p.begin(),p.end(),0);Id id=0;
  do {
    unsigned high=0,low=0;
    for(unsigned value=0;value<cut;value++){
      unsigned pos=std::find(p.begin(),p.end(),value)-p.begin();
      unsigned less=0,greater=0;
      for(unsigned a=0;a<pos;a++){less+=p[a]<value;greater+=p[a]>value;}
      low+=less*factorial_of(value);high+=greater*factorial_of(cut-1-value);
    }
    if(high!=codes[id].high || low!=codes[id].low || projection(a[id])!=h[id])
      throw std::runtime_error("Incorrect projected prefix or low/high rank");
    ++id;
  }while(std::next_permutation(p.begin(),p.end()));
  std::vector<uint64_t> dic;
  for(unsigned o=0;o<tail_orders;o++){
    auto first=b.packed.offsets[o], last=b.packed.offsets[o+1];
    dic.resize(last-first);for(unsigned j=0;j<dic.size();j++)dic[j]=projection(b.packed.dictionary[first+j]);
    for(unsigned j=0;j<embeddings;j++){
      auto at=o*embeddings+j;auto k=b.packed.ids[at];
      if(k>=dic.size() || dic[k]!=t[at])throw std::runtime_error("Incorrect projected suffix row");
    }
  }
  std::cout<<"Verified "<<id<<" prefix projections and factorial codes, "<<blocks<<" suffix projections\n";
}
