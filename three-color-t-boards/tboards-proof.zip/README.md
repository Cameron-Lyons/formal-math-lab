# More than 60 three-color T boards

**Yes: there are at least 72 distinct labeled boards.** The six seeds in
`BoardData.lean`, together with all six global color permutations and horizontal
reflection, give 72 boards. Lean checks each board and that all 72 are different.
This is a lower bound, not a determination of the exact total.

The new seed is below; `0 = red`, `1 = green`, `2 = blue`.

```text
         0
        000
       00100
      0020110
     012021022
    10110211112
   0201212122210
  221120011002202
 12202121112222101
1012000010020102200
```

It agrees with the first published seed on rows 0 through 5. A deterministic
depth-first search found this different completion after 606,030,673 nodes.
Its 12 color-permutation/reflection images are distinct and disjoint from the
60 published boards. An independent Cartesian-coordinate checker confirms
that every one of the 72 boards realizes each ordered T pattern exactly once.

## Lean verification

With elan installed, run from this directory:

```sh
lake build
```

The pinned toolchain is Lean 4.36.0. There are no external Lean dependencies;
the proof uses only `Std`. The finite checks use kernel-reduced `by decide +kernel`,
not `native_decide`. No `sorry`, search-correctness assumption, or solver axiom
is used. The build prints the axioms of the three principal results.

The completed build checked `Certificates.lean` in approximately 46 seconds.
`at_least_72` and `more_than_60` depend only on the standard Lean axioms
`propext` and `Quot.sound`; `new_board_exists` also lists `Classical.choice`.
The successful output is saved in `lean-build.log`.

- `TBoards.at_least_72`: an injective map from `Fin 72` to valid boards.
- `TBoards.more_than_60`: a duplicate-free list of more than 60 valid boards.
- `TBoards.new_board_exists`: a valid board absent from the published 60.

`TBoards.lean` defines the geometry and validity. In zero-based row `r`, entry
`j` has horizontal coordinate `j-r`. For upper row `r < 9` and `j < 2*r+1`,
the T reads `(r,j)`, `(r+1,j)`, `(r+1,j+1)`, `(r+1,j+2)` in the order
**top, left, middle, right**. Its top and middle have the same horizontal
coordinate. The model proves there are exactly 81 distinct placements, their
indices are in bounds, and validity implies a unique geometric placement for
each of the 81 ordered color quadruples. Row lengths and palette membership
are part of the proved validity condition.

`BoardData.lean` stores the six seeds and explicitly defines their symmetry
images. `Certificates.lean` checks validity, novelty, and distinctness and
proves the lower-bound statements. Its checks cover every transformed board;
the proof does not rely on an unproved symmetry claim.

## Independent checks and data

```sh
python verify_certificate.py
python sources/anc/verify.py
```

- `prefix_result.json`: new seed and discovery node count.
- `family.json`: all 72 certified boards, in the same order as the Lean family.
- `novel_patterns.csv`: all 81 patterns and their placements in the new board.
- `prepare_certificates.py`: regenerates the Lean data, family JSON, and CSV
  from the published certificates and new seed. The generator is not trusted
  by Lean; Lean checks the resulting explicit data.

To repeat the optional discovery search (requires `g++`):

```sh
python reproduce_search.py --seconds 120
```

The search is restricted to the first published seed's first six rows. A
timeout is not a nonexistence result. Search speed depends on the machine.
Discovery is unnecessary for verifying the proof.

## Source and attribution

The original five seeds and downloaded files in `sources/` come from Qiyuan
Ma, *Explicit Three- and Four-Color Prismatic T-Tetrominoes*, version 1.0,
25 October 2026, [DOI 10.5281/zenodo.23631079](https://doi.org/10.5281/zenodo.23631079).
The downloaded archive's MD5 matches the published value
`75f7fc208678c82d0269fa453942a80b`; all its internal SHA-256 checksums passed.

The source manuscript and certificate data are CC-BY-4.0; the source Python
programs are MIT licensed. Original notices and full licenses are preserved
under `sources/`. The first five seeds in `BoardData.lean` and their images
in `family.json` are adapted from that certificate data. The sixth seed and
its symmetry images were generated in this workspace. The new C++ discovery
program and Lean formalization were written for this task.
