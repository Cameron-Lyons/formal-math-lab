// Fixed stratified samples for all 7! suffix orders at lengths 19 and 20. No
// deck is eliminated from an exhaustive search by this profiling program.
#ifndef CARD_COUNT
#define CARD_COUNT 19
#endif
#include "../verify/join_tables.hpp"
#include "tail.hpp"
#include <iomanip>
static_assert((n == 19 || n == 20) && n == cut + 8 && ordinary == 7);
namespace profile {
constexpr unsigned H = 2048, S = 128, T = 192, per_level = 24;
using Word = std::array<unsigned char, n>;
struct SampleHead {
  Mask mask;
  Word word{};
  unsigned bonds = 0, maxpos = 0;
  int first_limit = -1;
  std::array<signed char, cut + 1> second_limit;
};
struct Values {
  std::array<unsigned char, cut> front;
  std::array<unsigned char, ordinary> back, below;
  std::array<unsigned, ordinary> bond;
  unsigned suffix_bonds;
  bool high;
};
struct Node {
  unsigned first, last, children, weight;
  std::array<unsigned, ordinary> common_bonds;
  std::array<unsigned char, cut> min_high, min_low;
};
struct Geometry {
  std::vector<unsigned> active;
  std::vector<Node> probes;
};
struct Counts {
  uint64_t misses = 0, no_bond = 0, canonical = 0, eligible_head = 0,
           first_cut = 0, second_cut = 0, union_cut = 0, remaining = 0,
           all_one = 0, all_two = 0, all_union = 0;
};
Word append(const Word &w, unsigned length, unsigned rank) {
  Word result{};
  for (unsigned i = 0; i < length; ++i)
    result[i] = w[i] + (w[i] >= rank);
  result[length] = rank;
  return result;
}
// If a last card of insertion rank q can be delivered in decreasing order,
// delay its input. Promote the old rank q-1 to q and send the delayed card
// straight through just after it. Every smaller insertion rank also works.
int threshold(const Word &w, unsigned length) {
  layout::Shape empty;
  int last = -1;
  for (unsigned rank = 0; rank <= length; rank++) {
    auto a = append(w, length, rank);
    layout::Prepare test{a.data(), int(length + 1), empty};
    if (test.test()) {
      if (last + 1 != int(rank))
        throw std::logic_error("Nonmonotone insertion");
      last = rank;
    }
  }
  return last;
}
Word unrank(unsigned id) {
  Word w{};
  unsigned left = (1u << cut) - 1, ways = heads;
  for (unsigned i = 0; i < cut; ++i) {
    ways /= cut - i;
    unsigned skip = id / ways;
    id %= ways;
    unsigned avail = left;
    while (skip--)
      avail &= avail - 1;
    w[i] = std::countr_zero(avail);
    left ^= 1u << w[i];
  }
  return w;
}
std::vector<SampleHead> sample_heads(const TableFile *table,
                                     std::mt19937 &rng) {
  std::vector<SampleHead> h(H);
  layout::Shape empty;
  const auto shapes = layout::layouts(cut);
  for (unsigned i = 0; i < H; ++i) {
    unsigned lo = uint64_t(i) * heads / H, hi = uint64_t(i + 1) * heads / H,
             id = lo + rng() % (hi - lo);
    auto &x = h[i];
    x.word = unrank(id);
    if (table)
      x.mask = (*table)[id];
    else {
      x.mask = {};
      for (unsigned j = 0; j < shapes.size(); j++) {
        layout::Prepare prep{x.word.data(), int(cut), shapes[j]};
        if (prep.test())
          x.mask[j / 64] |= 1ull << (j % 64);
      }
    }
    x.second_limit.fill(-1);
    for (unsigned j = 0; j < cut; ++j) {
      if (x.word[j] == cut - 1)
        x.maxpos = j;
      if (j && x.word[j - 1] == x.word[j] + 1)
        x.bonds |= 1u << x.word[j];
    }
    x.bonds |= 1u << (cut - 1 + x.word[cut - 1]);
    layout::Prepare test{x.word.data(), int(cut), empty};
    if (bool(x.mask[0] & 1) != test.test())
      throw std::logic_error("Empty layout mismatch");
    if (x.mask[0] & 1) {
      x.first_limit = threshold(x.word, cut);
      for (int r = 0; r <= x.first_limit; r++)
        x.second_limit[r] = threshold(append(x.word, cut, r), cut + 1);
    }
  }
  return h;
}
std::vector<Values> values() {
  std::vector<Values> all;
  for (unsigned s = 0; s < (1u << (n - 1)); ++s)
    if (std::popcount(s) == ordinary) {
      Values v{};
      int i = 0, j = 0;
      for (int x = 1; x < int(n); ++x) {
        if (s & (1u << (x - 1))) {
          v.below[j] = i;
          v.back[j++] = x;
        } else
          v.front[i++] = x;
      }
      unsigned consecutive = 0;
      for (unsigned r = 0; r + 1 < cut; r++)
        if (v.front[r] + 1 == v.front[r + 1])
          consecutive |= 1u << r;
      for (unsigned r = 0; r < ordinary; r++) {
        auto x = v.back[r];
        v.bond[r] = consecutive;
        if (x < n - 1 && !(s & (1u << x)))
          v.bond[r] |= 1u << (cut - 1 + v.below[r]);
      }
      for (unsigned r = 0; r + 1 < ordinary; ++r)
        if (v.back[r] + 1 == v.back[r + 1])
          v.suffix_bonds |= 1u << r;
      if (v.back[0] == 1)
        v.suffix_bonds |= 1u << (ordinary - 1);
      v.high = v.back.back() == n - 1;
      all.push_back(v);
    }
  if (all.size() != embeddings)
    throw std::logic_error("Missing embeddings");
  return all;
}
unsigned bond_key(const Tail &p) {
  unsigned key = p.back() == 0 ? 1u << (ordinary - 1) : 0;
  for (unsigned i = 1; i < ordinary; ++i)
    if (p[i - 1] == p[i] + 1)
      key |= 1u << p[i];
  return key;
}
using Span = std::array<unsigned, 3>;
void split(unsigned lo, unsigned hi, unsigned depth,
           std::vector<std::vector<Span>> &levels) {
  if (hi - lo <= 1)
    return;
  unsigned chunk = (hi - lo + 3) / 4, arity = 1 + (hi - lo - 1) / chunk;
  if (levels.size() <= depth)
    levels.resize(depth + 1);
  levels[depth].push_back({lo, hi, arity});
  for (unsigned q = lo; q < hi; q += chunk)
    split(q, std::min(q + chunk, hi), depth + 1, levels);
}
Geometry geometry(unsigned tag, const std::vector<Values> &sets) {
  Geometry result;
  for (unsigned i = 0; i < sets.size(); ++i)
    if (!(sets[i].suffix_bonds & tag))
      result.active.push_back(i);
  std::vector<std::vector<Span>> levels;
  split(0, result.active.size(), 0, levels);
  std::mt19937 rng(9001 + tag);
  for (const auto &level : levels) {
    unsigned nodes = level.size(), cap = std::min(nodes, per_level);
    for (unsigned j = 0; j < cap; ++j) {
      unsigned a = j * nodes / cap, b = (j + 1) * nodes / cap;
      auto [lo, hi, children] = level[a + rng() % (b - a)];
      Node u{lo, hi, children, b - a};
      u.common_bonds.fill(~0u);
      u.min_high.fill(31);
      u.min_low.fill(31);
      for (unsigned k = lo; k < hi; k++) {
        auto &v = sets[result.active[k]];
        auto &m = v.high ? u.min_high : u.min_low;
        for (unsigned r = 0; r < cut; r++)
          m[r] = std::min(m[r], v.front[r]);
        for (unsigned r = 0; r < ordinary; r++)
          u.common_bonds[r] &= v.bond[r];
      }
      result.probes.push_back(u);
    }
  }
  return result;
}
bool hit(const Mask &a, const Mask &b) {
  for (unsigned w = 0; w < a.size(); ++w)
    if (a[w] & b[w])
      return true;
  return false;
}
double tree_cost(const Geometry &g, const std::vector<SampleHead> &h,
                 const TableFile &table, Id base, unsigned first,
                 unsigned max_pos) {
  uint64_t visits = T;
  for (const auto &u : g.probes) {
    Mask common = table[base + g.active[u.first]];
    for (unsigned z = u.first + 1; z < u.last; ++z) {
      auto &m = table[base + g.active[z]];
      uint64_t total = 0;
      for (unsigned w = 0; w < m.size(); w++) {
        common[w] &= m[w];
        total |= common[w];
      }
      if (!total)
        break;
    }
    unsigned waiting = 0;
    for (unsigned t = 0; t < T; t++) {
      const auto &x = h[uint64_t(t) * H / T];
      unsigned r = x.word.front();
      if ((x.bonds & u.common_bonds[first]) ||
          (u.min_high[r] + max_pos > n - 1 &&
           u.min_low[r] + x.maxpos > n - 1) ||
          hit(x.mask, common))
        continue;
      ++waiting;
    }
    visits += uint64_t(waiting) * u.children * u.weight;
  }
  return double(visits) / T;
}
bool suffix_direct(const Tail &p, unsigned drop) {
  std::array<int, ordinary> w{};
  for (unsigned i = drop; i < ordinary; ++i)
    for (unsigned j = drop; j < ordinary; ++j)
      w[i - drop] += p[j] < p[i];
  return tail::detail::solve(w.data(), ordinary - drop, tail::empty, -1, -1);
}
bool canonical(const SampleHead &x, const Values &v, const Tail &tau,
               unsigned max_pos) {
  unsigned left = v.front[x.word.front()],
           right = n - 1 - (v.high ? max_pos : x.maxpos);
  if (left != right)
    return left < right;
  Deck p{}, d{};
  for (unsigned i = 0; i < cut; ++i)
    p[i] = v.front[x.word[i]];
  for (unsigned i = 0; i < ordinary; i++)
    p[cut + i] = v.back[tau[i]];
  for (unsigned i = 0; i < n; ++i)
    d[n - 1 - p[i]] = n - 1 - i;
  return p <= d;
}
} // namespace profile
#ifndef HARDNESS_PROFILE_LIBRARY
int main(int argc, char **argv) {
  using namespace profile;
  if (argc != 3)
    throw std::runtime_error("hardness_profile PREFIX TAIL");
  std::unique_ptr<TableFile> head;
  if (std::string(argv[1]) != "-")
    head = std::make_unique<TableFile>(argv[1], heads);
  TableFile tailfile(argv[2], blocks, true);
  Coding codec(nullptr);
  std::mt19937 rng(351119);
  auto h = sample_heads(head.get(), rng);
  auto sets = values();
  std::vector<unsigned> sample;
  for (unsigned s = 0; s < S; s++) {
    unsigned lo = s * embeddings / S, hi = (s + 1) * embeddings / S;
    sample.push_back(lo + rng() % (hi - lo));
  }
  std::array<std::unique_ptr<Geometry>, 128> trees;
  std::cout
      << "rank,active_sets,sample_pairs,first_misses,unbonded,canonical,empty"
      << cut << ",cut" << cut + 1 << ",cut" << cut + 2
      << ",union_later,remaining,tail" << cut + 1 << ",tail" << cut + 2
      << ",tree_per_head,unbonded_cut1,unbonded_cut2,unbonded_union\n";
  for (unsigned t = 0; t < tail_orders; t++) {
    const auto &tau = codec.orders[t];
    bool first_tail = suffix_direct(tau, 1),
         second_tail = suffix_direct(tau, 2);
    // All six-card terminal-zero suffixes pass. A further zero-park cut cannot
    // add a deck: deleting that extra prefix input yields the two-card
    // extension.
    if (!second_tail)
      throw std::logic_error("Found a six-card suffix requiring three stacks");
    unsigned tag = bond_key(tau),
             maxpos = cut + (std::find(tau.begin(), tau.end(), ordinary - 1) -
                             tau.begin());
    auto &g = trees[tag];
    if (!g)
      g = std::make_unique<Geometry>(geometry(tag, sets));
    unsigned base = t * embeddings;
    Counts c;
    for (unsigned s : sample) {
      auto &v = sets[s];
      const auto &m = tailfile[base + s];
      unsigned rx = v.below[tau[0]], ry = v.below[tau[1]] + (tau[0] < tau[1]);
      bool suffix_bond = v.suffix_bonds & tag;
      unsigned bonds = v.bond[tau[0]];
      for (const auto &x : h) {
        if (hit(x.mask, m))
          continue;
        ++c.misses;
        if (suffix_bond || (x.bonds & bonds))
          continue;
        ++c.no_bond;
        bool a = first_tail && int(rx) <= x.first_limit,
             b = second_tail && int(ry) <= x.second_limit[rx];
        c.all_one += a;
        c.all_two += b;
        c.all_union += a || b;
        if (!canonical(x, v, tau, maxpos))
          continue;
        ++c.canonical;
        if (x.mask[0] & 1)
          ++c.eligible_head;
        c.first_cut += a;
        c.second_cut += b;
        c.union_cut += a || b;
        c.remaining += !(a || b);
      }
    }
    double estimate = tree_cost(*g, h, tailfile, base, tau[0], maxpos);
    std::cout << t << ',' << g->active.size() << ',' << H * S << ',' << c.misses
              << ',' << c.no_bond << ',' << c.canonical << ','
              << c.eligible_head << ',' << c.first_cut << ',' << c.second_cut
              << ',' << c.union_cut << ',' << c.remaining << ',' << first_tail
              << ',' << second_tail << ',' << std::setprecision(9) << estimate
              << ',' << c.all_one << ',' << c.all_two << ',' << c.all_union
              << '\n';
  }
}
#endif
