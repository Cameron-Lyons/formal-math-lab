#include "../coverage/quadrant_codes.hpp"
#include <algorithm>
#include <chrono>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>
#include <vector>

template <int N, int K> struct Sample {
  static constexpr int M = N - K - 1;
  using Word = std::array<unsigned char, K>;
  std::array<int, K> labels{};
  std::array<int, M + 1> suffix{};
  Sample(std::mt19937 &gen, int d) {
    std::array<int, M> lows;
    std::array<int, K> highs;
    std::iota(lows.begin(), lows.end(), 1);
    std::iota(highs.begin(), highs.end(), M + 1);
    std::shuffle(lows.begin(), lows.end(), gen);
    std::shuffle(highs.begin(), highs.end(), gen);
    std::copy_n(lows.begin(), d, labels.begin());
    std::copy_n(highs.begin(), K - d, labels.begin() + d);
    std::sort(labels.begin(), labels.end());
    std::copy(lows.begin() + d, lows.end(), suffix.begin());
    std::copy(highs.begin() + K - d, highs.end(), suffix.begin() + M - d);
    std::shuffle(suffix.begin(), suffix.begin() + M, gen);
  }
  using Baseline = quadrant::Encoder<N, K>;
  typename Baseline::Key direct(const Word &word) const {
    std::array<int, N> p{}, q{};
    for (int i = 0; i < K; i++)
      p[i] = labels[word[i]];
    std::copy(suffix.begin(), suffix.end(), p.begin() + K);
    for (int i = 0; i < N; i++)
      q[N - 1 - p[i]] = N - 1 - i;
    unsigned head = 0, order = 0, set = 0;
    for (int i = 0; i < K; i++) {
      int smaller = 0;
      for (int j = i + 1; j < K; j++)
        smaller += (q[j] < q[i]);
      head = head * (K - i) + smaller;
    }
    for (int j = 0; j < M; j++) {
      unsigned bigger = 0;
      for (int i = 0; i < j; i++)
        bigger += q[K + i] > q[K + j];
      order = order * (j + 1) + bigger;
      set |= 1u << (q[K + j] - 1);
    }
    return {head, order, set};
  }
};

template <int N, int K> void check() {
  using S = Sample<N, K>;
  using Word = typename S::Word;
  using Tables = quadrant_codes::Tables<N, K>;
  Tables tables;
  std::mt19937 gen(614 + N);
  Word w;
  std::iota(w.begin(), w.end(), 0);
  auto same = [](auto a, auto b) {
    return a.head == b.head && a.order == b.order && a.set == b.set;
  };
  unsigned long count = 0;
  for (int d = 0; d <= S::M; d++) {
    for (int i = 0; i < 32; i++) {
      S s(gen, d);
      typename Tables::Block block(tables, s.labels.data(), s.suffix.data());
      for (int j = 0; j < 512; j++) {
        std::shuffle(w.begin(), w.end(), gen);
        auto code = quadrant_codes::encode_prefix<K>(w.data());
        auto q = s.direct(w), b = block.baseline.key(w.data()),
             z = block.key(code, w.data());
        if (!same(b, q) || !same(z, q)) {
          std::cerr << "N=" << N << " K=" << K << " d=" << d << " expected "
                    << q.head << ' ' << q.order << ' ' << q.set << " base "
                    << b.head << ' ' << b.order << ' ' << b.set << " actual "
                    << z.head << ' ' << z.order << ' ' << z.set << '\n';
          throw std::runtime_error("dual-address comparison failed");
        }
        ++count;
      }
    }
  }
  if constexpr (N <= 9) {
    S geometry(gen, 0);
    std::array<int, N - 1> deck;
    std::iota(deck.begin(), deck.end(), 1);
    unsigned exhaustive = 0;
    do {
      std::copy_n(deck.begin(), K, geometry.labels.begin());
      std::sort(geometry.labels.begin(), geometry.labels.end());
      std::copy(deck.begin() + K, deck.end(), geometry.suffix.begin());
      for (int i = 0; i < K; i++)
        w[i] = std::lower_bound(geometry.labels.begin(), geometry.labels.end(),
                                deck[i]) -
               geometry.labels.begin();
      typename Tables::Block block(tables, geometry.labels.data(),
                                   geometry.suffix.data());
      auto q = geometry.direct(w);
      if (!same(block.key(quadrant_codes::encode_prefix<K>(w.data()), w.data()),
                q) ||
          !same(block.baseline.key(w.data()), q))
        throw std::runtime_error("exhaustive dual-address check failed");
      ++exhaustive;
    } while (std::next_permutation(deck.begin(), deck.end()));
    std::cout << "n=" << N << " exhaustive end-in-minimum comparisons "
              << exhaustive << '\n';
  }
  // The threshold-mask gather uses different word widths on the fast path.
  for (unsigned subset = 0; subset < (1u << K); ++subset) {
    for (int i = 0; i < K; i++)
      w[i] = ((subset >> (K - 1 - i)) & 1) ? 0 : 1;
    if (quadrant_codes::low_positions<K>(w.data(), 1) != subset)
      throw std::runtime_error("byte gather failure");
  }
  std::cout << "n=" << N << " k=" << K << " triple comparisons " << count
            << " threshold masks " << (1u << K) << std::endl;
  if constexpr (K < 10)
    return;
  constexpr int words = 2048, blocks = 1024;
  std::vector<Word> words_pool(words);
  std::vector<quadrant_codes::Prefix> codes;
  std::iota(w.begin(), w.end(), 0);
  for (auto &p : words_pool) {
    std::shuffle(w.begin(), w.end(), gen);
    p = w;
    codes.push_back(quadrant_codes::encode_prefix<K>(w.data()));
  }
  std::vector<S> geometries;
  for (int i = 0; i < blocks; i++) {
    std::array<int, N - 1> deck;
    std::iota(deck.begin(), deck.end(), 1);
    std::shuffle(deck.begin(), deck.end(), gen);
    int d = std::count_if(deck.begin(), deck.begin() + K,
                          [](int x) { return x <= S::M; });
    geometries.emplace_back(gen, d);
  }
  auto time = [&](auto body) {
    auto t = std::chrono::steady_clock::now();
    std::uint64_t digest = 0;
    for (auto &g : geometries) {
      typename Tables::Block b(tables, g.labels.data(), g.suffix.data());
      for (unsigned i = 0; i < words_pool.size(); i++) {
        auto z = body(b, g, i);
        digest += std::uint64_t(z.head) * 520000009 + z.order * 13 + z.set;
      }
    }
    auto elapsed =
        std::chrono::duration<double>(std::chrono::steady_clock::now() - t)
            .count();
    std::cout << elapsed * 1e9 / (words * blocks) << " ns/query, checksum "
              << digest << std::endl;
    return digest;
  };
  std::cout << "reconstruct ";
  auto a =
      time([&](auto &, auto &g, int i) { return g.direct(words_pool[i]); });
  std::cout << "quadrant ";
  auto b = time([&](auto &b, auto &, int i) {
    return b.baseline.key(words_pool[i].data());
  });
  std::cout << "factorial codes ";
  auto c = time([&](auto &b, auto &, int i) {
    return b.key(codes[i], words_pool[i].data());
  });
  if (a != b || b != c)
    throw std::runtime_error("benchmark checksum failure");
}
int main() {
  check<9, 5>();
  check<19, 11>();
  check<20, 12>();
}
