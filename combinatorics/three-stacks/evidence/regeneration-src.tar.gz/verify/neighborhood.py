"""Exhaustive search within four changed positions of a published one-card deletion.

Install python-sat first. Use --first and --last to partition deletion positions.
The search tests each permutation once per deletion, irrespective of coincidences
between different deletions. Positive counts rely on a SAT model for each
new first intermediate order and a deterministic one-stack test for cache hits.
"""

from argparse import ArgumentParser
from itertools import combinations, permutations
from time import monotonic
from collections import deque

from pysat.solvers import Solver
from check import check, encode, operation_word, pair_table, replay, unpack

from replay import PANTONE_VATTER


class VariableInput:
    def __init__(self, n):
        cards = range(1, n + 1)
        # Pair variables for the varying input follow those for both stack exits.
        # Every query fixes all comparison signs for this input order.
        self.input = pair_table(cards, n * (n - 1))
        self.first, self.second, clauses = encode(cards, self.input)
        self.solver = Solver(name="cadical195", bootstrap_with=clauses)
        self.cached = deque(maxlen=3)

    def solve(self, deck):
        for order in self.cached:
            # On input deck, execute the canonical greedy one-stack algorithm
            # targeting 'order'. Any success gives an existing downstream run.
            stack = []
            pos = 0
            for card in deck:
                stack.append(card)
                while stack and stack[-1] == order[pos]:
                    stack.pop()
                    pos += 1
            if not stack:
                return True
        assumptions = [self.input[a, b] for a, b in combinations(deck, 2)]
        if not self.solver.solve(assumptions=assumptions):
            return False
        model = set(self.solver.get_model())
        first = unpack(deck, self.first, model)
        second = unpack(deck, self.second, model)
        # Validate the entire run before caching one of its intermediate orders.
        if not replay(deck, operation_word(deck, [first, second, sorted(deck)])):
            raise AssertionError("SAT witness failed direct stack replay")
        self.cached.appendleft(first)
        return True


def variants(deck, radius):
    yield tuple(deck)
    for size in range(2, radius + 1):
        shifts = [
            perm
            for perm in permutations(range(size))
            if all(i != source for i, source in enumerate(perm))
        ]
        for chosen in combinations(range(len(deck)), size):
            for shift in shifts:
                result = deck[:]
                for i, source in enumerate(shift):
                    result[chosen[i]] = deck[chosen[source]]
                yield tuple(result)


def main():
    p = ArgumentParser(description=__doc__)
    p.add_argument("--first", type=int, default=1)
    p.add_argument("--last", type=int, default=len(PANTONE_VATTER))
    p.add_argument("--radius", type=int, default=4)
    args = p.parse_args()
    eng = VariableInput(20)
    for k in range(args.first - 1, args.last):
        start = monotonic()
        missing = PANTONE_VATTER[k]
        deck = [x - (x > missing) for x in PANTONE_VATTER if x != missing]
        count = 0
        for candidate in variants(deck, args.radius):
            count += 1
            if not eng.solve(candidate):
                assert check(candidate, "verify/candidate") is None
                print("UNSORTABLE", *candidate, flush=True)
                return
        print(
            f"Deleted {missing}, checked {count}, all sortable, {monotonic() - start:.2f}s",
            flush=True,
        )


if __name__ == "__main__":
    main()
