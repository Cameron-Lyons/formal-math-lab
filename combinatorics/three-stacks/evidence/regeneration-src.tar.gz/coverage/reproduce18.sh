#!/usr/bin/env bash
# Run from the workspace root. python-sat is required only for fresh words.
set -euo pipefail
if [[ $# != 1 ]]; then
  echo 'Usage: coverage/reproduce18.sh work-directory' >&2
  exit 2
fi
work=$1
mkdir -p "$work"
cxx=(g++ -O3 -march=native -std=c++20)
for k in 8 9 10; do
  "${cxx[@]}" -DDECK_CUT=$k coverage/build_prefix_canonical.cpp -o "$work/prefix$k"
  "$work/prefix$k" "$work/prefix$k.bin"
done
for k in 8 9; do
  "${cxx[@]}" -DDECK_CUT=$k coverage/recut.cpp -o "$work/recut$k"
done
"${cxx[@]}" -DDECK_SIZE=18 coverage/build_tail.cpp -o "$work/tail"
"$work/tail" "$work/tail18.bin" 1800
"${cxx[@]}" -DDECK_SIZE=18 coverage/join.cpp -o "$work/project"
"${cxx[@]}" -DCARD_COUNT=18 verify/join_audit.cpp -o "$work/include"
"$work/include" --build-index "$work/prefix10.bin" "$work/index10.bin"
"${cxx[@]}" coverage/group_residuals.cpp -o "$work/group"
"${cxx[@]}" coverage/check_residual_stream.cpp -o "$work/check-residuals"
for part in 0 1 2a 3a 2b 3b; do
  read -r first stop stride mode < "coverage/results/n18-$part/range.txt"
  result="$work/n18-$part"
  mkdir -p "$result"
  cp "coverage/results/n18-$part/range.txt" "$result/range.txt"
  if [[ $mode == canonical ]]; then
    "$work/include" "$work/prefix10.bin" "$work/tail18.bin" "$result/raw.txt" "$first" "$stop" "$stride" 8 "$work/index10.bin" canonical > "$result/join.txt" 2> "$result/progress.log"
    "$work/group" 18 10 < "$result/raw.txt" > "$result/remaining.txt"
  else
    "$work/project" "$work/prefix10.bin" "$work/tail18.bin" "$first" "$stop" "$stride" > "$result/remaining.txt" 2> "$result/progress.log"
    tail -n 1 "$result/progress.log" > "$result/join.txt"
  fi
  gzip -n -c "$result/progress.log" > "$result/progress.txt.gz"
  "$work/check-residuals" "$result/remaining.txt" "$first" "$stop" "$stride" "$mode" | gzip -n > "$result/residual-counts.txt.gz"
  coverage/close_shard.sh 18 10 "$result/remaining.txt" "$result" "$work/recut9" "$work/prefix9.bin" "$work/recut8" "$work/prefix8.bin"
done
python coverage/audit18.py "$work" | tee "$work/n18-audit.txt"
