#pragma once
#include "dimensions.hpp"
#include "gaps.hpp"
#include <memory>

// The last card of a k-card prefix becomes the first card of its (k-1)-cut
// tail. For one original tail value set/order, only k such extended tails are
// possible. Each gets a mask of available continuations, learned lazily and
// shared by every prefix ending at that same rank.
namespace earlier {
constexpr int k = prefix::size - 1;
constexpr int layouts_count = 1 + 2 * k + 3 * k * (k - 1);
using Mask = std::array<std::uint64_t, (layouts_count + 63) / 64>;
inline unsigned prefix_rank(const std::array<int, prefix::size> &word) {
  unsigned left = ((1U << prefix::size) - 1) ^ (1U << word.back());
  unsigned rank = 0;
  for (int i = 0; i < k; ++i) {
    rank = rank * (k - i) + std::popcount(left & ((1U << word[i]) - 1));
    left ^= 1U << word[i];
  }
  return rank;
}
class Filter {
  struct Offers {
    std::unique_ptr<gap::Embedding> embedding;
    gap::Table *cache = nullptr;
    Mask checked{}, good{};
  };
  int budget;
  std::vector<Mask> prefix_masks;
  std::vector<layout::Shape> layouts = layout::layouts(k);
  std::array<std::unique_ptr<gap::Table>, dimensions::ordinary + 1> caches;
  std::array<Offers, prefix::size> choices;
  std::array<int, prefix::size> values{};
  std::array<int, dimensions::ordinary + 1> extended{};
  unsigned original_suffix = 0;

public:
  explicit Filter(const std::string &filename, int budget)
      : budget(budget), prefix_masks(dimensions::factorial(k)) {
    std::ifstream file(filename, std::ios::binary | std::ios::ate);
    auto bytes = sizeof(Mask) * prefix_masks.size();
    if (!file || file.tellg() != static_cast<std::streamoff>(bytes))
      throw std::runtime_error(
          "Missing or incomplete earlier-cut prefix table");
    file.seekg(0);
    file.read(reinterpret_cast<char *>(prefix_masks.data()), bytes);
    if (!file)
      throw std::runtime_error("Failed to read earlier-cut prefix table");
  }
  void new_order() {
    for (auto &c : caches)
      c.reset();
  }
  void new_block(const int *suffix,
                 const std::array<int, prefix::size> &prefix_values) {
    for (auto &o : choices)
      o = Offers{};
    values = prefix_values;
    original_suffix = 0;
    for (int i = 0; i < dimensions::ordinary; ++i) {
      extended[i + 1] = suffix[i];
      original_suffix |= 1U << suffix[i];
    }
  }
  bool accepts(unsigned rank, int final_rank) {
    auto &offer = choices[final_rank];
    if (!offer.embedding) {
      int value = values[final_rank];
      int order_slot = std::popcount(original_suffix & ((1U << value) - 1));
      auto &cache = caches[order_slot];
      if (!cache) {
        cache = std::make_unique<gap::Table>(k, dimensions::n, budget);
        extended[0] = value;
        cache->reset(extended.data());
      }
      offer.cache = cache.get();
      offer.embedding = std::make_unique<gap::Embedding>(
          k, dimensions::n, original_suffix | (1U << value));
    }
    const auto &head = prefix_masks[rank];
    for (unsigned w = 0; w < head.size(); ++w)
      if (head[w] & offer.good[w])
        return true;
    for (unsigned w = 0; w < head.size(); ++w) {
      auto todo = head[w] & ~offer.checked[w];
      for (; todo; todo &= todo - 1) {
        unsigned id = 64 * w + std::countr_zero(todo);
        auto bit = todo & -todo;
        offer.checked[w] |= bit;
        if (offer.cache->test(*offer.embedding, layouts[id])) {
          offer.good[w] |= bit;
          return true;
        }
      }
    }
    return false;
  }
};
} // namespace earlier
