// Aggregate the packed n19 continuation rows. Independently re-enumerate
// every fibre and verify the exact bitwise meet against the original raw rows.
#ifndef CARD_COUNT
#define CARD_COUNT 19
#endif
#include "../coverage/tail_fiber.hpp"
#include "join_tables.hpp"
#include "stream_tail.hpp"
#include <filesystem>
namespace fs = std::filesystem;
using namespace tail_fiber;
static_assert(n == 19 && cut == 11 && ordinary == m);
using Groups = std::vector<Mask>;
Groups blank(unsigned width) {
  Mask full;
  full.fill(~0ULL);
  return Groups(groups * width, full);
}
template <class T>
void write_new(const fs::path &path, const T *p, size_t rows) {
  auto tmp = path.string() + ".tmp." + std::to_string(getpid());
  try {
    std::ofstream f(tmp, std::ios::binary);
    if (!f.write(reinterpret_cast<const char *>(p), rows * sizeof(T)))
      throw std::runtime_error("Writing fibre output failed");
    f.close();
    if (!f || link(tmp.c_str(), path.c_str()))
      throw std::runtime_error("Choose a fresh fibre output path");
    fs::remove(tmp);
  } catch (...) {
    fs::remove(tmp);
    throw;
  }
}
inline void meet(Mask &target, const Mask &row) {
  for (unsigned w = 0; w < target.size(); w++)
    target[w] &= row[w];
}
void reflection(const fs::path &dir) {
  Lookup keys;
  Coding codes(nullptr);
  std::vector<Id> reflect(groups);
  for (unsigned g = 0; g < groups; g++) {
    if (group_of_positions(positions_of_group(g)) != g)
      throw std::logic_error("Group encoding is not invertible");
    reflect[g] = reflected_group(g);
  }
  for (unsigned g = 0; g < groups; g++)
    if (reflect[reflect[g]] != g)
      throw std::logic_error("Group reflection is not involutive");
  std::vector<std::array<Id, subsets>> direct(orders);
  std::uint64_t checks = 0;
  for (unsigned order = 0; order < orders; order++)
    for (unsigned s = 0; s < subsets; s++) {
      Id g = direct[order][s] = reflect[keys.id(order, s)];
      unsigned nlarge = m - std::popcount(s);
      for (unsigned test = 0; test < 2; test++) {
        unsigned large = ((1u << nlarge) - 1) << (test ? 18 - nlarge : 7);
        auto set = codes.set_id[s | large];
        const auto &e = codes.labels[set];
        Deck p{}, dual{};
        for (unsigned i = 0; i < cut; i++)
          p[i] = e.front[test ? cut - 1 - i : i];
        for (unsigned i = 0; i < m; i++)
          p[cut + i] = e.back[codes.orders[order][i]];
        for (unsigned i = 0; i < n; i++)
          dual[n - 1 - p[i]] = n - 1 - i;
        auto [dh, db] = codes.encode(dual);
        (void)dh;
        unsigned actual_set = 0;
        for (unsigned i = cut; i < n - 1; i++)
          actual_set |= 1u << (dual[i] - 1);
        if (keys.id(db / embeddings, actual_set) != g)
          throw std::logic_error(
              "Directly reconstructed dual disagrees with reflection");
        ++checks;
      }
    }
  write_new(dir / "reflected-group.u32", reflect.data(), reflect.size());
  write_new(dir / "dual-group-by-source-order-smallset.u32", direct.data(),
            direct.size());
  std::cout << "Verified all " << groups << " reflected group IDs and "
            << checks << " independent complete-deck dual computations.\n";
}
int main(int argc, char **argv) {
  if (argc == 3 && std::string(argv[1]) == "--reflect") {
    reflection(argv[2]);
    return 0;
  }
  if (argc != 4 && (argc != 5 || std::string(argv[4]) != "largest"))
    throw std::runtime_error("usage: build-tail-fibers PACKED_TAIL "
                             "ORIGINAL_RAW OUTPUT_DIR [largest]");
  fs::path dir = argv[3];
  bool largest = argc == 5;
  unsigned width = largest ? m : 1;
  if (!largest && !fs::create_directory(dir))
    throw std::runtime_error("Choose a fresh fibre output directory");
  Lookup keys;
  std::vector<std::uint8_t> smallest;
  smallest.reserve(embeddings);
  for (unsigned s = 0; s < (1u << (n - 1)); s++)
    if (std::popcount(s) == int(m))
      smallest.push_back(s & 127);
  if (smallest.size() != embeddings)
    throw std::logic_error("Wrong value-set count");
  Groups actual = blank(width);
  std::vector<Id> count(groups * width);
  std::vector<std::uint8_t> valid(groups);
  StreamTail packed(argv[1]);
  std::vector<std::array<Id, subsets>> directory(orders);
  for (Id order = 0; order < orders; order++) {
    packed.select(order);
    auto &row = directory[order];
    unsigned suffix_position = m - 1;
    // The final left-to-right maximum is the tail’s largest card. Its digit
    // in the source rank is zero, because no earlier value is larger.
    for (unsigned r = order; suffix_position && r % (suffix_position + 1);
         --suffix_position)
      r /= suffix_position + 1;
    for (unsigned s = 0; s < subsets; s++)
      row[s] = keys.id(order, s);
    for (unsigned set = 0; set < embeddings; set++) {
      Id g = row[smallest[set]] * width + (largest ? suffix_position : 0);
      ++count[g];
      meet(actual[g], packed.dictionary[packed.ids[set]]);
    }
  }
  for (unsigned s = 0; s < subsets; s++) {
    unsigned b = m - std::popcount(s), expected = permutations(cut, b);
    for (unsigned id = base[s]; id < base[s + 1]; id++) {
      if (!largest) {
        if (count[id] != expected)
          throw std::logic_error("Incorrect fibre cardinality");
        continue;
      }
      unsigned t = m - b;
      std::array<unsigned, m> digits{};
      unsigned r = id - base[s];
      for (int j = int(t) - 1; j >= 0; j--) {
        unsigned radix = m - j;
        digits[j] = r % radix;
        r /= radix;
      }
      unsigned unused = (1u << m) - 1, last_low = 0;
      for (unsigned j = 0; j < t; j++) {
        auto choices = unused;
        for (unsigned h = 0; h < digits[j]; h++)
          choices &= choices - 1;
        last_low = choices & -choices;
        unused ^= last_low;
      }
      unsigned allowed = b ? unused : last_low;
      for (unsigned pos = 0; pos < m; pos++) {
        unsigned true_count =
            (allowed & (1u << pos)) ? (b ? expected / b : 1) : 0;
        if (count[m * id + pos] != true_count)
          throw std::logic_error(
              "Incorrect largest-position fibre cardinality");
        if (true_count)
          valid[id] |= 1u << pos;
      }
    }
  }
  // Independently enumerate the ordered positions for the smallest t symbols.
  // Visit complete position permutations lexicographically. The first t
  // positions form successive groups of (7-t)! permutations. Inverting that
  // position word gives the ordinary suffix word used by the input file.
  std::array<std::array<std::uint16_t, m + 1>, orders> independent{};
  std::array<unsigned char, orders> independent_largest{};
  std::array<unsigned, m> pos;
  std::iota(pos.begin(), pos.end(), 0u);
  unsigned lex = 0;
  do {
    std::array<unsigned, m> word;
    for (unsigned i = 0; i < m; i++)
      word[pos[i]] = i;
    unsigned r = 0;
    for (unsigned i = 0; i < m; i++) {
      unsigned larger = 0;
      for (unsigned j = 0; j < i; j++)
        larger += word[j] > word[i];
      r = r * (i + 1) + larger;
    }
    independent_largest[r] = pos[m - 1];
    for (unsigned t = 0; t <= m; t++)
      independent[r][t] = lex / factorial_of(m - t);
    ++lex;
  } while (std::next_permutation(pos.begin(), pos.end()));
  if (lex != orders)
    throw std::logic_error("Incomplete injection check");
  for (unsigned t = 0; t < orders; t++)
    if (independent[t] != keys.rank[t])
      throw std::logic_error("Wrong injection rank");
  Groups reconstructed = blank(width);
  std::ifstream raw(argv[2], std::ios::binary | std::ios::ate);
  if (!raw ||
      raw.tellg() != std::streamoff(std::uint64_t(blocks) * sizeof(Mask)))
    throw std::runtime_error("Incorrect raw continuation size");
  raw.seekg(0);
  std::vector<Mask> source(embeddings);
  for (unsigned order = 0; order < orders; order++) {
    if (!raw.read(reinterpret_cast<char *>(source.data()),
                  source.size() * sizeof(Mask)))
      throw std::runtime_error("Raw continuation input failed");
    unsigned set_index = 0;
    for (unsigned bits = (1u << m) - 1; bits < (1u << (n - 1));) {
      unsigned small = 0;
      for (unsigned x = 1; x <= m; x++)
        if (bits & (1u << (x - 1)))
          small |= 1u << (x - 1);
      unsigned id = base[small] + independent[order][std::popcount(small)];
      meet(reconstructed[id * width +
                         (largest ? independent_largest[order] : 0)],
           source[set_index++]);
      unsigned low = bits & -bits, next = bits + low;
      bits = next | (((bits ^ next) / low) >> 2);
    }
    if (set_index != embeddings)
      throw std::logic_error("Incomplete independent set enumeration");
  }
  if (actual != reconstructed)
    throw std::logic_error("Packed and independent raw fibre meets differ");
  if (largest) {
    std::ifstream baseline(dir / "group-and.u64", std::ios::binary);
    for (unsigned id = 0; id < groups; id++) {
      Mask rec, original;
      rec.fill(~0ULL);
      for (unsigned pos = 0; pos < m; pos++) {
        auto &child = actual[m * id + pos];
        if (valid[id] & (1u << pos))
          meet(rec, child);
        else
          child.fill(0);
      }
      if (!baseline.read(reinterpret_cast<char *>(&original), sizeof(Mask)) ||
          original != rec)
        throw std::logic_error(
            "Largest-position refinement disagrees with original group");
    }
    write_new(dir / "group-and-by-largest-position.u64", actual.data(),
              actual.size());
    write_new(dir / "largest-position-valid.u8", valid.data(), valid.size());
  } else {
    write_new(dir / "group-and.u64", actual.data(), actual.size());
    write_new(dir / "group-by-order-smallset.u32", directory.data(),
              directory.size());
    write_new(dir / "injection-rank.u16", keys.rank.data(), keys.rank.size());
    write_new(dir / "smallset-base.u32", base.data(), base.size());
  }
  std::cout << "Verified all " << blocks << " rows, " << groups
            << " base groups, " << width << " positions per group, "
            << actual.size() * sizeof(Mask)
            << " bytes of full group AND masks.\n";
  for (unsigned t = 0; t <= m; t++) {
    std::uint64_t buckets = 0, nonempty = 0, ones = 0;
    for (unsigned s = 0; s < subsets; s++)
      if (std::popcount(s) == int(t))
        for (unsigned g = base[s]; g < base[s + 1]; g++) {
          for (unsigned pos = 0; pos < width; pos++)
            if (!largest || (valid[g] & (1u << pos))) {
              ++buckets;
              auto w = weight(actual[width * g + pos]);
              ones += w;
              nonempty += w != 0;
            }
        }
    std::cout << "small " << t << " groups " << buckets << " rows/group "
              << permutations(cut, m - t) / (largest && m > t ? m - t : 1)
              << " nonempty " << nonempty << " total bits " << ones << '\n';
  }
}
