// One descending consecutive pair contracts to a single card. Its original
// deck is sortable exactly when this 19-card image is sortable. The spool
// retains multiplicities for checking the accounting of every bonded input.
#pragma once
#include "join_tables.hpp"
#include <filesystem>
struct BondSpool {
  static_assert(n == 20);
  static constexpr unsigned target_n = 19, target_k = 11, target_sets = 31824;
  std::filesystem::path path;
  std::vector<unsigned short> set_id =
      std::vector<unsigned short>(1u << (target_n - 1));
  std::vector<std::ofstream> files =
      std::vector<std::ofstream>((5040 + 63) / 64);
  uint64_t count = 0;
  explicit BondSpool(const std::filesystem::path &dir) : path(dir) {
    if (!std::filesystem::exists(path) &&
        !std::filesystem::create_directory(path))
      throw std::runtime_error("Cannot create contraction spool directory");
    if (!std::filesystem::is_empty(path))
      throw std::runtime_error("Choose a fresh contraction spool directory");
    unsigned index = 0;
    for (unsigned mask = 0; mask < set_id.size(); mask++)
      if (std::popcount(mask) == 7)
        set_id[mask] = index++;
    if (index != target_sets)
      throw std::logic_error("Incorrect contraction set map");
  }
  bool add(const Deck &p) {
    unsigned skip = 0;
    while (skip + 1 < n && p[skip] != p[skip + 1] + 1)
      skip++;
    if (skip + 1 == n)
      return false;
    std::array<unsigned char, target_n> q;
    unsigned size = 0;
    for (unsigned i = 0; i < n; i++)
      if (i != skip)
        q[size++] = p[i] - (p[i] > p[skip]);
    unsigned values = 0, h = 0, factorial = 1;
    for (int i = target_k - 1; i >= 0; i--) {
      auto bit = 1u << q[i];
      h += factorial * std::popcount(values & (bit - 1));
      values |= bit;
      factorial *= target_k - i;
    }
    unsigned order = 0, tail_set = 0;
    for (unsigned i = target_k; i < target_n - 1; i++) {
      auto bit = 1u << (q[i] - 1);
      order =
          order * (i - target_k + 1) + std::popcount(tail_set >> (q[i] - 1));
      tail_set |= bit;
    }
    auto group = order / 64;
    auto &f = files[group];
    if (!f.is_open())
      f.open(path / ("contracted-" + std::to_string(group) + ".bin"),
             std::ios::binary);
    std::array<std::uint32_t, 2> query{h,
                                       order * target_sets + set_id[tail_set]};
    if (!f.write(reinterpret_cast<char *>(query.data()), sizeof(query)))
      throw std::runtime_error("Writing contraction failed");
    ++count;
    return true;
  }
  void finish() {
    for (auto &f : files)
      if (f.is_open()) {
        f.close();
        if (!f)
          throw std::runtime_error("Could not close contraction spool");
      }
  }
};
