"""Count pairs of suffix orders related by the sorting dual."""

import argparse
import bisect
import csv
import itertools
import math
from collections import Counter, defaultdict
from pathlib import Path


def suffix_rank(word):
    value = 0
    seen = 0
    for i, x in enumerate(word):
        value = (i + 1) * value + (seen >> x).bit_count()
        seen |= 1 << x
    return value


def dual(p):
    d = [0] * len(p)
    for i, x in enumerate(p):
        d[len(p) - 1 - x] = len(p) - 1 - i
    return tuple(d)


def induced(p, length):
    return tuple(x for x in p if x < length)


class Transitions:
    def __init__(self, k, m, priority):
        self.k, self.m, self.priority = k, m, priority
        self.words = sorted(itertools.permutations(range(m)), key=suffix_rank)
        self.buckets = defaultdict(list)
        for code, word in enumerate(self.words):
            for length in range(m + 1):
                self.buckets[length, induced(word, length)].append(priority[code])
        for group in self.buckets.values():
            group.sort()
        self.weight = [
            math.comb(k, m - l) * math.factorial(k) // math.factorial(m - l)
            for l in range(m + 1)
        ]
        self.total = math.factorial(k) * math.comb(k + m, m)

    def below(self, code, boundary):
        result = 0
        for length in range(self.m + 1):
            shape = dual(induced(self.words[code], length))
            group = self.buckets[length, shape]
            result += self.weight[length] * bisect.bisect_left(group, boundary)
        return result

    def weight_pair(self, a, b):
        u, v = self.words[a], self.words[b]
        return sum(
            w
            for l, w in enumerate(self.weight)
            if dual(induced(u, l)) == induced(v, l)
        )


def verify_tiny():
    k, m = 5, 3
    n = k + m + 1
    t = Transitions(k, m, list(range(math.factorial(m))))
    actual = Counter()
    for head in itertools.permutations(range(1, n)):
        p = head + (0,)
        a, b = suffix_rank(p[k:-1]), suffix_rank(dual(p)[k:-1])
        actual[a, b] += 1
    for a in range(math.factorial(m)):
        for b in range(math.factorial(m)):
            assert t.weight_pair(a, b) == actual[a, b]
        assert t.below(a, math.factorial(m)) == t.total


def observed(path, sample_size, k):
    n = k + 8
    with open(path, 'rb') as f:
        width = len(f.readline())
        if width == 0:
            return
        nrows = path.stat().st_size // width
        limit = min(nrows, sample_size)
        for j in range(limit):
            f.seek(((2*j+1)*nrows//(2*limit))*width)
            fields = f.readline().split()
            if len(fields) != n+2 or fields[0] != b'Hard':
                continue
            p = tuple(int(x)-1 for x in fields[2:])
            if sorted(p) != list(range(n)):
                continue
            yield suffix_rank(p[k:-1]), suffix_rank(dual(p)[k:-1])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("profile", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--prefix-size", type=int, choices=(11, 12), default=11)
    parser.add_argument("--metric", choices=("tree", "unbonded", "blend"), default="tree")
    parser.add_argument("--residuals", nargs="*", type=Path)
    parser.add_argument("--sample", type=int, default=8192)
    args = parser.parse_args()
    verify_tiny()
    with args.profile.open() as data:
        rows = list(csv.DictReader(data))
    assert len(rows) == 5040
    assert all(int(row["rank"]) == i for i, row in enumerate(rows))

    def score(i):
        row = rows[i]
        tree = float(row["tree_per_head"])
        unbonded = int(row["unbonded"])
        if args.metric == "tree":
            return tree, unbonded, i
        if args.metric == "unbonded":
            return unbonded, tree, i
        # The fitted score on the completed reference shards was 7:1.
        canonical = int(row["canonical"])
        return 7 * math.log1p(tree) + math.log1p(canonical), tree, unbonded, i

    priority_order = sorted(range(5040), key=score)
    priority = [0] * len(priority_order)
    for j, code in enumerate(priority_order):
        priority[code] = j
    transitions = Transitions(args.prefix_size, 7, priority)
    sampled = Counter()
    for source in args.residuals or []:
        sampled.update(observed(source, args.sample, args.prefix_size))
    sample_by_tau = defaultdict(list)
    for (code, other), count in sampled.items():
        sample_by_tau[code].append((other, count))

    levels = [1, 5, 10, 25, 50]
    total = transitions.total
    strict_sum = 0
    same_sum = 0
    by_priority = []
    with args.out.open("w", newline="") as output:
        writer = csv.writer(output)
        writer.writerow(
            ["tau", "easier_priority", "strictly_easier_duals", "same_order_duals", "deck_count"]
            + [f"dual_top_{p}pct_count" for p in levels]
            + ["observed", "observed_strictly_easier"]
        )
        for code in priority_order:
            assert transitions.below(code, 5040) == total
            easier = transitions.below(code, priority[code])
            same = transitions.weight_pair(code, code)
            strict_sum += easier
            same_sum += same
            harder = [
                total - transitions.below(code, 5040 - 5040 * p // 100)
                for p in levels
            ]
            sample = sample_by_tau[code]
            obs = sum(count for _, count in sample)
            obs_easier = sum(count for other, count in sample if priority[other] < priority[code])
            writer.writerow([code, priority[code], easier, same, total, *harder, obs, obs_easier])
            by_priority.append(harder)
    assert 2 * strict_sum + same_sum == 5040 * total
    print(f"Verified every ordered pair on 40,320 decks, all {args.prefix_size + 8}-card row sums and global reflection symmetry.")
    for i, percent in enumerate(levels):
        count = 5040 * percent // 100
        start = 5040 - count
        fraction = sum(row[i] for row in by_priority[start:]) / (count * total)
        obs_hard = sum(num for (a, _), num in sampled.items() if priority[a] >= start)
        obs_both = sum(num for (a, b), num in sampled.items() if min(priority[a], priority[b]) >= start)
        msg = f"top {count:4d} ({percent:2d}%): exact conditional both-hard {fraction:.5%}, unconditional {count / 5040 * fraction:.5%}"
        if obs_hard:
            msg += f", sampled residual {obs_both}/{obs_hard} = {obs_both / obs_hard:.5%}"
        print(msg)
    for code in [133, 144, 435, 443, 477, 485, 3511]:
        easier = transitions.below(code, priority[code]) / total
        print(f"tau {code:4d} priority {priority[code]:4d}, easier dual exact {easier:.4%}")


if __name__ == "__main__":
    main()
