"""Reconstruct the seven-block sample of 19-card flexible-cut parents."""
import argparse
import gzip
import json
import random
import subprocess
from pathlib import Path

from flexible_lifts import tie

blocks = [
    "order0--2962-3113", "order1--1179-1186", "order2--2857-2975",
    "order3--357-444", "order4--2026-2275", "order5--3810-3868", "order6--911-936",
]


def run(program, args, rows):
    result = subprocess.run([program, *map(str, args)], input=b"".join(rows),
                            capture_output=True, check=True)
    return result.stdout.splitlines(keepends=True)


def sample_block(data, number, block, rng, excluded):
    closure = data / "19-ordered-closed" / block / "closure.json"
    ranks = dict(json.loads(closure.read_text())["ranks"])
    intervals = []
    cursor = 0
    for line in (data / f"order19-log-{number}.txt").read_text().splitlines():
        fields = line.split()
        if not fields or fields[0] != "order" or "pending" not in fields:
            continue
        rank = int(fields[1])
        count = int(fields[fields.index("pending") + 1])
        if rank in ranks:
            if count != ranks[rank]:
                raise ValueError("Changed rank count")
            intervals.append((cursor, count))
        cursor += count
    population = sum(count for _, count in intervals)
    if population != sum(ranks.values()):
        raise ValueError("Incomplete source block")
    selections = sorted(rng.sample(range(population), min(7200, population)))
    listed = []
    width = len(("Hard 1 " + " ".join(map(str, range(1, 20))) + "\n").encode())
    with (data / f"order19-hard-{number}.txt").open("rb") as raw:
        position = start = 0
        for origin, count in intervals:
            while position < len(selections) and selections[position] < start + count:
                raw.seek((origin + selections[position] - start) * width)
                line = raw.read(width)
                deck = tuple(map(int, line.split()[2:]))
                if sorted(deck) != list(range(1, 20)) or not line.endswith(b"\n"):
                    raise ValueError("Misaligned source")
                if deck not in excluded and all(abs(x - y) > 1 for x, y in zip(deck, deck[1:])):
                    listed.append(line)
                position += 1
            start += count
    return population, len(selections), listed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data", type=Path)
    parser.add_argument("archive", type=Path)
    args = parser.parse_args()
    tools = json.loads((args.data / "19-ordered-tools.json").read_text())
    rng = random.Random(202611260604)
    snapshot = args.archive / "flex-lift-sat-snapshot.gz"
    if snapshot.exists():
        with gzip.open(snapshot, "rt") as stream:
            excluded = {tuple(map(int, line.split())) for line in stream}
    else:
        excluded = set()
        for path in (args.data / "19-ordered-closed").glob("*/individual.txt"):
            for line in path.read_text().splitlines():
                excluded.add(tuple(map(int, line.split()[2:])))
        with gzip.open(snapshot, "wt") as stream:
            for deck in sorted(excluded):
                print(*deck, file=stream)

    parents = set()
    for number, block in enumerate(blocks):
        population, sample_size, listed = sample_block(args.data, number, block, rng, excluded)
        for k, flipped in [(10, False), (9, False), (10, True), (9, True), (8, False), (8, True)]:
            arguments = [tools[f"prefix{k}"], 19, 1000, 11]
            if flipped:
                arguments.append("dual")
            listed = run(tools[f"recut{k}"], arguments, listed)
        passing = set(listed) - set(run(tools["flex"], [19, 180, 12, 13, 14, 15, 7], listed))
        late = set(run(tools["flex"], [19, 40, 12, 13], sorted(passing)))
        def key(line):
            return line not in late, tie(tuple(map(int, line.split()[2:])))
        chosen = sorted(passing, key=key)[:40]
        parents.update(tuple(map(int, line.split()[2:])) for line in chosen)
        print(block, population, sample_size, len(listed), len(passing), len(late), len(chosen), flush=True)
    with (args.archive / "flex-lift-parents.txt").open("w") as out:
        for deck in sorted(parents):
            print(*deck, file=out)


if __name__ == "__main__":
    main()
