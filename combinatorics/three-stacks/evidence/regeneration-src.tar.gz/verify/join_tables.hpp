#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <fstream>
#include <iostream>
#include <limits>
#include <list>
#include <memory>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <unordered_map>
#include <vector>

using Id = std::uint32_t;
#ifndef CARD_COUNT
#define CARD_COUNT 17
#endif
#ifndef CUT_SIZE
#define CUT_SIZE (CARD_COUNT >= 19 ? CARD_COUNT - 8 : 10)
#endif
constexpr unsigned n = CARD_COUNT, cut = CUT_SIZE, ordinary = n - cut - 1;
static_assert(n <= 20 && cut <= 12 && cut >= 2 && ordinary <= 8);
constexpr Id factorial_of(unsigned k) {
  Id result = 1;
  for (unsigned i = 2; i <= k; i++)
    result *= i;
  return result;
}
constexpr Id choose(unsigned k, unsigned r) {
  Id result = 1;
  for (unsigned i = 1; i <= r; i++)
    result = result * (k - r + i) / i;
  return result;
}
constexpr unsigned columns = 1 + 2 * cut + 3 * cut * (cut - 1);
using Mask = std::array<std::uint64_t, (columns + 63) / 64>;
using Head = std::array<std::uint8_t, cut>;
using Tail = std::array<std::uint8_t, ordinary>;
using Deck = std::array<std::uint8_t, n>;
constexpr Id heads = factorial_of(cut), embeddings = choose(n - 1, ordinary);
constexpr Id tail_orders = factorial_of(ordinary),
             blocks = embeddings * tail_orders;
constexpr unsigned chunks = (heads + 63) / 64;
bool invalid_high_bits(const Mask &m) {
  if constexpr (columns % 64)
    return (m.back() >> (columns % 64)) != 0;
  return false;
}

bool disjoint(const Mask &a, const Mask &b) {
  std::uint64_t shared = 0;
  for (unsigned i = 0; i < a.size(); ++i)
    shared |= a[i] & b[i];
  return !shared;
}
bool subset(const Mask &a, const Mask &b) {
  for (unsigned i = 0; i < a.size(); ++i)
    if (a[i] & ~b[i])
      return false;
  return true;
}
int weight(const Mask &a) {
  int answer = 0;
  for (auto bits : a)
    answer += std::popcount(bits);
  return answer;
}
struct MaskHash {
  std::size_t operator()(const Mask &a) const {
    std::uint64_t h = 1;
    for (auto x : a)
      h = (h ^ x) * 0x9e3779b97f4a7c15ULL;
    return h ^ (h >> 32);
  }
};
#include "packed_tail.hpp"

// Both tables are immutable file-backed pages. Dual tests can address remote
// suffix ranks without retaining another copy of the full tail table in RAM.
struct TableFile {
  const Mask *data = nullptr;
  void *mapping = nullptr;
  std::size_t bytes = 0;
  Id origin = 0;
  packed_tail::View packed;
  TableFile(const char *path, std::size_t count, bool allow_packed = false) {
    int fd = open(path, O_RDONLY);
    if (fd < 0)
      throw std::runtime_error("Unable to open table");
    struct stat info;
    if (fstat(fd, &info) != 0 || info.st_size <= 0) {
      close(fd);
      throw std::runtime_error("Incorrect table size");
    }
    bytes = info.st_size;
    std::uint64_t tag = 0;
    if (pread(fd, &tag, sizeof(tag), 0) != sizeof(tag)) {
      close(fd);
      throw std::runtime_error("Truncated table");
    }
    bool is_packed = allow_packed && tag == packed_tail::magic;
    if (!is_packed && bytes != count * sizeof(Mask)) {
      close(fd);
      throw std::runtime_error("Incorrect table size");
    }
    mapping = mmap(nullptr, bytes, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    if (mapping == MAP_FAILED)
      throw std::runtime_error("Unable to map table");
    if (is_packed)
      packed.attach(mapping, bytes);
    else
      data = static_cast<const Mask *>(mapping);
  }
  // A local slice starts with row first. A global file can be read as soon
  // as rows through end have been written. Map only the requested interval.
  TableFile(const char *path, Id count, Id first, Id end, bool local_slice)
      : origin(first) {
    if(first>=end || end>count)throw std::runtime_error("Invalid raw table interval");
    int fd=open(path,O_RDONLY);struct stat info{};
    const auto length=std::size_t(end-first)*sizeof(Mask);
    const auto pos=local_slice?0:std::size_t(first)*sizeof(Mask);
    if(fd<0 || fstat(fd,&info)!=0 ||
       (local_slice ? std::size_t(info.st_size)!=length :
         std::size_t(info.st_size)<pos+length || std::size_t(info.st_size)>std::size_t(count)*sizeof(Mask))){
      if(fd>=0)close(fd);
      throw std::runtime_error("Incomplete raw table interval");
    }
    const auto page=std::size_t(sysconf(_SC_PAGESIZE));
    auto aligned=pos-pos%page;
    bytes=length+(pos-aligned);
    mapping=mmap(nullptr,bytes,PROT_READ,MAP_SHARED,fd,aligned);close(fd);
    if(mapping==MAP_FAILED)throw std::runtime_error("Cannot map raw table interval");
    data=reinterpret_cast<const Mask*>(static_cast<const char*>(mapping)+(pos-aligned));
  }
  ~TableFile() {
    if (mapping)
      munmap(mapping, bytes);
  }
  TableFile(const TableFile &) = delete;
  const Mask &operator[](Id id) const {
    return data ? data[id-origin] : packed.get(id);
  }
};
struct Group {
  Mask mask{};
  int bits = 0;
  std::vector<Id> blocks;
};
struct WordInfo {
  Head rank;
  std::uint8_t max_position;
  std::uint16_t descending;
};
struct Embedding {
  Head front{};
  Tail back{};
  unsigned consecutive = 0;
};

struct Coding {
  std::array<Tail, tail_orders> orders{};
  const WordInfo *prefixes;
  std::vector<Embedding> labels;
  std::array<Id, 1 << (n - 1)> set_id{};
  std::array<Id, cut + 1> factorial{};

  static int tail_rank(const std::uint8_t *x) {
    int rank = 0;
    unsigned seen = 0;
    for (unsigned i = 0; i < ordinary; ++i) {
      int larger = std::popcount(seen >> x[i]);
      rank = rank * (i + 1) + larger;
      seen |= 1u << x[i];
    }
    return rank;
  }
  explicit Coding(const WordInfo *words) : prefixes(words) {
    factorial[0] = 1;
    for (unsigned i = 1; i < factorial.size(); ++i)
      factorial[i] = i * factorial[i - 1];
    std::array<int, ordinary> tail_order;
    std::iota(tail_order.begin(), tail_order.end(), 0);
    std::array<bool, tail_orders> seen{};
    do {
      Tail word;
      std::copy(tail_order.begin(), tail_order.end(), word.begin());
      int r = tail_rank(word.data());
      if (seen[r])
        throw std::logic_error("Repeated suffix rank");
      seen[r] = true;
      orders[r] = word;
    } while (std::next_permutation(tail_order.begin(), tail_order.end()));
    for (unsigned mask = 0; mask < (1u << (n - 1)); ++mask)
      if (std::popcount(mask) == int(ordinary)) {
        Embedding e;
        unsigned a = 0, b = 0;
        for (unsigned x = 0; x < n - 1; ++x) {
          if (mask & (1u << x))
            e.back[b++] = x + 1;
          else
            e.front[a++] = x + 1;
        }
        for (unsigned j = 1; j < cut; ++j)
          if (e.front[j] == e.front[j - 1] + 1)
            e.consecutive |= 1u << (j - 1);
        set_id[mask] = labels.size();
        labels.push_back(e);
      }
    if (labels.size() != embeddings)
      throw std::logic_error("Incorrect value sets");
  }
  Deck decode(Id h, Id block) const {
    Deck p{};
    const auto &e = labels[block % embeddings];
    const auto &tau = orders[block / embeddings];
    for (unsigned i = 0; i < cut; ++i)
      p[i] = e.front[prefixes[h].rank[i]];
    for (unsigned i = 0; i < ordinary; ++i)
      p[cut + i] = e.back[tau[i]];
    return p;
  }
  std::pair<Id, Id> encode(const Deck &p) const {
    Id h = 0, seen = 0;
    for (int i = cut - 1; i >= 0; --i) {
      auto bit = 1u << p[i];
      h += factorial[cut - 1 - i] * std::popcount(seen & (bit - 1));
      seen |= bit;
    }
    unsigned m = 0;
    for (unsigned i = cut; i < n - 1; ++i)
      m |= 1u << (p[i] - 1);
    return {h, tail_rank(p.data() + cut) * embeddings + set_id[m]};
  }
};
// Entries are in column-major order, so a worker can stream the bitsets
// for the layouts in one tail mask. A persistent index shares all large
// arrays between workers and all n with the same cut size.
struct IndexHeader {
  std::uint64_t magic;
  std::uint64_t checksum;
  std::uint32_t cut_size, layouts, prefix_rows;
  std::array<unsigned, columns> order;
};
constexpr std::uint64_t index_magic = 0x325844494b435453ULL;
constexpr std::size_t header_bytes = 4096;
static_assert(sizeof(IndexHeader) <= header_bytes);
constexpr std::size_t word_bytes =
    (std::size_t(heads) * sizeof(WordInfo) + 7) & ~std::size_t(7);
constexpr std::size_t index_bytes =
    header_bytes + word_bytes + std::size_t(columns) * chunks * 8;

std::uint64_t fingerprint(const TableFile &head) {
  std::uint64_t h = 1469598103934665603ULL;
  for (Id i = 0; i < heads; ++i) {
    const auto &row = head[i];
    if (invalid_high_bits(row))
      throw std::logic_error("High bits in prefix mask");
    for (auto word : row)
      h = (h ^ word) * 1099511628211ULL;
  }
  return h;
}
struct IndexFile {
  std::uint8_t *data = nullptr;
  ~IndexFile() {
    if (data)
      munmap(data, index_bytes);
  }
  IndexFile() = default;
  IndexFile(const IndexFile &) = delete;
  void map(int fd, bool writable) {
    int flags = fd < 0     ? MAP_PRIVATE | MAP_ANONYMOUS
                : writable ? MAP_SHARED
                           : MAP_PRIVATE;
    auto p = mmap(nullptr, index_bytes, PROT_READ | (writable ? PROT_WRITE : 0),
                  flags, fd, 0);
    if (p == MAP_FAILED)
      throw std::runtime_error("Unable to map the prefix index");
    data = static_cast<std::uint8_t *>(p);
  }
  IndexHeader *header() const { return reinterpret_cast<IndexHeader *>(data); }
  WordInfo *words() const {
    return reinterpret_cast<WordInfo *>(data + header_bytes);
  }
  std::uint64_t *bits() const {
    return reinterpret_cast<std::uint64_t *>(data + header_bytes + word_bytes);
  }
  void load(const char *filename, const TableFile &head) {
    int fd = open(filename, O_RDONLY);
    if (fd < 0)
      throw std::runtime_error("Unable to open precomputed prefix index");
    struct stat info;
    if (fstat(fd, &info) != 0 || info.st_size != off_t(index_bytes)) {
      close(fd);
      throw std::runtime_error("Incorrect prefix index size");
    }
    map(fd, false);
    close(fd);
    const auto &meta = *header();
    if (meta.magic != index_magic || meta.cut_size != cut ||
        meta.layouts != columns || meta.prefix_rows != heads ||
        meta.checksum != fingerprint(head))
      throw std::runtime_error("Prefix index does not match the input table");
  }
  // Swap successively smaller square submatrices between the upper-right
  // and lower-left quadrants. After transposition, bit j of line i is the
  // original bit i of line j.
  static void transpose(std::array<std::uint64_t, 64> &lines) {
    std::uint64_t mask = 0xffffffffULL;
    for (unsigned shift = 32; shift;) {
      for (unsigned k = 0; k < 64; k = (k + shift + 1) & ~shift) {
        auto swap = ((lines[k] >> shift) ^ lines[k + shift]) & mask;
        lines[k] ^= swap << shift;
        lines[k + shift] ^= swap;
      }
      shift /= 2;
      mask ^= mask << shift;
    }
  }
  void build(const TableFile &head) {
    auto &meta = *header();
    meta.checksum = fingerprint(head);
    meta.cut_size = cut;
    meta.layouts = columns;
    meta.prefix_rows = heads;
    std::array<int, cut> order;
    std::iota(order.begin(), order.end(), 0);
    Id id = 0;
    do {
      auto &entry = words()[id];
      std::copy(order.begin(), order.end(), entry.rank.begin());
      entry.max_position =
          std::find(order.begin(), order.end(), cut - 1) - order.begin();
      entry.descending = 0;
      for (unsigned j = 1; j < cut; ++j)
        if (order[j - 1] == order[j] + 1)
          entry.descending |= 1u << order[j];
      ++id;
    } while (std::next_permutation(order.begin(), order.end()));
    if (id != heads)
      throw std::logic_error("Wrong prefix permutation enumeration");
    std::array<Id, columns> hits{};
    for (Id w = 0; w < chunks; ++w) {
      unsigned valid = std::min(64u, heads - 64 * w);
      for (unsigned part = 0; part < Mask{}.size(); ++part) {
        std::array<std::uint64_t, 64> lines{};
        for (unsigned j = 0; j < valid; ++j)
          lines[j] = head[64 * w + j][part];
        transpose(lines);
        for (unsigned j = 0; j < 64 && part * 64 + j < columns; ++j) {
          unsigned c = part * 64 + j;
          bits()[std::size_t(c) * chunks + w] = lines[j];
          hits[c] += std::popcount(lines[j]);
        }
      }
    }
    std::iota(meta.order.begin(), meta.order.end(), 0);
    std::sort(meta.order.begin(), meta.order.end(),
              [&](auto a, auto b) { return hits[a] > hits[b]; });
    meta.magic = index_magic;
  }
};

void build_and_publish_index(const char *source, const char *destination) {
  TableFile head(source, heads);
  std::string temp = std::string(destination) + ".tmp.XXXXXX";
  int fd = mkstemp(temp.data());
  if (fd < 0)
    throw std::runtime_error("Cannot create prefix index");
  try {
    if (ftruncate(fd, index_bytes) != 0)
      throw std::runtime_error("Cannot size prefix index");
    IndexFile storage;
    storage.map(fd, true);
    storage.build(head);
    if (msync(storage.data, index_bytes, MS_SYNC) != 0 || fsync(fd) != 0)
      throw std::runtime_error("Cannot flush prefix index");
    if (rename(temp.c_str(), destination) != 0)
      throw std::runtime_error("Cannot publish prefix index");
    close(fd);
  } catch (...) {
    close(fd);
    unlink(temp.c_str());
    throw;
  }
  std::cerr << "Built shared prefix index for " << heads << " words, "
            << index_bytes << " bytes\n";
}

