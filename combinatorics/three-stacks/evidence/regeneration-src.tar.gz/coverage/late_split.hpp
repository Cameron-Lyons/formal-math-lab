#pragma once
#include "../structural/two.hpp"
#include <array>
#include <bit>
#include <cstdint>
#include <stdexcept>
#include <vector>

namespace late_split {
// Sort the extended prefix in descending order through stacks 1 and 2 into
// stack 3. A two-stack sorting of the suffix can then be merged with stack 3.
template <unsigned N, unsigned K> class Filter {
  static constexpr unsigned positive_tail = N - K - 2;
  static constexpr unsigned factorial(unsigned k) {
    unsigned v = 1;
    for (unsigned i = 2; i <= k; ++i)
      v *= i;
    return v;
  }
  static constexpr unsigned slot_bits = 19;
  std::vector<std::uint64_t> intervals =
      std::vector<std::uint64_t>(1u << slot_bits);
  std::array<bool, factorial(positive_tail)> good_short_suffix{};
  template <class Word>
  static unsigned suffix_rank(const Word &p, unsigned from) {
    unsigned seen = 0, r = 0;
    for (unsigned j = from; j + 1 < N; ++j) {
      r = r * (j - from + 1) + std::popcount(seen >> p[j]);
      seen |= 1u << p[j];
    }
    return r;
  }

public:
  uint64_t lookups = 0, searches = 0;
  Filter() {
    static_assert(positive_tail <= 6 && K + 2 < 16);
    std::array<int, N> p{};
    for (unsigned i = 0; i < positive_tail; i++)
      p[K + 1 + i] = i + 1;
    do {
      good_short_suffix[suffix_rank(p, K + 1)] =
          two::twoRec(p.data() + K + 1, positive_tail + 1, 0, 0, 0, 0);
    } while (std::next_permutation(p.begin() + K + 1, p.end() - 1));
    // Every remaining suffix has at most six cards. Check this finite premise
    // directly before treating the second extension as an unconditional gate.
    std::array<int, positive_tail> q{};
    std::iota(q.begin(), q.end(), 0);
    do {
      if (!two::twoRec(q.data(), positive_tail, 0, 0, 0, 0))
        throw std::logic_error("Two-stack suffix assumption failed");
    } while (std::next_permutation(q.begin(), q.end()));
  }
  template <class Word> bool accepts(const Word &p, unsigned head) {
    ++lookups;
    unsigned members = 0;
    for (unsigned i = 0; i < K; ++i)
      members |= 1u << p[i];
    unsigned first = p[K],
             first_rank = std::popcount(members & ((1u << first) - 1));
    bool one = good_short_suffix[suffix_rank(p, K + 1)];
    unsigned inserted = first_rank, length = K + 1;
    // Keep single-extension cache keys separate from extensions of K+1 heads.
    uint64_t key = uint64_t(head) * (K + 2);
    if (!one) {
      key += first_rank + 1;
      members |= 1u << first;
      inserted = std::popcount(members & ((1u << p[K + 1]) - 1));
      ++length;
    }
    ++key;
    auto &stored = intervals[(key * 0x9e3779b97f4a7c15ull) >> (64 - slot_bits)];
    unsigned lower = 0, upper = length;
    if ((stored >> 8) == key) {
      lower = stored & 15;
      upper = (stored >> 4) & 15;
    }
    if (inserted < lower)
      return true;
    if (inserted >= upper)
      return false;
    members |= 1u << p[length - 1];
    std::array<int, K + 2> complemented{};
    for (unsigned i = 0; i < length; i++)
      complemented[i] = std::popcount(members >> (p[i] + 1));
    ++searches;
    bool sorted = two::twoRec(complemented.data(), length, 0, 0, 0, 0);
    // Lowering the value of the last input card preserves a sorting in
    // descending order. Delete it from the schedule and pass its replacement
    // straight through at the later output position, after the input is read.
    if (sorted)
      lower = inserted + 1;
    else
      upper = inserted;
    stored = (key << 8) | (upper << 4) | lower;
    return sorted;
  }
};
} // namespace late_split
