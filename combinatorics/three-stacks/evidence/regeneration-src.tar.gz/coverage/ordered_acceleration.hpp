// Fast positive lookup of the dual's common cut-11 layout. The full layout
// comparison is still run when the selected 16 columns do not intersect.
#pragma once
#include "quadrant_codes.hpp"
#include "../verify/quadrant_code_file.hpp"
#include <filesystem>

namespace ordered_acceleration {
class ProjectedRows {
  const uint16_t *rows_;
  size_t bytes_;

public:
  ProjectedRows(const std::filesystem::path &path, size_t count)
      : bytes_(count * sizeof(uint16_t)) {
    int fd = open(path.c_str(), O_RDONLY);
    struct stat info;
    if (fd < 0 || fstat(fd, &info) || info.st_size != off_t(bytes_))
      throw std::runtime_error("Invalid projected layout table");
    rows_ = static_cast<const uint16_t *>(
        mmap(nullptr, bytes_, PROT_READ, MAP_SHARED, fd, 0));
    close(fd);
    if (rows_ == MAP_FAILED)
      throw std::runtime_error("Cannot map projected layout table");
  }
  ProjectedRows(const ProjectedRows &) = delete;
  ~ProjectedRows() { munmap(const_cast<uint16_t *>(rows_), bytes_); }
  const uint16_t &operator[](Id index) const { return rows_[index]; }
};

struct Dual {
  using Tables = quadrant_codes::Tables<n, cut>;
  Tables tables;
  quadrant_codes::File<cut> codes;
  ProjectedRows prefixes, suffixes;
  std::vector<Tables::Block> address;

  explicit Dual(const std::filesystem::path &root)
      : codes((root / "quadrant-codes11.bin").c_str()),
        prefixes(root / "ordered19-head16.bin", heads),
        suffixes(root / "ordered19-tail16.bin", blocks) {
    address.reserve(embeddings);
  }
  template <class Leaves> void prepare(const Leaves &leaves) {
    address.clear();
    for (const auto &leaf : leaves)
      address.emplace_back(tables, leaf.prefix, leaf.suffix);
  }
};
}
