"""Independently verify the splice certificate using Cartesian T placements."""
import argparse
from itertools import permutations, product
import json
from pathlib import Path


CERTIFICATE = Path(__file__).with_name("splice_witnesses.json")
PATTERNS = set(product("012", repeat=4))
ACTIONS = [(str.maketrans("012", "".join(colors)), reflect)
           for colors in permutations("012") for reflect in (False, True)]


def split_rows(flat, start, stop):
    """Decode the rows with indices start through stop-1."""
    if len(flat) != stop * stop - start * start or set(flat) - set("012"):
        raise ValueError(f"invalid encoding for rows {start} through {stop - 1}")
    return [flat[r*r - start*start:(r+1)**2 - start*start] for r in range(start, stop)]


def patterns(rows, start):
    grid = {(j-r, -r): color for r, row in enumerate(rows, start)
            for j, color in enumerate(row)}
    seen = set()
    for x, y in grid:
        cells = ((x, y+1), (x-1, y), (x, y), (x+1, y))
        if all(cell in grid for cell in cells):
            pattern = tuple(grid[cell] for cell in cells)
            if pattern in seen:
                raise ValueError(f"repeated T {pattern}")
            seen.add(pattern)
    return frozenset(seen)


def common_set(pieces):
    iterator = iter(pieces)
    first = next(iterator)
    if any(other != first for other in iterator):
        raise ValueError("pieces disagree on their T patterns")
    return first


def verify(data):
    cut = data["cut"]
    if not 0 < cut < 9 or not data["groups"]:
        raise ValueError("expected a nonempty certificate with an interior cut")
    signatures = set()
    # The apex at both ends makes reflection of a board reverse its marker.
    marker_actions = {}
    representatives = cap_count = tail_count = 0
    for index, group in enumerate(data["groups"]):
        pivot = group["pivot"]
        split_rows(pivot, cut, cut+1)
        caps, tails = group["caps"], group["tails"]
        for pieces in (caps, tails):
            if not pieces or len(pieces) != len(set(pieces)):
                raise ValueError(f"empty or duplicate pieces in group {index}")
        for apex in {cap[0] for cap in caps}:
            marker = apex + pivot + apex
            for action, (palette, reflected) in enumerate(ACTIONS):
                image = (marker[::-1] if reflected else marker).translate(palette)
                if marker_actions.setdefault(image, action) != action:
                    raise ValueError(f"ambiguous symmetry for marker {marker}")
        upper = common_set(patterns(split_rows(cap, 0, cut) + [pivot], 0)
                           for cap in caps)
        lower = common_set(patterns([pivot] + split_rows(tail, cut+1, 10), cut)
                           for tail in tails)
        if upper & lower or upper | lower != PATTERNS:
            raise ValueError(f"patterns do not partition all 81 in group {index}")
        key = (pivot, upper)
        if key in signatures:
            raise ValueError(f"duplicate group signature at group {index}")
        signatures.add(key)
        representatives += len(caps) * len(tails)
        cap_count += len(caps)
        tail_count += len(tails)
    return len(signatures), cap_count, tail_count, representatives, 12 * representatives


def verify_expanded(data, expected):
    """Check every complete image geometrically, and compare with the earlier family."""
    positions = {(j-r, -r): r*r+j for r in range(10) for j in range(2*r+1)}
    windows = []
    for x, y in positions:
        cells = ((x, y+1), (x-1, y), (x, y), (x+1, y))
        if all(cell in positions for cell in cells):
            windows.append(tuple(positions[cell] for cell in cells))
    if len(windows) != 81:
        raise ValueError("incorrect placement count")
    powers = [1 << i for i in range(81)]
    all_patterns = (1 << 81) - 1
    boards = set()
    for group in data["groups"]:
        for cap, tail in product(group["caps"], group["tails"]):
            rows = split_rows(cap + group["pivot"] + tail, 0, 10)
            flat = "".join(rows)
            mirror = "".join(row[::-1] for row in rows)
            for palette, reflected in ACTIONS:
                image = (mirror if reflected else flat).translate(palette)
                if image in boards:
                    raise ValueError("duplicate full board")
                boards.add(image)
                digits = bytes(map(int, image))
                seen = 0
                for t, l, m, r in windows:
                    seen |= powers[27*digits[t] + 9*digits[l] + 3*digits[m] + digits[r]]
                if seen != all_patterns:
                    raise ValueError(f"invalid full board: {image}")
    if len(boards) != expected:
        raise ValueError("expanded count differs from splice count")
    previous = json.loads(CERTIFICATE.with_name("extended_family.json").read_text())
    if any("".join(rows) not in boards for rows in previous):
        raise ValueError("an earlier board is absent")
    print(f"Checked all {expected:,} full images, including all {len(previous):,} earlier boards.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", type=Path, nargs="?", default=CERTIFICATE)
    parser.add_argument("--expand", action="store_true", help="also check every labeled board directly")
    args = parser.parse_args()
    certificate = json.loads(args.certificate.read_text())
    groups, caps, tails, representatives, labeled = verify(certificate)
    print(f"Verified {groups:,} groups, {caps:,} caps, and {tails:,} tails.")
    print(f"{representatives:,} disjoint symmetry families give {labeled:,} labeled boards.")
    if args.expand:
        verify_expanded(certificate, labeled)
