# Which suffix orders occur together under sorting duality?

Write a 19-card permutation ending in 1 with zero-based values and split its positive portion into an 11-card prefix and a seven-card suffix. Let τ be the relative order of the suffix, and υ the corresponding order for the reflected permutation D(p), where $D(p)_{18-p_i}=18-i$. For $\ell=0,\ldots,7$ let $a_\ell(\tau)$ be the word induced by the smallest ℓ values of τ.

The exact number of decks with the ordered pair (τ, υ) is

$$
W(\tau,\upsilon)=\sum_{\ell=0}^{7}
\mathbf 1\{a_\ell(\upsilon)=D(a_\ell(\tau))\}
\binom{11}{7-\ell}\frac{11!}{(7-\ell)!}.
$$

To see this, divide the positive values into 1 through 7 and 8 through 18. Suppose ℓ low values occur in the original suffix. Read the original positions of values 7 down to 1 to form the dual suffix. The ℓ low values belonging to the original suffix occupy precisely the positions carrying the smallest ℓ values of υ. Thus υ specifies the low value set. The relative order on these ℓ positions is the anti-diagonal reflection of the order of the ℓ smallest original suffix values. The other $b=7-\ell$ suffix values can be chosen from 11 high values in $\binom{11}{b}$ ways. The ordering of the b low values in the original prefix is fixed by υ. The rest of the prefix can therefore be completed in $11!/b!$ ways. τ determines the entire suffix once its values have been chosen.

The same formula holds for a positive prefix of length k and a positive suffix of length m, replacing 11 by k and 7 by m when $k\geq m$. It is symmetric in the two suffix orders and each row sums to $11!\binom{18}{7}$ at length 19. Summing over an arbitrary set of dual orders requires only eight lookups in buckets indexed by the smaller induced patterns.

The script checks all 36 pair multiplicities directly on all 40,320 nine-card decks ending in 1 with a five-card prefix. It also checks the row sums for all 5,040 orders at length 19. Its optional empirical residual columns use a stratified sample of fixed-width input rows and depend on the supplied shard files. Its unconditional transition counts are exact.

```sh
python coverage/dual_order_profile.py hardness19.csv dual-priority19.csv
```
