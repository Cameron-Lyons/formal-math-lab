// Hold a selected normalized prefix fixed and vary every value set and tail.
// Deferred (dual-head, dual-tail) pairs go to the same raw format as lazy_dual.
#ifndef CARD_COUNT
#define CARD_COUNT 20
#endif
#include "../knuth/layout.hpp"
#include "bond_spool.hpp"
#include "join_tables.hpp"
#include "stream_tail.hpp"
#include <filesystem>
namespace fs = std::filesystem;
struct HeadState {
  Head p;
  Id rank;
  Mask layouts;
  unsigned bonds;
};
struct Query {
  Id h, b;
};
template <typename T> void read(std::ifstream &f, T *p, size_t rows) {
  if (!f.read(reinterpret_cast<char *>(p), rows * sizeof(T)))
    throw std::runtime_error("Packed read failed");
}
int main(int argc, char **argv) {
  if (argc != 7 && (argc != 8 || std::string(argv[7]) != "contract-bonds"))
    throw std::runtime_error(
        "usage: published-head-scan HEAD_RANKS "
        "PACKED_TAIL FIRST STOP STRIDE NEW_SPOOL [contract-bonds]");
  std::ifstream seeds(argv[1]);
  Id r;
  std::vector<HeadState> sample;
  auto shapes = layout::layouts(cut);
  while (seeds >> r) {
    if (r >= heads || sample.size() == 64 ||
        std::any_of(sample.begin(), sample.end(),
                    [&](const auto &s) { return s.rank == r; }))
      throw std::runtime_error("Invalid or repeated head rank");
    auto &s = sample.emplace_back();
    s.rank = r;
    unsigned avail = (1u << cut) - 1, ways = heads;
    for (unsigned i = 0; i < cut; i++) {
      ways /= cut - i;
      unsigned skip = r / ways;
      r %= ways;
      auto bits = avail;
      while (skip--)
        bits &= bits - 1;
      s.p[i] = std::countr_zero(bits);
      avail ^= 1u << s.p[i];
      if (i && s.p[i - 1] == s.p[i] + 1)
        s.bonds |= 1u << s.p[i];
    }
    for (unsigned j = 0; j < shapes.size(); j++) {
      layout::Prepare pre{s.p.data(), cut, shapes[j]};
      if (pre.test())
        s.layouts[j / 64] |= 1ULL << (j % 64);
    }
  }
  if (!seeds.eof() || sample.empty())
    throw std::runtime_error("Missing seed file");
  StreamTail packed(argv[2]);
  Id first = std::stoul(argv[3]), stop = std::stoul(argv[4]),
     stride = std::stoul(argv[5]);
  if (first >= stop || stop > tail_orders || !stride)
    throw std::runtime_error("Invalid order range");
  fs::path dir = argv[6];
  if (!fs::create_directory(dir))
    throw std::runtime_error("Choose a new spool directory");
  std::unique_ptr<BondSpool> contractions;
  if (argc == 8)
    contractions = std::make_unique<BondSpool>(dir);
  Coding codec(nullptr);
  std::vector<std::uint64_t> failed(embeddings), reduced(embeddings);
  constexpr unsigned orders_per_spool = 64;
  std::vector<std::ofstream> spools((tail_orders + orders_per_spool - 1) /
                                    orders_per_spool);
  for (Id set = 0; set < embeddings; set++)
    for (unsigned h = 0; h < sample.size(); h++) {
      if (!(sample[h].bonds & codec.labels[set].consecutive))
        reduced[set] |= 1ULL << h;
    }
  std::uint64_t total = 0, dis = 0, bond = 0, deferred = 0;
  for (Id t = first; t < stop; t += stride) {
    auto count = packed.select(t);
    const auto &dict = packed.dictionary;
    const auto &ids = packed.ids;
    for (unsigned d = 0; d < count; d++) {
      std::uint64_t bits = 0;
      for (unsigned h = 0; h < sample.size(); h++)
        bits |= std::uint64_t(disjoint(dict[d], sample[h].layouts)) << h;
      failed[d] = bits;
    }
    total += sample.size() * embeddings;
    const auto &tau = codec.orders[t];
    for (unsigned set = 0; set < embeddings; set++) {
      if (ids[set] >= count)
        throw std::runtime_error("Bad dictionary identifier");
      auto bits = failed[ids[set]];
      if (!bits)
        continue;
      auto &emb = codec.labels[set];
      auto before = std::popcount(bits);
      dis += before;
      if (contractions) {
        Deck p{};
        for (unsigned i = 0; i < ordinary; i++)
          p[cut + i] = emb.back[tau[i]];
        for (auto todo = bits; todo; todo &= todo - 1) {
          auto &w = sample[std::countr_zero(todo)].p;
          for (unsigned i = 0; i < cut; i++)
            p[i] = emb.front[w[i]];
          if (contractions->add(p))
            ++bond;
          else
            ++deferred;
        }
        continue;
      }
      bits &= reduced[set];
      Deck p{}, dual{};
      if (bits) {
        for (unsigned i = 0; i < ordinary; i++)
          p[cut + i] = emb.back[tau[i]];
        for (unsigned i = cut; i < n - 1; i++)
          if (p[i] == p[i + 1] + 1) {
            bits = 0;
            break;
          }
      }
      for (auto keep = bits; keep; keep &= keep - 1) {
        unsigned i = std::countr_zero(keep);
        auto &w = sample[i].p;
        if (emb.front[w.back()] == p[cut] + 1) {
          bits ^= 1ULL << i;
          continue;
        }
        for (unsigned j = 0; j < cut; j++)
          p[j] = emb.front[w[j]];
        for (unsigned j = 0; j < n; j++)
          dual[n - 1 - p[j]] = n - 1 - j;
        auto [h, b] = codec.encode(dual);
        auto group = (b / embeddings) / orders_per_spool;
        auto &f = spools[group];
        if (!f.is_open())
          f.open(dir / ("dual-" + std::to_string(group) + ".bin"),
                 std::ios::binary);
        Query q{h, b};
        if (!f.write(reinterpret_cast<char *>(&q), sizeof(q)))
          throw std::runtime_error("Could not spool deferred dual");
      }
      auto after = std::popcount(bits);
      bond += before - after;
      deferred += after;
    }
  }
  for (auto &f : spools)
    if (f.is_open()) {
      f.close();
      if (!f)
        throw std::runtime_error("Failed to close dual spool");
    }
  if (contractions) {
    contractions->finish();
    if (contractions->count != bond)
      throw std::logic_error("Wrong number of contracted inputs");
  }
  if (dis != bond + deferred)
    throw std::logic_error("Incomplete direct classification");
  std::cout << "heads " << sample.size() << " permutations " << total
            << " direct layout " << total - dis << " disjoint " << dis
            << " descending bond " << bond << " deferred " << deferred << '\n';
}
