"""Replay one or more splice groups from their recorded six-row discovery prefixes."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

from verify_splice import CERTIFICATE, patterns, split_rows


def upper_sections(lower, remaining):
    """Produce every upper section, including lower, using precisely remaining."""
    if len(lower) == 1:
        if not remaining:
            yield lower
        return

    def choose_top(top, unused):
        j = len(top)
        if j + 2 == len(lower):
            for section in upper_sections(top, unused):
                yield section + lower
            return
        triple = tuple(lower[j:j+3])
        for color in "012":
            pattern = (color, *triple)
            if pattern in unused:
                yield from choose_top(top + color, unused - {pattern})

    yield from choose_top("", remaining)


def replay(binary, group, index):
    prefix = group["prefix"]
    rows = split_rows(prefix, 0, 6)
    if rows[-1] != group["pivot"]:
        raise ValueError(f"group {index} has a different discovery pivot")
    caps = sorted(section[:25] for section in upper_sections(rows[-1], patterns(rows, 0)))
    if caps != group["caps"]:
        raise ValueError(f"group {index} cap mismatch")
    result = subprocess.run([binary, prefix, str(len(group["tails"]))], check=True,
                            text=True, stdout=subprocess.PIPE)
    if result.stdout.splitlines() != [prefix + tail for tail in group["tails"]]:
        raise ValueError(f"group {index} tail mismatch")
    print(f"Group {index} reproduced {len(caps):,} caps and {len(group['tails']):,} tails.", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("groups", type=int, nargs="*", help="one-based group numbers, default all")
    parser.add_argument("--jobs", type=int, default=1, help="number of simultaneous prefix searches")
    args = parser.parse_args()
    groups = json.loads(CERTIFICATE.read_text())["groups"]
    indices = args.groups or list(range(1, len(groups)+1))
    if args.jobs < 1 or any(i < 1 or i > len(groups) for i in indices):
        parser.error("choose a positive job count and valid group numbers")
    with TemporaryDirectory() as directory:
        binary = Path(directory) / "splice_search"
        subprocess.run(["c++", "-O3", "-std=c++20", CERTIFICATE.with_name("splice_search.cpp"),
                        "-o", binary], check=True)
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            results = [pool.submit(replay, binary, groups[i-1], i) for i in indices]
            for result in results:
                result.result()


if __name__ == "__main__":
    main()
