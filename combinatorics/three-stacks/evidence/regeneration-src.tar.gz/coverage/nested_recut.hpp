#pragma once
#include "gaps.hpp"
#include "tail.hpp"
#include <array>
#include <fstream>
#include <list>
#include <memory>
#include <unordered_map>

namespace nested_recut {
template <unsigned N, unsigned K> class Filter {
  static constexpr unsigned count = 1 + 2 * K + 3 * K * (K - 1);
  using Bits = std::array<std::uint64_t, (count + 63) / 64>;
  struct Offered {
    Bits checked{}, good{};
  };
  struct Cache {
    std::unique_ptr<gap::Table> table;
    std::unordered_map<unsigned, Offered> offers;
    std::list<unsigned>::iterator recent;
  };
  std::list<unsigned> live;
  std::vector<Bits> heads;
  const std::vector<layout::Shape> shapes = layout::layouts(K);
  std::unordered_map<unsigned, Cache> orders;
  unsigned fuel;
  // Completed embedding certificates remain valid when an order loses its
  // larger table of bounded searches. Reuse the least recently searched table.
  static constexpr unsigned tail_cards = N - K - 1;
  static constexpr unsigned bytes_per_table =
      (1 + 2 * (tail_cards + 1) + 3 * (tail_cards + 2) * (tail_cards + 2)) *
      (1u << (tail_cards + 2));
  static constexpr unsigned capacity =
      std::max(1u, (tail_cards <= 9 ? 67108864u : 33554432u) / bytes_per_table);

  gap::Table &table_for(unsigned order, Cache &cache, const int *tail) {
    if (cache.table) {
      live.splice(live.begin(), live, cache.recent);
      return *cache.table;
    }
    if (live.size() >= capacity) {
      auto &victim = orders.at(live.back());
      cache.table = std::move(victim.table);
      live.pop_back();
    } else
      cache.table = std::make_unique<gap::Table>(K, N, fuel);
    cache.table->reset(tail);
    live.push_front(order);
    cache.recent = live.begin();
    return *cache.table;
  }

public:
  Filter(const char *filename, unsigned budget) : fuel(budget) {
    size_t rows = 1;
    for (unsigned x = 2; x <= K; ++x)
      rows *= x;
    std::ifstream f(filename, std::ios::binary | std::ios::ate);
    if (!f || f.tellg() != std::streamoff(rows * sizeof(Bits)))
      throw std::runtime_error("Wrong nested prefix table size");
    f.seekg(0);
    heads.resize(rows);
    f.read(reinterpret_cast<char *>(heads.data()), rows * sizeof(Bits));
    if (!f)
      throw std::runtime_error("Truncated nested prefix table");
  }
  void reset() {
    orders.clear();
    live.clear();
  }
  template <class Word> bool accepts(const Word &d) {
    std::array<int, tail_cards> tail;
    unsigned suffix = 0;
    for (unsigned i = 0; i < tail_cards; ++i) {
      tail[i] = d[K + i];
      suffix |= 1u << tail[i];
    }
    unsigned order = tail::rank_order(tail.data(), tail_cards);
    auto &cache = orders[order];
    auto &offer = cache.offers[suffix];
    unsigned left = ((1u << N) - 1) ^ (suffix | 1u), rank = 0;
    for (unsigned i = 0; i < K; ++i) {
      unsigned v = d[i], b = 1u << v;
      rank = rank * (K - i) + std::popcount(left & (b - 1));
      left ^= b;
    }
    const Bits &available = heads[rank];
    for (unsigned w = 0; w < available.size(); ++w)
      if (available[w] & offer.good[w])
        return true;
    bool needs_search = false;
    for (unsigned w = 0; w < available.size(); ++w)
      needs_search |= bool(available[w] & ~offer.checked[w]);
    if (!needs_search)
      return false;
    auto &table = table_for(order, cache, tail.data());
    gap::Embedding embedding(K, N, suffix);
    for (unsigned w = 0; w < available.size(); ++w) {
      auto todo = available[w] & ~offer.checked[w];
      while (todo) {
        auto bit = todo & -todo;
        unsigned j = 64 * w + std::countr_zero(bit);
        offer.checked[w] |= bit;
        todo ^= bit;
        if (table.test(embedding, shapes[j])) {
          offer.good[w] |= bit;
          return true;
        }
      }
    }
    return false;
  }
};
} // namespace nested_recut
