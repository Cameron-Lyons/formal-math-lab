// A prefix is read without output. Cards assigned to piles one and two stay
// there in the stated bottom-to-top orders. All other cards must reach pile
// three in decreasing order. Failed branches only discard proposed routes.
#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <vector>

namespace layout {
struct Shape {
    std::vector<int> first, second;
    int members() const {return first.size()+second.size();}
};

struct Prepare {
    const unsigned char* p;
    int n;
    const Shape& shape;
    unsigned hold=0,park=0;

    bool search(int in,unsigned active,unsigned transit,unsigned missing,int a,int b) const {
        while(true){
            int next=missing?std::bit_width(missing)-1:31;
            if(next<31 && (transit & (1u<<next))){
                transit^=1u<<next;missing^=1u<<next;continue;
            }
            if(active){
                int pos=std::bit_width(active)-1, card=p[pos];
                if(card==next){active^=1u<<pos;missing^=1u<<card;continue;}
                if(b<int(shape.second.size()) && shape.second[b]==card && !transit){
                    active ^= 1u<<pos;++b;continue;
                }
            }
            if(in==n && !active) return !missing && !transit && a==int(shape.first.size()) && b==int(shape.second.size());
            if(in<n && p[in]==next){missing^=1u<<next;++in;continue;}
            if(active){
                int pos=std::bit_width(active)-1, card=p[pos];
                if(!(park&(1u<<card)) && !(transit>>card) &&
                   search(in,active^(1u<<pos),transit|(1u<<card),missing,a,b)) return true;
            }
            if(in==n)return false;
            if(hold&(1u<<p[in])){
                if(active || a==int(shape.first.size()) || shape.first[a]!=p[in])return false;
                ++a;++in;
            }else active|=1u<<in++;
        }
    }
    bool test(){
        for(int v:shape.first)hold|=1u<<v;
        for(int v:shape.second)park|=1u<<v;
        return search(0,0,0,((1u<<n)-1) ^ (hold|park),0,0);
    }
};

inline std::vector<Shape> layouts(int n){
    std::vector<Shape> result={{{},{}}};
    for(int a=0;a<n;a++){
        result.push_back({{a},{}});
        result.push_back({{},{a}});
        for(int b=0;b<n;b++)if(a!=b){
            result.push_back({{a,b},{}});
            result.push_back({{a},{b}});
            result.push_back({{},{a,b}});
        }
    }
    return result;
}
}
