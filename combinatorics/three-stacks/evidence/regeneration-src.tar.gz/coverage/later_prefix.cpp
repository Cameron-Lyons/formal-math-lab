// For each normalized prefix, find a certified largest rank of a final extra
// card that can be loaded into the third stack with all previous cards.
#include "prefix.hpp"
#include <chrono>
#include <iostream>
int main(int argc,char**argv){constexpr int k=prefix::size;if(argc<2||argc>4)throw std::runtime_error("usage: later_prefix output [first stop]");int first=argc>2?std::stoi(argv[2]):0,stop=argc>3?std::stoi(argv[3]):prefix::count;
 if(first<0||first>=stop||stop>prefix::count)throw std::runtime_error("Invalid rank range");auto p=prefix::permutation(first);std::ofstream out(argv[1],std::ios::binary);std::array<unsigned char,k+1> q{};layout::Shape empty;std::array<uint64_t,k+2> counts{};
 for(int id=first;id<stop;id++){
  int good=-1,bad=k+1;while(bad-good>1){int mid=(good+bad)/2;for(int i=0;i<k;i++)q[i]=p[i]+(p[i]>=mid);q[k]=mid;layout::Prepare prep{q.data(),k+1,empty};if(prep.test())good=mid;else bad=mid;}
  auto code=static_cast<unsigned char>(good+1);out.put(code);counts[code]++;if(id+1<stop&&!std::next_permutation(p.begin(),p.end()))throw std::runtime_error("Incomplete prefix stream");
 }if(!out)throw std::runtime_error("Cannot write later-cut table");std::cerr<<"threshold counts";for(auto x:counts)std::cerr<<' '<<x;std::cerr<<'\n';
}
