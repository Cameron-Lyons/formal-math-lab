#pragma once
#include "prefix.hpp"
#include <limits>
#include <memory>
#include <unordered_map>

namespace hierarchy {
using Mask = prefix::Mask;
using Index = std::uint32_t;
struct RootRows {
  std::vector<Index> ids;
  std::vector<Mask> masks;
};
struct Anchor {
  std::shared_ptr<const RootRows> root;
  Mask layouts;
  unsigned projection;
  std::vector<Index> ranks;
};
using Ptr = std::shared_ptr<const Anchor>;
struct Hash {
  std::size_t operator()(const Mask &m) const {
    std::uint64_t h = 0;
    for (auto x : m)
      h = (h ^ x) * 0x9e3779b185ebca87ULL;
    return h ^ (h >> 31);
  }
};
inline bool contained(const Mask &a, const Mask &b) {
  for (unsigned i = 0; i < a.size(); ++i)
    if (a[i] & ~b[i])
      return false;
  return true;
}
inline int distance(const Mask &a, const Mask &b) {
  int d = 0;
  for (unsigned i = 0; i < a.size(); ++i)
    d += std::popcount(a[i] ^ b[i]);
  return d;
}
struct Bank {
  std::vector<Ptr> values;
  unsigned write = 0;
  void add(Ptr p) {
    if (p->ranks.size() > 1500)
      return;
    if (p->root) {
      auto converted = std::make_shared<Anchor>(*p);
      for (auto &id : converted->ranks)
        id = p->root->ids[id];
      converted->root.reset();
      p = std::move(converted);
    }
    if (values.size() < 192)
      values.push_back(std::move(p));
    else {
      values[write] = std::move(p);
      write = (write + 1) % values.size();
    }
  }
};
struct Query {
  Mask m;
  std::uint32_t cost;
  Ptr anchor;
};
class Groups {
  std::unordered_map<Mask, Index, Hash> ids;
  std::vector<Query> queries;
  std::vector<Index> members;
  std::size_t memory = 0;
  template <class Project, class Enumerate, class Head>
  void cluster(unsigned begin, unsigned end, Ptr parent, Bank &bank,
               Project &project, Enumerate &enumerate, Head &head) {
    const unsigned n = end - begin;
    Mask common = queries[members[begin]].m;
    std::uint64_t full_cost = 0;
    for (unsigned i = begin; i < end; ++i) {
      auto &q = queries[members[i]];
      full_cost += q.cost;
      for (unsigned w = 0; w < common.size(); ++w)
        common[w] &= q.m[w];
    }
    for (auto &anchor : bank.values)
      if ((!parent || anchor->ranks.size() < parent->ranks.size()) &&
          contained(anchor->layouts, common))
        parent = anchor;
    if (n >= 2 && (!parent || parent->ranks.size() > 64) &&
        (!parent || parent->layouts != common) && memory < (384U << 20)) {
      auto bounds = project(common);
      const bool from_parent =
          parent &&
          (parent->root || parent->ranks.size() * 10ULL <= bounds.count);
      const std::size_t cap =
          from_parent && parent->root
              ? parent->ranks.size()
              : std::min<std::uint64_t>(
                    100000, std::max<std::uint64_t>(50, full_cost / n / 5));
      if (from_parent ||
          (bounds.count < 4000000U && bounds.count * 5ULL < full_cost)) {
        std::vector<Index> good;
        bool complete = true;
        if (from_parent) {
          for (Index j : parent->ranks)
            if (!prefix::any(parent->root ? parent->root->masks[j] : head(j),
                             common)) {
              good.push_back(j);
              if (good.size() > cap) {
                complete = false;
                break;
              }
            }
        } else {
          auto candidates = enumerate(common, cap + 1);
          complete = candidates.ranks.size() <= cap;
          if (complete)
            good = std::move(candidates.ranks);
        }
        if (complete &&
            (!parent || good.size() * 5ULL < parent->ranks.size() * 4ULL)) {
          memory += 4 * good.capacity() + sizeof(Anchor);
          auto a = std::make_shared<Anchor>(
              Anchor{from_parent ? parent->root : nullptr, common,
                     from_parent ? parent->projection : bounds.which,
                     std::move(good)});
          if (n >= 5)
            bank.add(a);
          parent = std::move(a);
        }
      }
    }
    if (n <= 3 || (parent && parent->ranks.size() <= 64)) {
      for (unsigned i = begin; i < end; ++i) {
        auto &q = queries[members[i]];
        if (parent && (parent->root || parent->ranks.size() * 3ULL < q.cost))
          q.anchor = parent;
      }
      return;
    }
    auto farthest = [&](const Mask &a) {
      unsigned far = begin;
      int best = -1;
      for (unsigned i = begin; i < end; ++i) {
        int d = distance(a, queries[members[i]].m);
        if (d > best) {
          best = d;
          far = i;
        }
      }
      return queries[members[far]].m;
    };
    Mask a = farthest(queries[members[begin]].m), b = farthest(a);
    auto mid = std::partition(members.begin() + begin, members.begin() + end,
                              [&](Index i) {
                                return distance(a, queries[i].m) <=
                                       distance(b, queries[i].m);
                              }) -
               members.begin();
    if (mid == begin || mid == end)
      mid = begin + n / 2;
    cluster(begin, mid, parent, bank, project, enumerate, head);
    cluster(mid, end, parent, bank, project, enumerate, head);
  }

public:
  template <class Rows, class Project, class Enumerate, class Head>
  Groups(Rows rows, unsigned n, Bank &bank, Project project,
         Enumerate enumerate, Head head) {
    for (unsigned i = 0; i < n; ++i) {
      const auto &value = rows(i);
      auto [it, fresh] = ids.try_emplace(value, queries.size());
      if (fresh)
        queries.push_back({value, project(value).count, {}});
    }
    members.resize(queries.size());
    std::iota(members.begin(), members.end(), 0);
    Mask common = queries.front().m;
    for (const auto &query : queries)
      for (unsigned w = 0; w < common.size(); ++w)
        common[w] &= query.m[w];
    Ptr initial;
    constexpr unsigned sample = 4096;
    unsigned misses = 0;
    for (unsigned i = 0; i < sample; ++i)
      misses +=
          !prefix::any(common, head(std::uint64_t(i) * prefix::count / sample));
    if (std::uint64_t(misses) * prefix::count < 4000000ULL * sample) {
      auto root = std::make_shared<RootRows>();
      auto estimated = std::size_t(misses) * prefix::count / sample;
      root->ids.reserve(estimated + estimated / 8 + 32);
      root->masks.reserve(root->ids.capacity());
      for (int i = 0; i < prefix::count && root->ids.size() <= 5000000; ++i) {
        const auto &m = head(i);
        if (!prefix::any(common, m)) {
          root->ids.push_back(i);
          root->masks.push_back(m);
        }
      }
      if (root->ids.size() <= 5000000) {
        std::vector<Index> local(root->ids.size());
        std::iota(local.begin(), local.end(), 0);
        initial = std::make_shared<Anchor>(
            Anchor{root, common, std::numeric_limits<unsigned>::max(),
                   std::move(local)});
      }
    }
    cluster(0, members.size(), initial, bank, project, enumerate, head);
  }
  Ptr get(const Mask &m) const { return queries[ids.at(m)].anchor; }
};
} // namespace hierarchy
