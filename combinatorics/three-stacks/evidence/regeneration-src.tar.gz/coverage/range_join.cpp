// Intersect certificates across contiguous ranges of suffix value sets. A
// shared bit at a node certifies every deck in its range for that prefix.
#ifndef CARD_COUNT
#define CARD_COUNT 19
#endif
#include "../verify/dual_projection.hpp"
#include "../verify/join_tables.hpp"
#include "earlier_cache.hpp"
#include "gaps.hpp"
#include "late_split.hpp"
#include "nested_recut.hpp"
#include "quadrant.hpp"
#include "range_cluster.hpp"
#include "tail.hpp"
#ifdef ORDERED_PROJECTED
#include "ordered_acceleration.hpp"
#endif
#ifdef __AVX2__
#include <immintrin.h>
#endif

namespace ranges {
constexpr int short_cut = cut - 1;
constexpr int early_columns = 64;
constexpr int all_early = 1 + 2 * short_cut + 3 * short_cut * (short_cut - 1);
constexpr int branching = 4;
constexpr Id short_heads = heads / cut;
constexpr unsigned short_sets = choose(n - 1, ordinary + 1);
using ShortMask =
    std::array<uint64_t,
               (1 + 2 * short_cut + 3 * short_cut * (short_cut - 1) + 63) / 64>;
using Shape = layout::Shape;
struct Geometry {
  std::array<unsigned short, early_columns> column;
  std::array<unsigned, early_columns> gap;
};
struct Leaf {
  Mask mask;
  uint32_t bond;
  std::array<uint16_t, cut> omit;
  std::array<uint64_t, cut> early{};
  bool tail_bond;
  int suffix[ordinary + 1]{}, prefix[cut]{};
};
struct Node {
  Mask mask;
  uint32_t bond;
  std::array<uint16_t, cut> omit;
  std::array<uint64_t, cut> early;
  int leaf = -1, children = 0, span = 0;
  std::array<int, branching> child{};
};
inline bool hit(const Mask &a, const Mask &b) {
  uint64_t x = 0;
  for (size_t w = 0; w < a.size(); ++w)
    x |= a[w] & b[w];
  return x != 0;
}
static std::array<unsigned, early_columns> choose_columns() {
  auto all = layout::layouts(short_cut);
  std::vector<unsigned> ids;
  for (unsigned j = 0; j < all.size(); ++j)
    if (all[j].members() <= 1)
      ids.push_back(j);
  // Keep pairs involving the smallest or largest parked prefix rank.
  for (unsigned span = 0; ids.size() < early_columns && span < short_cut;
       ++span) {
    for (unsigned j = 0; j < all.size() && ids.size() < early_columns; ++j) {
      auto &s = all[j];
      if (s.members() != 2)
        continue;
      int a = !s.first.empty() ? s.first.front() : s.second.front();
      int b = s.first.size() == 2 ? s.first.back() : s.second.back();
      if (unsigned(std::min({a, b, short_cut - 1 - a, short_cut - 1 - b})) ==
          span)
        ids.push_back(j);
    }
  }
  if (ids.size() != early_columns)
    throw std::logic_error("Early columns incomplete");
  if constexpr (short_cut == 10 || short_cut == 11) {
    // Extra pair layouts observed frequently among misses of the first
    // selection. Each layout still needs independent prefix/tail evidence.
    constexpr unsigned extra[] = {290, 231, 258, 202, 253, 197, 245, 216,
                                  141, 289, 161, 256, 229, 112, 173, 163,
                                  129, 198, 195, 287, 219, 275, 242, 282,
                                  144, 261, 260, 224, 213, 227};
    const auto ten = layout::layouts(10);
    for (unsigned j : extra) {
      if constexpr (short_cut == 11) {
        auto shape = ten[j];
        for (auto *stack : {&shape.first, &shape.second})
          for (auto &value : *stack)
            if (value >= 5)
              ++value;
        auto found = std::find_if(all.begin(), all.end(), [&](const auto &s) {
          return s.first == shape.first && s.second == shape.second;
        });
        if (found == all.end())
          throw std::logic_error("Missing lifted layout");
        j = found - all.begin();
      }
      if (std::find(ids.begin(), ids.end(), j) == ids.end())
        ids.insert(ids.begin() + 30, j);
    }
    ids.resize(early_columns);
  }
  std::array<unsigned, early_columns> out;
  std::copy(ids.begin(), ids.end(), out.begin());
  return out;
}
struct Early {
  std::array<unsigned, early_columns> columns = choose_columns();
  std::vector<uint64_t> available;
  std::vector<Geometry> geography;
  std::array<unsigned, 1u << (n - 1)> short_id{};
  std::vector<std::array<unsigned, cut>> extension;
  int fuel, leaf_budget;
  std::string offer_cache_directory;
  struct ShortHeads {
    const ShortMask *masks = nullptr;
    void map(const char *path) {
      int fd = open(path, O_RDONLY);
      struct stat info{};
      if (fd < 0 || fstat(fd, &info) != 0 ||
          info.st_size != off_t(short_heads) * sizeof(ShortMask)) {
        if (fd >= 0)
          close(fd);
        throw std::runtime_error("Incorrect earlier prefix file");
      }
      auto address = mmap(nullptr, info.st_size, PROT_READ, MAP_SHARED, fd, 0);
      close(fd);
      if (address == MAP_FAILED)
        throw std::runtime_error("Cannot map earlier prefix file");
      masks = static_cast<const ShortMask *>(address);
    }
    void release() {
      if (masks)
        munmap(const_cast<ShortMask *>(masks),
               size_t(short_heads) * sizeof(ShortMask));
      masks = nullptr;
    }
    ~ShortHeads() { release(); }
    const ShortMask &operator[](Id i) const { return masks[i]; }
  } full_heads;
  std::vector<std::array<unsigned, all_early>> full_keys;
  std::array<std::unique_ptr<gap::Table>, ordinary + 1> detailed;
  std::array<std::array<unsigned char, 1 + 2 * (ordinary + 2) +
                                           3 * (ordinary + 3) * (ordinary + 3)>,
             ordinary + 1>
      direct;
  std::array<ShortMask, cut> checked{}, good{};
  uint64_t pack(const ShortMask &m) const {
    uint64_t bits = 0;
    for (unsigned i = 0; i < early_columns; i++)
      if (m[columns[i] / 64] & (1ull << (columns[i] % 64)))
        bits |= 1ull << i;
    return bits;
  }
  Early(const char *path, const Coding &codec, int budget, int post,
        bool local = false)
      : available(local ? 0 : short_heads), fuel(budget), leaf_budget(post) {
    full_heads.map(path);
    for (Id index = 0; index < available.size(); ++index)
      available[index] = pack(full_heads[index]);
    if (!leaf_budget && !local)
      full_heads.release();
    const auto shapes = layout::layouts(short_cut);
    gap::Table keys(short_cut, n, 1);
    constexpr unsigned stride = 1u << (ordinary + 3);
    for (unsigned set = 0; set < (1u << (n - 1)); ++set)
      if (std::popcount(set) == int(ordinary + 1)) {
        short_id[set] = geography.size();
        auto &g = geography.emplace_back();
        gap::Embedding emb(short_cut, n, set << 1);
        if (leaf_budget) {
          auto &all = full_keys.emplace_back();
          for (unsigned j = 0; j < all_early; j++)
            all[j] = keys.key(emb, shapes[j]);
        }
        for (unsigned i = 0; i < early_columns; i++) {
          auto key = keys.key(emb, shapes[columns[i]]);
          g.gap[i] = key;
          g.column[i] = key / stride;
        }
      }
    extension.resize(embeddings);
    for (Id s = 0; s < embeddings; s++) {
      unsigned known = 0;
      for (auto x : codec.labels[s].back)
        known |= 1u << (x - 1);
      for (unsigned r = 0; r < cut; r++) {
        auto x = codec.labels[s].front[r];
        unsigned slot = std::popcount(known & ((1u << (x - 1)) - 1));
        extension[s][r] = short_id[known | (1u << (x - 1))] + slot * short_sets;
      }
    }
  }
  void update(const Tail &tau, std::vector<Leaf> &leaves) {
    constexpr unsigned ord = ordinary + 1;
    earlier_cache::Header header{};
    header.n = n;
    header.k = short_cut;
    header.order = Coding::tail_rank(tau.data());
    header.fuel = fuel;
    header.columns = columns;
    earlier_cache::File file(offer_cache_directory, header);
    std::vector<uint64_t> offer_rows(short_sets * (file.enabled() ? ord : 1));
    bool cached = file.read(offer_rows);
    gap::Table gap_test(short_cut, n, std::max(fuel, 1));
    for (unsigned slot = 0; slot < ord; slot++) {
      auto *offers =
          offer_rows.data() + (file.enabled() ? slot * short_sets : 0);
      std::array<int, ord> word{};
      word[0] = slot;
      for (unsigned j = 0; j < ordinary; j++)
        word[j + 1] = tau[j] + (tau[j] >= slot);
      gap_test.reset(word.data());
      std::array<unsigned char, 1 + 2 * (ord + 1) + 3 * (ord + 2) * (ord + 2)>
          good{};
      auto pair_col = [](unsigned role, unsigned a, unsigned b) {
        return 1 + 2 * (ord + 1) +
               ((role - tail::both_first) * (ord + 2) + a) * (ord + 2) + b;
      };
      good[0] = tail::detail::solve(word.data(), ord, tail::empty, -1, -1);
      for (unsigned role : {tail::first, tail::second})
        for (unsigned a = 0; a <= ord; a++)
          good[1 + (role - tail::first) * (ord + 1) + a] =
              tail::detail::solve(word.data(), ord, role, a, -1);
      for (unsigned role : {tail::both_first, tail::split, tail::both_second})
        for (unsigned a = 0; a < ord + 2; a++)
          for (unsigned b = 0; b < ord + 2; b++)
            if (a != b)
              good[pair_col(role, a, b)] =
                  tail::detail::solve(word.data(), ord, role, a, b);
      if (leaf_budget) {
        if (!detailed[slot])
          detailed[slot] =
              std::make_unique<gap::Table>(short_cut, n, leaf_budget);
        detailed[slot]->reset(word.data());
        direct[slot] = good;
      }
      if (!cached)
        for (unsigned s = 0; s < short_sets; s++) {
          const auto &g = geography[s];
          uint64_t mask = 0;
          for (unsigned j = 0; j < early_columns; j++) {
            bool works = good[g.column[j]] || (fuel && gap_test.test(g.gap[j]));
            mask |= uint64_t(works) << j;
          }
          offers[s] = mask;
        }
      for (Id s = 0; s < embeddings; s++)
        for (unsigned r = 0; r < cut; r++) {
          unsigned ext = extension[s][r];
          if (ext / short_sets == slot)
            leaves[s].early[r] = offers[ext % short_sets];
        }
    }
    if (file.enabled() && !cached)
      file.write(offer_rows);
  }
  void begin_leaf() {
    checked = {};
    good = {};
  }
  bool more(Id set, unsigned last, Id old) {
    if (!leaf_budget)
      return false;
    auto ext = extension[set][last];
    unsigned slot = ext / short_sets;
    const auto &keys = full_keys[ext % short_sets];
    const auto &mask = full_heads[old];
    constexpr unsigned stride = 1u << (ordinary + 3);
    for (unsigned w = 0; w < mask.size(); w++)
      if (mask[w] & good[last][w])
        return true;
    for (unsigned w = 0; w < mask.size(); w++) {
      auto tod = mask[w] & ~checked[last][w];
      while (tod) {
        unsigned bit = std::countr_zero(tod), j = 64 * w + bit;
        auto unit = 1ull << bit;
        tod ^= unit;
        checked[last][w] |= unit;
        auto key = keys[j];
        if (direct[slot][key / stride] || detailed[slot]->test(key)) {
          good[last][w] |= unit;
          return true;
        }
      }
    }
    return false;
  }
};
struct Record {
  Mask mask;
  uint64_t early;
  uint32_t flags;
  Id id;
};
struct Search {
#ifdef ORDERED_PROJECTED
  std::unique_ptr<ordered_acceleration::Dual> fast;
#endif
  const TableFile &heads_table;
  const TableFile &tail_table;
  const Coding &codec;
  const WordInfo *words;
  Id head_first = 0, head_end = heads;
  Id mapped_first = 0, mapped_end = heads;
  unsigned group_depth = 0;
  unsigned fixed_count = 0;
  using Defer = void (*)(void *, Id, Id);
  Defer defer = nullptr;
  void *defer_context = nullptr;
  uint64_t deferred = 0;
  std::vector<uint64_t> local_earlier;
  std::unique_ptr<dual_projection::File<cut>> quick_dual;
  std::unique_ptr<Early> early;
  std::unique_ptr<late_split::Filter<n, cut>> late;
  std::uint64_t late_direct = 0, late_dual = 0;
  std::vector<Leaf> leaves = std::vector<Leaf>(embeddings);
  std::vector<Node> tree;
  std::vector<int> active;
  uint64_t checked = 0, individual = 0, noncanonical = 0, dual_ok = 0,
           remaining = 0, additional = 0, accounted = 0;
  std::vector<Record> records;
  int order = 0;
  bool allow_clustering = true, cluster = false;
  bool compare_ties = true;
  range_cluster::Weights<columns, Mask> weights;
  std::unique_ptr<nested_recut::Filter<n, cut - 2>> next_cut;
  std::unique_ptr<nested_recut::Filter<n, cut - 3>> last_cut;
  uint64_t next_ok = 0, last_ok = 0, root_count = 0;
  size_t batch = 262144;
  Search(const TableFile &h, const TableFile &t, const Coding &c,
         const char *earlyfile, int budget, int post, bool local = false)
      : heads_table(h), tail_table(t), codec(c), words(c.prefixes) {
    if (earlyfile)
      early = std::make_unique<Early>(earlyfile, c, budget, post, local);
    if constexpr (n >= 17 && n - cut - 2 <= 6)
      if (earlyfile)
        late = std::make_unique<late_split::Filter<n, cut>>();
  }
  void shard(Id first, Id end, const WordInfo *first_word, Defer remote,
             void *context) {
    if (first >= end || end > heads || !first_word)
      throw std::runtime_error("Invalid prefix shard");
    head_first = mapped_first = first;
    head_end = mapped_end = end;
    words = first_word;
    defer = remote;
    defer_context = context;
    fixed_count = 0;
    while (fixed_count < cut && words[0].rank[fixed_count] ==
                                    words[end - first - 1].rank[fixed_count])
      ++fixed_count;
    if (early && early->available.empty()) {
      local_earlier.resize(end - first);
      for (Id i = 0; i < local_earlier.size(); ++i)
        local_earlier[i] =
            early->pack(early->full_heads[earlier_rank(words[i])]);
      if (!early->leaf_budget)
        early->full_heads.release();
    }
  }
  static Deck deck(const WordInfo &w, const Leaf &leaf) {
    Deck out{};
    for (unsigned i = 0; i < cut; ++i)
      out[i] = leaf.prefix[w.rank[i]];
    for (unsigned i = 0; i < ordinary; ++i)
      out[cut + i] = leaf.suffix[i];
    return out;
  }
  bool discard_fixed(const Leaf &leaf) const {
    if (!fixed_count)
      return false;
    std::array<int, n> position;
    position.fill(-1);
    const auto &ranks = words[0].rank;
    for (unsigned i = 0; i < fixed_count; ++i) {
      auto value = leaf.prefix[ranks[i]];
      if (i && leaf.prefix[ranks[i - 1]] == value + 1)
        return true;
      position[value] = i;
    }
    for (unsigned i = 0; i < ordinary; ++i)
      position[leaf.suffix[i]] = cut + i;
    // The dual starts with reversed positions of the largest values. Assign
    // its unknown positions in increasing order to maximize it
    // lexicographically.
    unsigned first_free = fixed_count;
    for (unsigned i = 0; i < fixed_count; ++i) {
      int pos = position[n - 1 - i];
      int upper = n - 1 - (pos < 0 ? int(first_free++) : pos);
      int actual = leaf.prefix[ranks[i]];
      if (actual != upper)
        return actual > upper;
    }
    return false;
  }
  void prepare(int tau) {
    order = tau;
    active.clear();
    tree.clear();
    tree.reserve(2 * embeddings);
    const auto &perm = codec.orders[tau];
    for (Id s = 0; s < embeddings; s++) {
      auto &lf = leaves[s];
      auto &emb = codec.labels[s];
      for (unsigned i = 0; i < cut; i++)
        lf.prefix[i] = emb.front[i];
      for (unsigned i = 0; i < ordinary; i++)
        lf.suffix[i] = emb.back[perm[i]];
      lf.tail_bond = false;
      for (unsigned i = 0; i < ordinary; i++)
        lf.tail_bond |= lf.suffix[i] == lf.suffix[i + 1] + 1;
      if (lf.tail_bond || discard_fixed(lf))
        continue;
      lf.mask = tail_table[tau * embeddings + s];
      lf.bond = emb.consecutive;
      for (unsigned r = 0; r < cut; r++)
        if (lf.prefix[r] == lf.suffix[0] + 1)
          lf.bond |= 1u << (cut - 1 + r);
      // Canonical comparison of p[0] with the sorting dual's first card.
      // max_position is either its index in the prefix or fixed by the tail.
      int max_in_tail = -1;
      for (unsigned i = 0; i < ordinary; i++)
        if (lf.suffix[i] == int(n - 1))
          max_in_tail = cut + i;
      for (unsigned r = 0; r < cut; r++) {
        unsigned omitted = 0;
        for (unsigned m = 0; m < cut; m++)
          if (lf.prefix[r] >
              int(n - 1) - (max_in_tail < 0 ? int(m) : max_in_tail))
            omitted |= 1u << m;
        lf.omit[r] = omitted;
      }
      active.push_back(s);
    }
    if (early && !active.empty())
      early->update(perm, leaves);
  }
  void choose_tree() {
    cluster = false;
    if (!allow_clustering || head_end - head_first < 1000000u ||
        active.size() < 1000)
      return;
    // Estimate how many prefixes pass the root unchanged. Expensive suffix
    // orders benefit most from the extra partitioning.
    Node common{};
    const auto &first = leaves[active.front()];
    common.mask = first.mask;
    common.bond = first.bond;
    common.early = first.early;
    common.omit = first.omit;
    for (auto id : active) {
      const auto &leaf = leaves[id];
      common.bond &= leaf.bond;
      for (unsigned w = 0; w < common.mask.size(); w++)
        common.mask[w] &= leaf.mask[w];
      for (unsigned r = 0; r < cut; r++) {
        common.early[r] &= leaf.early[r];
        common.omit[r] &= leaf.omit[r];
      }
    }
    auto sample = [&](unsigned j, unsigned count) -> const Mask & {
      return heads_table[head_first +
                         uint64_t(j) * (head_end - head_first) / count];
    };
    unsigned waiting = 0;
    for (unsigned j = 0; j < 1024; j++) {
      Id i = head_first + uint64_t(j) * (head_end - head_first) / 1024;
      const auto &mask = heads_table[i];
      if (hit(common.mask, mask))
        continue;
      const auto &w = words[i - head_first];
      uint64_t saved = local_earlier.empty()
                           ? (early ? early->available[earlier_rank(w)] : 0)
                           : local_earlier[i - mapped_first];
      waiting += !other_accepts(common, Record{mask, saved, features(w), i});
    }
    cluster =
        uint64_t(waiting) * (head_end - head_first) > uint64_t(3200000) * 1024;
    if (cluster)
      weights.train(sample);
  }
  int build(int begin, int end, unsigned depth = 0) {
    int id = tree.size();
    tree.emplace_back();
    tree[id].span = end - begin;
    if (end == begin + 1) {
      Node &p = tree[id];
      int s = active[begin];
      p.leaf = s;
      p.mask = leaves[s].mask;
      p.bond = leaves[s].bond;
      p.omit = leaves[s].omit;
      p.early = leaves[s].early;
    } else {
      int chunk = (end - begin + branching - 1) / branching;
      std::array<int, 5> edges;
      if (cluster) {
        int mid = weights.partition(active, leaves, begin, end, depth);
        edges = {begin,
                 weights.partition(active, leaves, begin, mid, depth + 1), mid,
                 weights.partition(active, leaves, mid, end, depth + 1), end};
      } else {
        for (int i = 0; i <= branching; i++)
          edges[i] = std::min(end, begin + i * chunk);
      }
      for (int j = 0; j < branching; j++)
        if (edges[j] < edges[j + 1]) {
          int child = build(edges[j], edges[j + 1], depth + 2);
          auto &p = tree[id];
          auto &c = tree[child];
          p.child[p.children++] = child;
          if (p.children == 1) {
            p.mask = c.mask;
            p.bond = c.bond;
            p.omit = c.omit;
            p.early = c.early;
          } else {
            for (unsigned w = 0; w < p.mask.size(); w++)
              p.mask[w] &= c.mask[w];
            p.bond &= c.bond;
            for (unsigned r = 0; r < cut; r++) {
              p.omit[r] &= c.omit[r];
              p.early[r] &= c.early[r];
            }
          }
        }
    }
    return id;
  }
  static Id earlier_rank(const WordInfo &p) {
    unsigned left = ((1u << cut) - 1) ^ (1u << p.rank.back());
    unsigned rank = 0;
    for (unsigned i = 0; i < cut - 1; i++) {
      int x = p.rank[i];
      rank = rank * (cut - 1 - i) + std::popcount(left & ((1u << x) - 1));
      left ^= 1u << x;
    }
    return rank;
  }
  static uint32_t features(const WordInfo &w) {
    return w.descending | (w.rank.back() << 12) | (w.rank.front() << 16) |
           (w.max_position << 20);
  }
  static bool other_accepts(const Node &p, const Record &c) {
    unsigned last = (c.flags >> 12) & 15;
    return (((c.flags & 4095) | (1u << (cut - 1 + last))) & p.bond) ||
           (p.omit[(c.flags >> 16) & 15] & (1u << (c.flags >> 20))) ||
           (c.early & p.early[last]);
  }
  struct Pending {
    uint64_t key;
    Deck d;
  };
  std::vector<Pending> pending_output;
  static unsigned suffix_order(const Deck &d, unsigned start) {
    unsigned seen = 0, rank = 0;
    for (unsigned i = start; i < n - 1; i++) {
      rank = rank * (i - start + 1) + std::popcount(seen >> d[i]);
      seen |= 1u << d[i];
    }
    return rank;
  }
  bool late_accepts(const Deck &d, Id h, Id dh, bool head_may_park,
                    bool remote) {
    if (!late)
      return false;
    if (head_may_park && late->accepts(d, h)) {
      ++late_direct;
      return true;
    }
    if (!remote && !(heads_table[dh][0] & 1))
      return false;
    Deck dual;
    for (unsigned i = 0; i < n; i++)
      dual[n - 1 - d[i]] = n - 1 - i;
    if (late->accepts(dual, dh)) {
      ++late_dual;
      return true;
    }
    return false;
  }
  void emit(const Deck &d) {
    ++remaining;
    std::cout << "Hard 1";
    for (int v : d)
      std::cout << ' ' << v + 1;
    std::cout << '\n';
  }
  void flush_nested() {
    // The normalized earlier tail orders are few for a fixed original order.
    // Keep each continuation table hot across all matching pending decks.
    std::sort(pending_output.begin(), pending_output.end(),
              [](const auto &a, const auto &b) { return a.key < b.key; });
    for (const auto &item : pending_output) {
      if (next_cut && next_cut->accepts(item.d)) {
        ++next_ok;
        continue;
      }
      if (last_cut && last_cut->accepts(item.d)) {
        ++last_ok;
        continue;
      }
      emit(item.d);
    }
    pending_output.clear();
  }
  void settle(const Deck &d) {
    if (!next_cut && !last_cut) {
      emit(d);
      return;
    }
    unsigned set = 0;
    for (unsigned i = cut - 3; i < n - 1; i++)
      set |= 1u << d[i];
    constexpr unsigned second_bits =
        std::bit_width(factorial_of(n - cut + 2) - 1);
    unsigned first = next_cut ? suffix_order(d, cut - 2) : 0;
    unsigned second = last_cut ? suffix_order(d, cut - 3) : 0;
    auto key =
        (uint64_t(first) << (second_bits + n)) | (uint64_t(second) << n) | set;
    pending_output.push_back({key, d});
    if (pending_output.size() >= 262144)
      flush_nested();
  }
  void visit(int id, const std::vector<Id> &previous) {
    const auto &p = tree[id];
    if (p.leaf >= 0) {
      accounted += previous.size();
      const auto &l = leaves[p.leaf];
#ifdef ORDERED_PROJECTED
      const auto &encode = fast->address[p.leaf];
#else
      quadrant::Encoder<n, cut> encode(l.prefix, l.suffix);
#endif
      if (early && early->leaf_budget)
        early->begin_leaf();
      int max_pos = -1;
      for (unsigned k = 0; k < ordinary; k++)
        if (l.suffix[k] == int(n - 1))
          max_pos = cut + k;
      for (Id at : previous) {
        const auto &c = records[at];
        individual++;
        const auto &w = words[c.id - head_first];
        if (compare_ties && l.prefix[w.rank[0]] ==
            int(n - 1) - (max_pos < 0 ? w.max_position : max_pos)) {
          auto d = deck(w, l);
          Deck dual;
          for (unsigned i = 0; i < n; i++)
            dual[n - 1 - d[i]] = n - 1 - i;
          if (dual < d) {
            noncanonical++;
            continue;
          }
        }
#ifdef ORDERED_PROJECTED
        auto key = encode.key(fast->codes[c.id], w.rank.data());
#else
        auto key = encode.key(w.rank.data());
#endif
        unsigned dh = key.head,
                 db = key.order * embeddings + codec.set_id[key.set];
#ifdef ORDERED_PROJECTED
        if (fast->prefixes[dh] & fast->suffixes[db]) {
#else
        if (quick_dual && quick_dual->accepts(dh, tail_table[db])) {
#endif
          ++dual_ok;
          continue;
        }
        if (defer && (dh < mapped_first || dh >= mapped_end)) {
          if (early && early->leaf_budget &&
              early->more(p.leaf, w.rank.back(), earlier_rank(w))) {
            additional++;
            continue;
          }
          auto d = deck(w, l);
          if (late_accepts(d, c.id, dh, c.mask[0] & 1, true))
            continue;
          if (next_cut || last_cut) {
            if (next_cut && next_cut->accepts(d)) {
              ++next_ok;
              continue;
            }
            if (last_cut && last_cut->accepts(d)) {
              ++last_ok;
              continue;
            }
          }
          defer(defer_context, dh, db);
          deferred++;
          continue;
        }
        if (hit(heads_table[dh], tail_table[db])) {
          dual_ok++;
          continue;
        }
        if (early && early->leaf_budget &&
            early->more(p.leaf, w.rank.back(), earlier_rank(w))) {
          additional++;
          continue;
        }
        auto d = deck(w, l);
        if (!late_accepts(d, c.id, dh, c.mask[0] & 1, false))
          settle(d);
      }
      return;
    }
    std::array<std::vector<Id>, branching> next;
    for (int j = 0; j < p.children; j++)
      next[j].reserve(previous.size() / 3);
#ifdef __AVX2__
    if (p.children == 4 && previous.size() >= 80) {
      __m256i mask[Mask{}.size()], earlier[cut], omission[cut], bonds;
      auto pack = [&](auto value) {
        return _mm256_set_epi64x(
            value(tree[p.child[3]]), value(tree[p.child[2]]),
            value(tree[p.child[1]]), value(tree[p.child[0]]));
      };
      for (unsigned w = 0; w < Mask{}.size(); w++)
        mask[w] = pack([&](const Node &a) { return a.mask[w]; });
      for (unsigned r = 0; r < cut; r++) {
        earlier[r] = pack([&](const Node &a) { return a.early[r]; });
        omission[r] = pack([&](const Node &a) { return a.omit[r]; });
      }
      bonds = pack([](const Node &a) { return a.bond; });
      for (Id at : previous) {
        const auto &c = records[at];
        unsigned last = (c.flags >> 12) & 15, first = (c.flags >> 16) & 15;
        auto any = _mm256_and_si256(earlier[last], _mm256_set1_epi64x(c.early));
        any = _mm256_or_si256(
            any, _mm256_and_si256(omission[first],
                                  _mm256_set1_epi64x(1u << (c.flags >> 20))));
        any = _mm256_or_si256(
            any, _mm256_and_si256(
                     bonds, _mm256_set1_epi64x((c.flags & 4095) |
                                               (1u << (cut - 1 + last)))));
        for (unsigned w = 0; w < Mask{}.size(); w++)
          any = _mm256_or_si256(
              any, _mm256_and_si256(mask[w], _mm256_set1_epi64x(c.mask[w])));
        unsigned alive = _mm256_movemask_pd(_mm256_castsi256_pd(
            _mm256_cmpeq_epi64(any, _mm256_setzero_si256())));
        while (alive) {
          unsigned j = std::countr_zero(alive);
          next[j].push_back(at);
          alive &= alive - 1;
        }
      }
    } else
#endif
      for (Id at : previous) {
        const auto &c = records[at];
        for (int j = 0; j < p.children; j++) {
          const auto &child = tree[p.child[j]];
          if (!hit(child.mask, c.mask) && !other_accepts(child, c))
            next[j].push_back(at);
        }
      }
    checked += uint64_t(previous.size()) * p.children;
    for (int j = 0; j < p.children; j++) {
      const auto &child = tree[p.child[j]];
      accounted += uint64_t(previous.size() - next[j].size()) * child.span;
      if (!next[j].empty())
        visit(p.child[j], next[j]);
    }
  }
  void scan_active() {
    auto before = accounted, old_roots = root_count;
    const Id span = head_end - head_first;
    accounted += uint64_t(span) * (embeddings - active.size());
    tree.clear();
    if (!active.empty()) {
      choose_tree();
      int root = build(0, active.size());
      const auto &p = tree[root];
      std::vector<Id> next;
      records.clear();
      auto flush = [&]() {
        if (next.empty())
          return;
        root_count += records.size();
        visit(root, next);
        next.clear();
        records.clear();
      };
      for (Id i = head_first; i < head_end; i++) {
        const auto &mask = heads_table[i];
        if (hit(p.mask, mask))
          continue;
        const auto &w = words[i - head_first];
        uint64_t saved = local_earlier.empty()
                             ? (early ? early->available[earlier_rank(w)] : 0)
                             : local_earlier[i - mapped_first];
        Record record{mask, saved, features(w), i};
        if (!other_accepts(p, record)) {
          next.push_back(records.size());
          records.push_back(record);
          if (records.size() >= batch)
            flush();
        }
      }
      flush();
      accounted += uint64_t(span - (root_count - old_roots)) * p.span;
      checked += span;
    }
    if (accounted - before != uint64_t(span) * embeddings)
      throw std::logic_error("Unaccounted decks");
  }
  void group_heads() {
    const auto original = words;
    unsigned saved_fixed = fixed_count;
    std::vector<int> base = std::move(active);
    Id group_rows = factorial_of(cut - group_depth);
    for (Id lo = mapped_first; lo < mapped_end; lo = head_end) {
      head_first = lo;
      head_end = std::min(mapped_end, (1 + lo / group_rows) * group_rows);
      words = original + (lo - mapped_first);
      fixed_count = 0;
      while (fixed_count < cut &&
             words[0].rank[fixed_count] ==
                 words[head_end - lo - 1].rank[fixed_count])
        ++fixed_count;
      active.clear();
      for (int s : base)
        if (!discard_fixed(leaves[s]))
          active.push_back(s);
      scan_active();
    }
    words = original;
    fixed_count = saved_fixed;
    head_first = mapped_first;
    head_end = mapped_end;
    active = std::move(base);
  }
  void run(int tau) {
    checked = individual = noncanonical = dual_ok = remaining = additional =
        accounted = deferred = 0;
    root_count = next_ok = last_ok = late_direct = late_dual = 0;
    if (next_cut)
      next_cut->reset();
    if (last_cut)
      last_cut->reset();
    auto st = std::chrono::steady_clock::now();
    prepare(tau);
    auto prep = std::chrono::steady_clock::now();
    if (group_depth > fixed_count)
      group_heads();
    else
      scan_active();
    flush_nested();
    const Id span = head_end - head_first;
    if (accounted != uint64_t(span) * embeddings)
      throw std::logic_error("Incomplete head groups");
    const auto end = std::chrono::steady_clock::now();
    std::cerr << "order " << tau << " decks " << uint64_t(span) * embeddings
              << " active sets " << active.size() << " comparisons " << checked
              << " leaf " << individual << " mirror " << noncanonical
              << " dual " << dual_ok << " extra " << additional << " roots "
              << root_count << " late " << late_direct << " late_dual "
              << late_dual << " clustered " << cluster << " nested1 " << next_ok
              << " nested2 " << last_ok << " pending " << remaining;
    if (defer)
      std::cerr << " deferred " << deferred << " head_start " << head_first
                << " head_end " << head_end;
    std::cerr << " prepare " << std::chrono::duration<double>(prep - st).count()
              << " seconds " << std::chrono::duration<double>(end - st).count()
              << '\n';
  }
};
} // namespace ranges
#ifndef RANGE_JOIN_LIBRARY
int main(int argc, char **argv) {
  unsigned group_depth = 0;
  if (argc >= 9 && std::string(argv[argc - 2]) == "--prefix-depth") {
    group_depth = std::stoul(argv[argc - 1]);
    argc -= 2;
  }
  if (group_depth > cut)
    throw std::runtime_error("Invalid fixed-prefix depth");
  if (argc < 7 || argc > 13)
    throw std::runtime_error(
        "range_join prefix tail index first past_last stride [earlier_prefix "
        "[fuel [full_leaf_fuel [next_cut_file [last_cut_file [batch]]]]]]");
  int first = std::stoi(argv[4]), end = std::stoi(argv[5]),
      stride = std::stoi(argv[6]);
  if (first < 0 || end > int(tail_orders) || first >= end || stride <= 0)
    throw std::runtime_error("Invalid shard");
  TableFile head(argv[1], heads), tailfile(argv[2], blocks, true);
  IndexFile index;
  index.load(argv[3], head);
  Coding codec(index.words());
  ranges::Search run(head, tailfile, codec, argc > 7 ? argv[7] : nullptr,
                     argc > 8 ? atoi(argv[8]) : 0,
                     argc > 9 ? atoi(argv[9]) : 0);
  run.group_depth = group_depth;
  if (argc > 10 && std::string(argv[10]) != "-")
    run.next_cut =
        std::make_unique<nested_recut::Filter<n, cut - 2>>(argv[10], 1000);
  if (argc > 11 && std::string(argv[11]) != "-")
    run.last_cut =
        std::make_unique<nested_recut::Filter<n, cut - 3>>(argv[11], 1000);
  if (argc > 12) {
    run.batch = std::stoul(argv[12]);
    if (!run.batch)
      throw std::runtime_error("Batch size must be positive");
  }
  std::ios::sync_with_stdio(false);
  for (int t = first; t < end; t += stride)
    run.run(t);
}
#endif
