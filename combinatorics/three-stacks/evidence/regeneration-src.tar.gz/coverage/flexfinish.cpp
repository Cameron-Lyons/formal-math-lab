#include "../knuth/layout.hpp"
#include "../structural/reach.hpp"
#include <array>
#include <bit>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>

namespace {
constexpr int max_cards=24;
using Deck=std::array<int,max_cards>;

// Test actual prefix ranks and the actual suffix from the identical state.
// No conclusion is drawn from a failed or budget-limited search.
bool cut(const Deck& p,int n,int k,const std::vector<layout::Shape>& shapes,int budget){
    if(k<=0 || k>=n)return false;
    unsigned C=0;
    for(int i=0;i<k;i++)C|=1u<<p[i];
    std::array<unsigned char,max_cards> standard{};
    Deck value{}, local=p;
    for(int i=0;i<k;i++)standard[i]=std::popcount(C&((1u<<p[i])-1));
    int size=0;
    for(unsigned v=C;v;v&=v-1)value[size++]=std::countr_zero(v);
    reach::Search search{local.data(),n,budget,0,false};
    for(const auto& shape:shapes){
        layout::Prepare preparation{standard.data(),k,shape};
        if(!preparation.test())continue;
        unsigned last=C,first=0;
        for(unsigned j=0;j<shape.first.size();j++){
            int x=value[shape.first[j]];local[j]=x;first|=1u<<j;last^=1u<<x;
        }
        const reach::Node empty{31,31,0,nullptr};
        const reach::Node* top=&empty;
        reach::Node middle[2];
        for(unsigned j=0;j<shape.second.size();j++){
            int x=value[shape.second[j]];
            middle[j]={x,std::min(x,top->smallest),0,top};top=&middle[j];last^=1u<<x;
        }
        search.nodes=0;search.exhausted=false;
        if(search.dfs(first,top,last,k,0))return true;
    }
    return false;
}

}
int main(int argc,char**argv){
    if(argc<2)throw std::runtime_error("usage: flexfinish n [DFS-budget] [cut sizes...]");
    int n=std::stoi(argv[1]),budget=argc>2?std::stoi(argv[2]):100;
    if(n<5 || n>max_cards)throw std::runtime_error("Unsupported size");
    std::vector<int> cuts;
    if(argc>3)for(int i=3;i<argc;i++)cuts.push_back(std::stoi(argv[i]));
    else cuts={n-6,n-5,n-7,n-4,n-8};
    std::array<std::vector<layout::Shape>,max_cards> shapes;
    for(int k:cuts){
        if(k<=0||k>=n)throw std::runtime_error("Invalid cut");
        shapes[k]=layout::layouts(k);
        // Try simple layouts and a spread of parked ranks before the rest.
        auto& v=shapes[k];
        std::stable_partition(v.begin(),v.end(),[](auto& s){return s.members()<2;});
        std::mt19937 rng(125713+k);
        std::shuffle(v.begin()+2*k+1,v.end(),rng);
    }
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    Deck p{},dual;
    std::string tag;int flag;
    unsigned long long ok=0,missed=0;
    while(std::cin>>tag>>flag){
        unsigned seen=0;
        for(int i=0;i<n;i++){
            if(!(std::cin>>p[i]) || p[i]<1 || p[i]>n || seen&(1u<<(p[i]-1)))throw std::runtime_error("Invalid deck");
            --p[i];seen|=1u<<p[i];dual[n-1-p[i]]=n-1-i;
        }
        bool good=false;
        for(int k:cuts){
            if(cut(p,n,k,shapes[k],budget)||cut(dual,n,k,shapes[k],budget)){good=true;break;}
        }
        if(good){++ok;continue;}
        ++missed;
        std::cout<<"Hard 1";for(int i=0;i<n;i++)std::cout<<' '<<p[i]+1;std::cout<<'\n';
    }
    std::cerr<<"sorted "<<ok<<" pending "<<missed<<'\n';
}
